# -*- coding: utf-8 -*-

import LINETCR
from LINETCR.lib.curve.ttypes import *
from datetime import datetime
from bs4 import BeautifulSoup
from threading import Thread
from gtts import gTTS
import time,random,sys,json,codecs,threading,glob,re,os,subprocess,shutil,urllib,urllib2,urllib3,tweepy,youtube,tempfile,unicodedata,string,requests,ctypes,glob


token1="Eq7cGZphaQfrMw3DPHGb.Hy1VUCGlHeqjFqxh7coaoW.ojQ7623HRE/0DoTOhPEkaXT7k4q6Bwt8Bhm1ZlcQj1c="#bot1
token2="Er9qGSWERRF1vyz0WAVa.oG3za5Ww4ySLaamwYDQvYG.3obsppeuE58dzG7jZVoSGWTfs3CDZgjn2Vncs4Ls7wM="#bot2
token3="EqQrLDIO3Q8KlU4SZ9U9.7nZ3RUcnZg4WkSShdgN6sq.G5Gz2mgez0WPIBvrDoycn1ttbH/VVwFug8Qd8MwvZFM="#bot3
token4="ErntuY8LOinZCAFFPKG7.uCygs/PSEWcFXVzxqH0MvW.67c88d60gkF2Xkxk6aNj7FeZ3Z3iD91TSzjtE7Aoe6w="#bot4
token5="Er5R3enDzZlMKVb8f5f7.UxG/M/08Hz54h7hZ9FCS9W.izNHy5y+Hxrjly9B3pQOoCjjnhgH3CtcUkLkdXQECzw="#bot5
token6="EqKp1aityrgT6Hozo0m8.gCGJ+SRoFSpP9eGQFQ44Qa.JbVqFBdRQ3s/JzXhw1XWMtc3OTtiCn58ZZAWbS5BeKM="#bot6
token7="Er6YjAI5YmFhKggUX7g9.TE2t3RjxnNIOuVDaw2Makq.b0tbbgL4hMnRsCtGD9qfWoI2FAEc2P6DTMyEpyp4jqY="#bot7      u19c823fecace7ec3e9f4482a7eae38a8
token8="Eq5GE1FdRdPgfQv9RgM4.DKdueqIaz6nOwMO4dj2gDa.tMjXmKboQLrU2Bu2zCt/FQqSO55yre+xfBhYyx/LvlY="#bot8      ub5ed93deb2573678a852f7405b698029
token9="EqSgvD1FakZdhXp4IUke.LehbNqEyfsmIhdpfOUMndG.E8i1hPRwh9jrxvqPKGEmolVsBcn/BkOrsVSciVYXx2I="#bot9      u16fb47b890e545d9cec5f39fd55eff46
token10="EqZn9DOi4eaGlVXHeLy6.fVThUjdLrDNoXFoF1v7+rG.8zo3Tm7PKRp198xSepMlVZEh/U245fA7xEUvdpNCU9s="#bot10    ud2f4f0cba70c66e030f8a1015cccbfbe
token11="EqM6lllql1S6Of2AMRb0.Im7lzQb29qUJQJU3qj9wGa.M6i01bJxB/juFxOi+lTlmSqk5/M9Edp/a/7+aMrPWFM="#bot16  ud2f4f0cba70c66e030f8a1015cccbfbe
token12="ErAb3UD1BzMaEOYSuJSe.81QEm6VdYMxzpT7yr+JudG.IN7eITh5GAHp3oYMFfd9K1pcwYIiQwjKbRcbDsT91Q4="#bot12   uf35a9e33abc3ca65d93eded847f8d40e
token13="EqMFDJPYCdswkR0aiBec.1VX6ryqQCgy5wkneyyqLxa.buePeFaMI/g1ntdiVLAQ23IqBRKiq/7zdsOARbuSTJM="#bot13    ud6fc7a45842a70663958a3446184255c
token14="EqY3tsNuuuXh57BCGfVa.bNtRUUhagkSopwN9/26cIG.CcFgUlegZrDqv1HVzwR0f1L3kPdVY2GqIvWPyFMHoi8="#bot14    u0674ebbae1c018ab0e3d69fdfb6e828a
token15="EqOUjbAyWR3PJrG5BvTf.ZNhJPR+2tRrAbPmTQALPxW.cXywOOGHVMiXogE+RS195SHn+SW1gEANAKamrcuvQu4="#bot15    uce71e3a6bff64eb45a06932da9a9695f
token16="EqM6lllql1S6Of2AMRb0.Im7lzQb29qUJQJU3qj9wGa.M6i01bJxB/juFxOi+lTlmSqk5/M9Edp/a/7+aMrPWFM="#bot16    u88cecb66a076f50ba3aa3bb7409f5680
token17="EqbpYE68qIx36lhfAII1.kL3z9VUfJnSHzAy+5XReCq.ic6qduuk4KOnaehE4dJODt6uGcxgHs4pCOQhECLCDZQ="#bot17
token18="Eqoqw0AMqDiMR2uc8x04.DOvjSsWiyQvdAEQ/bD1Qva.kFY97bfL+22spidxADYayvITMN7rZaoBKIGQiMAyk4w="#bot18
token19="EqiiWrMonqmUm6AoKDQa.rZ+d5kJKZzqbsQsNtz6boG.kvTbDJj010ymu/GTU+7u0XeSi9Vg85tzXPzikTOEkrk="#bot19    u473fc3e4a8e4cd94014aa4a74d9e813a
token20="Eq21v3OQYyQpOr7mwVm8.8GrP48U0BEEZiC+UoiwjYa.Lz/jInTmMhtKDL+B21whMIEBI5nXKPQOaiB5TYvW2Uc="#bot20    uf20469e3cbb46de7b321cfee388589c8
token21="EqW0QqMkUE5KuhQRjQX2.rV2waUF96CiR3E94nNPwiG.uWjd0Fa8fMk4wFiRN7pdSOXJv6sn04Wf3PQhREHBA9o="#kikil 56 u46fd9602e7fde9c22bddef78367a5622
token22="EqDy3TEQ0TN19CD7KpJa.hnGfBiD5G8AmXjagkv2GcG.UXO9oftRnrRoxEX1LRaupBHgs3tvB5G1iJ8dp9dP+jA="#sakura1
token23="EqEDKc4rnJyqfsfigKf7.vFd7MwJfkXl1fR4jcmUQvW.EPo2+g8PG8VUP+44lX7RV9uDCe0Lt7fjIWUU3d5AvM4="#congrat

cl = LINETCR.LINE()
cl.login(token=token1)
cl.loginResult()
print "ELIZA LOGIN SIKSES"

ki = LINETCR.LINE()
ki.login(token=token2)
ki.loginResult()
print "PARRY LOGIN OK"

kk = LINETCR.LINE()
kk.login(token=token3)
kk.loginResult()
print "RAKKO V10"

kc = LINETCR.LINE()
kc.login(token=token4)
kc.loginResult()
print "DOCTOR.A.V10"

ks = LINETCR.LINE()
ks.login(token=token5)
ks.loginResult()
print "ELIZA V10 OK"

ka = LINETCR.LINE()
ka.login(token=token6)
ka.loginResult()
print "OP1 (BOT 6 )"

kb = LINETCR.LINE()
kb.login(token=token7)
kb.loginResult()
print "OP2 (BOT 7 )"

ko = LINETCR.LINE()
ko.login(token=token8)
ko.loginResult()
print "OP3 (BOT 8 )"

ke = LINETCR.LINE()
ke.login(token=token9)
ke.loginResult()
print "OP4 (BOT 9 )"

ku = LINETCR.LINE()
ku.login(token=token10)
ku.loginResult()
print "OP5 (BOT 10 )"

km = LINETCR.LINE()
km.login(token=token11)
km.loginResult()
print "OP6 (BOT 11 )"

kr = LINETCR.LINE()
kr.login(token=token12)
kr.loginResult()
print "OP7 (BOT 12 )"

kd = LINETCR.LINE()
kd.login(token=token13)
kd.loginResult()
print "OP8 (BOT 13 )"

kw = LINETCR.LINE()
kw.login(token=token14)
kw.loginResult()
print "OP9 (BOT 14 )"

kn = LINETCR.LINE()
kn.login(token=token15)
kn.loginResult()
print "OP10 (BOT 15 )"

kt = LINETCR.LINE()
kt.login(token=token16)
kt.loginResult()
print "OP11 (BOT 16 )"

ky = LINETCR.LINE()
ky.login(token=token17)
ky.loginResult()
print "OP12 (BOT 17 )"

kh = LINETCR.LINE()
kh.login(token=token18)
kh.loginResult()
print "OP13 (BOT 18 )"

kz = LINETCR.LINE()
kz.login(token=token19)
kz.loginResult()
print "OP14 (BOT 19 )"

satpam = LINETCR.LINE()
satpam.login(token=token20)
satpam.loginResult()
print "KIKIL 1 OK"

satpam2 = LINETCR.LINE()
satpam2.login(token=token21)
satpam2.loginResult()
print "KIKIL2 SUKSES"

sd = LINETCR.LINE()
sd.login(token=token22)
sd.loginResult()

print "LOGIN COMPLITE SIRI V10 START"
print "login success Bro.."
print "_______________________"
print "___________________"
print "_____________"
print ""
print"__            ___________88o_____o88888888"
print "_______________________o888o___o8888888888"
print "_______o888ooo________o8888o_888888888888"
print "__ooo8888888888888___88888888888888888888"
print "___*88888888888888o_88888888888888888888"
print "___o8888888888888__88888888888888888888"
print "__o8888888888888__88888888888888888888"
print "___88888888888*__888888888888888888*"
print "______*88888*___888888888888888*"
print "_______888888__88888888888888*"
print "______o88888888888888888888*"
print "____o888888888888888888888888888888888888888oo"
print "___8888888888888888888888888888888888888888888o"
print "_o8888888888888888888888888888888888888888888*"
print "888888888888888888888888888888888888888888**"
print "*8888888888888888888888888888888**"
print "_*88888888888*_88888"
print "__8888888888____88888o"
print "__8888888888_____88888o"
print "__*888888888o_____88888o"
print "___88888888888_____*8888o"
print "___*888888888888o___*8888o"
print "____*8888888888888o___*888o"
print "_____*88888888888888____8888"
print "_______8888888888888o____*888"
print "________888888888888______*888o"
print "_________8888888888*_______*8888"
print "_________*8888888888oo______*888"
print "__________*8888888888888o"
print "___________*88888888888888o"
print "____________*888888888888888o"
print "______________88888888___8888o"
print "_______________8888888_o88888"
print "_______________*8888888888*"
print "_________________8888888*"
print "__________________88888888888o"
print "___________________88888888__o"
print "____________________8888888o"
print "_____________________8888888"
print "______________________8888888"
print "______________________*8888888"
print "______________________888888888oo"
print "______________________888__888888o"
print "_____________________o88___88888"
print "_____________________*_____8888"
print "__________________________o"
print "BOT SIRI REALOADED.2.0 AKUN"

reload(sys)
sys.setdefaultencoding('utf-8')

helpMessage =""" しりちゃん Siri Help (English)
═════════════════════
╠❂͜͡➣  Siri:help
╠❂͜͡➣  [Gift]
╠❂͜͡➣  Ginfo
╠❂͜͡➣  Welcome
╠❂͜͡➣  Creator /Creators
╠❂͜͡➣  Owner (Cek owner)
╠❂͜͡➣  Admin /adminlist List
╠❂͜͡➣  Set:changeowner @
╠❂͜͡➣  Siri contact (Bot siri list)
╠❂͜͡➣  Setlastpoint [Viewlastseen]
╠❂͜͡➣  Cctv   [Sider] Setpoint
╠❂͜͡➣  vielastseen[View sider]
╠❂͜͡➣  Setlast    Viewlast
╠❂͜͡➣ Me  (kontak self]
╠❂͜͡➣ Setlastpoint
╠❂͜͡➣ Viewlastseen
╠❂͜͡➣ Set help
════════════════════


════════════════════
╠❂͜͡➣ Mid siri
╠❂͜͡➣ Invite: (You must have Mid contact)
╠❂͜͡➣ Mid @ (check MID by tag)
╠❂͜͡➣ Cancel/Siri:Cancel/Siri cancel invite
╠❂͜͡➣ Steal contact  (send contact view)
╠❂͜͡➣ Steal mid
╠❂͜͡➣ Siri「Open qr/Siri Close」qr
╠❂͜͡➣ Bot sider masuk (undang bot sider)
╠❂͜͡➣ Bye bot sider (Keluarkan bot sider)
╠❂͜͡➣ Masuk  Line.me/ti....
╠❂͜͡➣ Speed/Sp
╠❂͜͡➣ Set check
╠❂͜͡➣ Help/Key
╠❂͜͡➣ Stealdp @
╠❂͜͡➣ Stealhome @
╠❂͜͡➣ Music
╠❂͜͡➣ Set:check
╠❂͜͡➣ Gurl
╠❂͜͡➣ Midd @
╠❂͜͡➣ Pp @ pp @ 
╠❂͜͡➣ Cover @ cover @
╠❂͜͡➣ Clock [On/Off」
╠❂͜͡➣ Tag all/Tagall
╠❂͜͡➣ Absen/Respon
╠❂͜͡➣ Ban (Banned send contact)
╠❂͜͡➣ Unban (Delete Banned)
╠❂͜͡➣ Ban @ ( Banned via tag)
╠❂͜͡➣ Clear (Netral)
╠❂͜͡➣ Kill ban  (Kick Banned)
╠❂͜͡➣ Banlist
╠❂͜͡➣ Siri gn (Gname select)
╠❂͜͡➣ Siri tag/Tag
╠❂͜͡➣ Group name  (Change name Group)
═══════════════════════


═══════════════════════
╠❂͜͡➣ Getprofile kirim kontak
╠❂͜͡➣ Getgroup image
╠❂͜͡➣ HAJAR @
╠❂͜͡➣ Kill @
╠❂͜͡➣ Spam @
╠❂͜͡➣ StealG
╠❂͜͡➣ Copy6 @ 5 siri copy
╠❂͜͡➣ Copy1-5 @  -  Backup1-7 /Back1-7
╠❂͜͡➣ Backup1-7 Back1-7
╠❂͜͡➣ All backup","All back
╠❂͜͡➣ Op copy @ - All op backup/ All op back
╠❂͜͡➣ Set invite /Siri invite(By contact)
╠❂͜͡➣ Siri:on /Off
╠❂͜͡➣ Siri1 on
╠❂͜͡➣ Siri:Bye /Siri:bye
╠❂͜͡➣ Siri login (invite siri Eliza,Rakko)
╠❂͜͡➣ Add optional (invite 20siri)
╠❂͜͡➣ Like teman
╠❂͜͡➣ Bye siri1/2/3
╠❂͜͡➣ Siri:reinvite/Siri reinvite
╠❂͜͡➣ Unban (delete banned)
╠❂͜͡➣ Siri like
╠❂͜͡➣ Siri remove @ (remov admin)
╠❂͜͡➣ Set:Changeowner  (add Admin)
╠❂͜͡➣ Siri add (add frend)
╠❂͜͡➣ Siri bom
╠❂͜͡➣ List of siri (daftar,siri)
╠❂͜͡➣ Memberlist
╠❂͜͡➣ Group list
╠❂͜͡➣ Steal group pict
╠❂͜͡➣ Fancytext:
╠❂͜͡➣ Kedipkedip
╠❂͜͡➣ Invite me
╠❂͜͡➣ Searchid:  (cari idline via tag)
╠❂͜͡➣ list group
╠❂͜͡➣ ListGr   / LG2 cek group
╠❂͜͡➣ Siri backup    Siri:backup
╠❂͜͡➣ Remove all chat
╠❂͜͡➣ Unicode   (spam unicode)
╠❂͜͡➣ CRASH  /BLANK
╠❂͜͡➣ Recover (clone grup)
╠❂͜͡➣ Backup on / off  (backup grup)
╠❂͜͡➣ Restart /Reboot
╠❂͜͡➣ Turn off
╠❂͜͡➣ Siri login
╠❂͜͡➣ Siri:reinvite  Siri reinvite
╠❂͜͡➣ Add optional
╠❂͜͡➣ Siri bye
╠❂͜͡➣ Siri kicker
╠❂͜͡➣ Option bye
╠❂͜͡➣ BUBARKAN!
╠═════════════════════
╠   line.me/ti/p/~anto_sahaja
╠   http://sirichan.xyz/
╚═════════════════════
"""
KAC=[cl,ki,kk,kc,ks,ka,kb,ko,ke,ku,km,kr,kd,kw,kn,kt,ky,kh,kz]
DEF=[ki,kk,kc,ks,ka,kb,ko,ke,ku,kr,km,kd,kw,satpam,satpam2]
Bots=[cl,ki,kk,kc,ks,ka,kb,ko,ke,ku,km,kr,kd,kw,kn,kt,ky,kh,kz,satpam,satpam2,sd]
DEF2=[ki,kk,kc,ks]

mid = cl.getProfile().mid
Amid = ki.getProfile().mid
Bmid = kk.getProfile().mid
Cmid = kc.getProfile().mid
Dmid = ks.getProfile().mid
Emid = ka.getProfile().mid
Fmid = kb.getProfile().mid
Gmid = ko.getProfile().mid
Hmid = ke.getProfile().mid
Imid = ku.getProfile().mid
Jmid = km.getProfile().mid
Kmid = kr.getProfile().mid
Lmid = kd.getProfile().mid
Mmid = kw.getProfile().mid
Nmid = kn.getProfile().mid
Omid = kt.getProfile().mid
Pmid = ky.getProfile().mid
Qmid = kh.getProfile().mid
Rmid = kz.getProfile().mid
Smid = satpam.getProfile().mid
Tmid = satpam2.getProfile().mid
Umid = sd.getProfile().mid

owner=["uab7c6852cbf418f0cc1d0c62c1301737"] #193
#owner=["u1e41ac41ef958c9123e4277504a01da8"]#pngeran koyn id
#mid bokir ub542d871ea20170d941cc026c27eb4e6
#mid akun asli  "ufb484c768b5da9de91722b2cf5a19cd3"]hapus akun                                                                   #AKU VAKUM                   #Wanoja                   #AKU pngern koyn id         AKU                             #DEVIL                            #NAYA                                 #MEY                                #TRIANI                        #kimamel
Bots=[mid,Amid,Bmid,Cmid,Dmid,Emid,Fmid,Gmid,Hmid,Imid,Jmid,Kmid,Lmid,Mmid,Nmid,Omid,Pmid,Qmid,Rmid,Smid,Tmid,Umid,"ub542d871ea20170d941cc026c27eb4e6","u675167dda1e2fd0762d0c613e596f68f","u1e41ac41ef958c9123e4277504a01da8","uab7c6852cbf418f0cc1d0c62c1301737","u3e1d2cd40d0c5f68dc952a7ac0666647","u16e06c9c5eff8a91f8be33aa57e1cc29","u72ee4dc03405e25ad6d642f17b752b75","uc9c21e28fd742033003466b50228ae87","uae31cdd7019a9093ed82120f54b5701e"]
admin=["ub542d871ea20170d941cc026c27eb4e6","u675167dda1e2fd0762d0c613e596f68f","u1e41ac41ef958c9123e4277504a01da8","uab7c6852cbf418f0cc1d0c62c1301737","u3e1d2cd40d0c5f68dc952a7ac0666647","u16e06c9c5eff8a91f8be33aa57e1cc29","u72ee4dc03405e25ad6d642f17b752b75","uc9c21e28fd742033003466b50228ae87","uae31cdd7019a9093ed82120f54b5701e"]
#owner=["ub542d871ea20170d941cc026c27eb4e6"]

name1 = cl.getProfile().displayName
name2 = ki.getProfile().displayName
name3 = kk.getProfile().displayName
name4 = kc.getProfile().displayName
name5 = ks.getProfile().displayName
name6 = ka.getProfile().displayName
name7 = kb.getProfile().displayName
name8 = ko.getProfile().displayName
name9 = ke.getProfile().displayName
name10 = ku.getProfile().displayName
name11 = km.getProfile().displayName
name12 = kr.getProfile().displayName
name13 = kd.getProfile().displayName
name14 = kw.getProfile().displayName
name15 = kn.getProfile().displayName
name16 = kt.getProfile().displayName
name17 = ky.getProfile().displayName
name18 = kh.getProfile().displayName
name19 = kz.getProfile().displayName
name20 = sd.getProfile().displayName

wait = {
    'contact':True,
    'autoJoin':True,
    'autoCancel':{"on":True,"members":1},
    'leaveRoom':True,
    'timeline':False,
    'autoAdd':False,
    'message':"Thanks for add me",
    "lang":"JP",
    "comment":"Thanks for add me",
    "commentOn":False,
    "commentBlack":{},
    "wblack":False,
    "dblack":False,
    "clock":False,
    "cName":'159',
    "cName2":"Parry v10",
    "cName3":"Rakko v10",
    "cName4":"Doctor.A v10",
    "cName5":"Eliza v10",
    "cName6":"しりちゃん追加保護ボット4400",
    "cName7":"しりちゃん追加保護ボット4401",
    "cName8":"しりちゃん追加保護ボット4402",
    "cName9":"しりちゃん追加保護ボット4403",
    "cName10":"しりちゃん追加保護ボット4404",
    "cName11":"しりちゃん追加保護ボット4405",
    "cName12":"しりちゃん追加保護ボット4406",
    "cName13":"しりちゃん追加保護ボット4407",
    "cName14":"しりちゃん追加保護ボット4408",
    "cName15":"しりちゃん追加保護ボット4409",
    "cName16":"しりちゃん追加保護ボット4410",
    "cName17":"しりちゃん追加保護ボット4411",
    "cName18":"しりちゃん追加保護ボット4412",
    "cName19":"しりちゃんkicker&復旧アカ55",
    "cName20":"しりちゃんkicker&復旧アカ59",
    "blacklist":{"u739c25d186d3be8a02c70d7997f1c48a","u1b8d2297e1dd687e15060a94373a2845","ue93f96985cbf8944b7e14fe097768d7a","u3e08e7e5c5eeec3659e313d54b192a9b","ua14b07a7a1fecf1cb3be382c108f394d","ua4bb37dcce8488b3760eedf6a6434732","u2c46d771313c3cac2fbe644ffbd21edd","u514274dd5bafac72ff0b392443d86b2c","u3af99fee337072482d90512398c4b38f"},
    "wblacklist":False,
    "dblacklist":False,
    "Protectgr":True,
    "Protectjoin":False,
    "Protectcancl":True,
    "protectionOn":True,
    "atjointicket":True,
    "sayWelcome":False,
    "welcom":True,
    "winvite":False,
    "winvite2":False,
    "chat":True,
    "alwaysRead":False,
    "tag":True,
    "autoInvite":True,
    "sider":{},
    }

wait2 = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{}
    }

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
    }

pesan = {
     "sider1":"\nHai kk..Baru datang ya..,sini kak chat",
     "sider2":"\nHalo kk...sider aja nih 😂😃\nSini donk gabung chat..",
     "sider3":"\nCieee...ketahuan ngintip..\nSini dong rame in rom nya",
    }

setTime = {}
setTime = wait2['setTime']
mulai = time.time()

dangerMessage = ["Kick:on","Kick","Kick @","Kick on","cleanse","group cleansed",".winebot","kickall","mayhem","kick on","makasih :d","!kickall","nuke","Kickall","Mayhem"]

#-----5 BOT BACKUP-----#
contact = cl.getProfile()
backupX1 = cl.getProfile()
backupX1.displayName = contact.displayName
backupX1.statusMessage = contact.statusMessage
backupX1.pictureStatus = contact.pictureStatus

contact = ki.getProfile()
backupX2 = ki.getProfile()
backupX2.displayName = contact.displayName
backupX2.statusMessage = contact.statusMessage
backupX2.pictureStatus = contact.pictureStatus

contact = kk.getProfile()
backupX3 = kk.getProfile()
backupX3.displayName = contact.displayName
backupX3.statusMessage = contact.statusMessage
backupX3.pictureStatus = contact.pictureStatus

contact = kc.getProfile()
backupX4 = kc.getProfile()
backupX4.displayName = contact.displayName
backupX4.statusMessage = contact.statusMessage
backupX4.pictureStatus = contact.pictureStatus

contact = ks.getProfile()
backupX5 = ks.getProfile()
backupX5.displayName = contact.displayName
backupX5.statusMessage = contact.statusMessage
backupX5.pictureStatus = contact.pictureStatus

#-------OPTION BACKUP-------#
contact = ka.getProfile()
backupX6 = ka.getProfile()
backupX6.displayName = contact.displayName
backupX6.statusMessage = contact.statusMessage
backupX6.pictureStatus = contact.pictureStatus

contact = kb.getProfile()
backupX7 = kb.getProfile()
backupX7.displayName = contact.displayName
backupX7.statusMessage = contact.statusMessage
backupX7.pictureStatus = contact.pictureStatus

contact = ko.getProfile()
backupX8 = ko.getProfile()
backupX8.displayName = contact.displayName
backupX8.statusMessage = contact.statusMessage
backupX8.pictureStatus = contact.pictureStatus

contact = ke.getProfile()
backupX9 = ke.getProfile()
backupX9.displayName = contact.displayName
backupX9.statusMessage = contact.statusMessage
backupX9.pictureStatus = contact.pictureStatus

contact = ku.getProfile()
backupX10 = ku.getProfile()
backupX10.displayName = contact.displayName
backupX10.statusMessage = contact.statusMessage
backupX10.pictureStatus = contact.pictureStatus

contact = km.getProfile()
backupX11 = km.getProfile()
backupX11.displayName = contact.displayName
backupX11.statusMessage = contact.statusMessage
backupX11.pictureStatus = contact.pictureStatus

contact = kr.getProfile()
backupX12 = kr.getProfile()
backupX12.displayName = contact.displayName
backupX12.statusMessage = contact.statusMessage
backupX12.pictureStatus = contact.pictureStatus

contact = kd.getProfile()
backupX13 = kd.getProfile()
backupX13.displayName = contact.displayName
backupX13.statusMessage = contact.statusMessage
backupX13.pictureStatus = contact.pictureStatus

contact = kw.getProfile()
backupX14 = kw.getProfile()
backupX14.displayName = contact.displayName
backupX14.statusMessage = contact.statusMessage
backupX14.pictureStatus = contact.pictureStatus

contact = kn.getProfile()
backupX15 = kn.getProfile()
backupX15.displayName = contact.displayName
backupX15.statusMessage = contact.statusMessage
backupX15.pictureStatus = contact.pictureStatus

contact = kt.getProfile()
backupX16 = kt.getProfile()
backupX16.displayName = contact.displayName
backupX16.statusMessage = contact.statusMessage
backupX16.pictureStatus = contact.pictureStatus

contact = ky.getProfile()
backupX17 = ky.getProfile()
backupX17.displayName = contact.displayName
backupX17.statusMessage = contact.statusMessage
backupX17.pictureStatus = contact.pictureStatus

contact = kh.getProfile()
backupX18 = kh.getProfile()
backupX18.displayName = contact.displayName
backupX18.statusMessage = contact.statusMessage
backupX18.pictureStatus = contact.pictureStatus

contact = kz.getProfile()
backupX19 = kz.getProfile()
backupX19.displayName = contact.displayName
backupX19.statusMessage = contact.statusMessage
backupX19.pictureStatus = contact.pictureStatus

contact = satpam.getProfile()
backupX20 = satpam.getProfile()
backupX20.displayName = contact.displayName
backupX20.statusMessage = contact.statusMessage
backupX20.pictureStatus = contact.pictureStatus

def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

def download_page(url):
    version = (3,0)                                                                           
    cur_version = sys.version_info
    if cur_version >= version:     #If the Current Version of Python is 3.0 or above
        import urllib,request    #urllib library for Extracting web pages
        try:
            headers = {}                                                                              
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)                                                        
            respData = str(resp.read())
            return respData                                                                       
        except Exception as e:                                                                        
            print(str(e))
    else:                        #If the Current Version of Python is 2.x
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

def _images_get_next_item(s):
    start_line = s.find('rg_di')
    if start_line == -1:    #If no links are found then give an error!
        end_quote = 0
        link = "no_links"
        return link, end_quote
    else:
        start_line = s.find('"class="rg_meta"')
        start_content = s.find('"ou"',start_line+90)
        end_content = s.find(',"ow"',start_content-90)
        content_raw = str(s[start_content+6:end_content-1])
        return content_raw, end_content

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      #Append all the links in the list named 'Links'
            time.sleep(0.1)        #Timer could be used to slow down the request for image download
            page = page[end_content:]
    return items

def upload_tempimage(client):
     '''
         Upload a picture of a kitten. We don't ship one, so get creative!
     '''
     config = {                                                                                                                  
         'album': album,
         'name':  'bot auto upload',
         'title': 'bot auto upload',
         'description': 'bot auto upload'
     }                                                                                                                  
     print("Uploading image... ")
     image = client.upload_from_path(image_path, config=config, anon=False)                                                  
     print("Done")
     print()

     return image

def sendMessage(to, text, contentMetadata={}, contentType=0):
    msg = Message()
    msg.to, msg.from_ = to, profile.mid
    msg.text = text
    msg.contentType, msg.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

def yt(query):
    with requests.session() as s:
         isi = []
         if query == "":                                                                                                             
             query = "S1B tanysyz"
         s.headers['user-agent'] = 'Mozilla/5.0'
         url    = 'http://www.youtube.com/results'
         params = {'search_query': query}
         r    = s.get(url, params=params)
         soup = BeautifulSoup(r.content, 'html5lib')
         for a in soup.select('.yt-lockup-title > a[title]'):                                                                       
            if '&list=' not in a['href']:
                if 'watch?v' in a['href']:
                    b = a['href'].replace('watch?v=', '')
                    isi += ['youtu.be' + b]
         return isi

def sendImage(self, to_, path):
        M = Message(to=to_,contentType = 1)
        M.contentMetadata = None
        M.contentPreview = None
        M_id = self._client.sendMessage(M).id
        files = {
            'file': open(path, 'rb'),                                                                                           
        }
        params = {
            'name': 'media',
            'oid': M_id,
            'size': len(open(path, 'rb').read()),
            'type': 'image',
            'ver': '1.0',                                                                                                       
        }
        data = {
            'params': json.dumps(params)
        }
        r = self._client.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Upload image failure.')                                                                           
        #r.content
        return True

def sendImage2(self, to_, path):
      M = Message(to=to_,contentType = 1)
      M.contentMetadata = None
      M.contentPreview = None
      M_id = self._client.sendMessage(M).id
      files = {
         'file': open(path, 'rb'),
      }
      params = {
         'name': 'media',
         'oid': M_id,
         'size': len(open(path, 'rb').read()),
         'type': 'image',
         'ver': '1.0',
      }
      data = {
         'params': json.dumps(params)                                                                                         
      }
      r = self._client.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
      if r.status_code != 201:
          raise Exception('Upload image failure.')
      return True


def sendAudio(self, to_, path):                                                                                                 
        M = Message(to=to_, text=None, contentType = 3)
        M.contentMetadata = None
        M.contentPreview = None
        M2 = self.Talk.client.sendMessage(0,M)
        M_id = M2.id
        files = {
            'file': open(path, 'rb'),
        }
        params = {
            'name': 'media',
            'oid': M_id,
            'size': len(open(path, 'rb').read()),
            'type': 'audio',
            'ver': '1.0',
        }
        data = {
            'params': json.dumps(params)
        }
        r = self.post_content('https://obs-sg.line-apps.com/talk/m/upload.nhn', data=data, files=files)
        if r.status_code != 201:                                                                                                    
            raise Exception('Upload audio failure.')
        return True

def sendImageWithURL(self, to_, url):
      path = '%s/pythonLine-%i.data' % (tempfile.gettempdir(), randint(0, 9))
      r = requests.get(url, stream=True)
      if r.status_code == 200:
         with open(path, 'w') as f:
            shutil.copyfileobj(r.raw, f)
      else:
         raise Exception('Download image failure.')
         try:
             self.sendImage(to_, path)
         except Exception as e:
             raise e

def sendAudioWithURL(self, to_, url):
      path = '%s/pythonLine-%i.data' % (tempfile.gettempdir(), randint(0, 9))                                                 
      r = requests.get(url, stream=True)
      if r.status_code == 200:
          with open(path, 'wb') as f:
            r.raw.decode_content = True
            shutil.copyfileobj(r.raw, f)
      else:
          raise Exception('Download Audio failure.')
      try:
          self.sendAudio(to_, path)
      except Exception as e:
        print e

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    return '%02d Jam %02d Menit %02d Detik' % (hours, mins, secs)

def post_content(self, urls, data=None, files=None):
        return self._session.post(urls, headers=self._headers, data=data, files=files)                          
def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾","サテラ:","サテラ:","サテラ：","サテラ："]
    for tex in tex:
      for command in commands:
        if string ==command:
          return True

def removeAllMessages(self, lastMessageId):
     return self._client.removeAllMessages(0, lastMessageId)

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

def bot(op):
     try:
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                cl.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    cl.sendText(op.param1,str(wait["message"]))
                    print "AUTO ADD"

        #------Protect Group Kick start------#
        if op.type == 11:
           if wait["Protectgr"] == True:
               if op.param2 not in Bots:
                   G = random.choice(KAC).getGroup(op.param1)
                   G.preventJoinByTicket = False
                   random.choice(KAC).updateGroup(G)
                   Ticket = random.choice(KAC).reissueGroupTicket(op.param1)
                   satpam.acceptGroupInvitationByTicket(op.param1,Ticket)
                   satpam2.acceptGroupInvitationByTicket(op.param1,Ticket)
                   satpam.kickoutFromGroup(op.param1,[op.param2])
                   satpam2.kickoutFromGroup(op.param1,[op.param2])
                   G = random.choice(KAC).getGroup(op.param1)
                   G.preventJoinByTicket = True
                   random.choice(KAC).updateGroup(G)
                   satpam.leaveGroup(op.param1)
                   satpam2.leaveGroup(op.param1)
                   cl.sendText(op.param1, cl.getContact(op.param2).displayName + "   ☡  \n招待URLを変更したユーザがいたため、一時退出させました（´・ω・｀）\n退出させたユーザは一時的にブラックリストに入ったので再招待する際は、一時間以上まってから行ってね\n\n"+datetime.today().strftime('%H:%M:%S'))
                   wait['blacklist'][op.param2] == True
                   print "QR DI BUKA - BOT NGKICK KIKIL"
              
        #------Protect Group Kick finish-----#

        #------Cancel Invite User start------#
        if op.type == 13:
           if wait["Protectcancl"] == True:
               if op.param2 not in Bots:
                  group = ka.getGroup(op.param1)
                  gMembMids = [contact.mid for contact in group.invitee]
                  random.choice(DEF).cancelGroupInvitation(op.param1, gMembMids)
                  print "MEMBER DI INVIT AUTO CANCEL AKTIF"
        #------Cancel Invite User Finish------#
            
        if op.type == 13:
            if op.param3 in mid:
                if op.param2 in Amid:
                    G = Amid.getGroup(op.param1)
                    G.preventJoinByTicket = False
                    Amid.updateGroup(G)
                    Ticket = Amid.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                    G.preventJoinByTicket = True
                    Amid.updateGroup(G)
                    Ticket = Amid.reissueGroupTicket(op.param1)

            if op.param3 in Amid:
                if op.param2 in mid:
                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ki.updateGroup(X)
                    Ti = ki.reissueGroupTicket(op.param1)

            if op.param3 in Bmid:
                if op.param2 in Amid:
                    X = ki.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ki.updateGroup(X)
                    Ti = ki.reissueGroupTicket(op.param1)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kk.updateGroup(X)
                    Ti = kk.reissueGroupTicket(op.param1)

            if op.param3 in Cmid:
                if op.param2 in Bmid:
                    X = kk.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kk.updateGroup(X)
                    Ti = kk.reissueGroupTicket(op.param1)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kc.updateGroup(X)
                    Ti = kc.reissueGroupTicket(op.param1)
                
            if op.param3 in Dmid:
                if op.param2 in Cmid:
                    X = kc.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kc.updateGroup(X)
                    Ti = kc.reissueGroupTicket(op.param1)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ks.updateGroup(X)
                    Ti = ks.reissueGroupTicket(op.param1)
                
            if op.param3 in Emid:
                if op.param2 in Dmid:
                    X = ks.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ks.updateGroup(X)
                    Ti = ks.reissueGroupTicket(op.param1)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ka.updateGroup(X)
                    Ti = ka.reissueGroupTicket(op.param1)
                
            if op.param3 in Fmid:
                if op.param2 in Emid:
                    X = ka.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ka.updateGroup(X)
                    Ti = ka.reissueGroupTicket(op.param1)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kb.updateGroup(X)
                    Ti = kb.reissueGroupTicket(op.param1)
                
            if op.param3 in Gmid:
                if op.param2 in Fmid:
                    X = kb.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kb.updateGroup(X)
                    Ti = kb.reissueGroupTicket(op.param1)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ko.updateGroup(X)
                    Ti = ko.reissueGroupTicket(op.param1)
                
            if op.param3 in Hmid:
                if op.param2 in Gmid:
                    X = ko.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ko.updateGroup(X)
                    Ti = ko.reissueGroupTicket(op.param1)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ke.updateGroup(X)
                    Ti = ke.reissueGroupTicket(op.param1)
                    
            if op.param3 in Imid:
                if op.param2 in Hmid:
                    X = ke.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ke.updateGroup(X)
                    Ti = ke.reissueGroupTicket(op.param1)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ku.updateGroup(X)
                    Ti = ku.reissueGroupTicket(op.param1)
                    
            if op.param3 in Jmid:
                if op.param2 in Imid:
                    X = ku.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ku.updateGroup(X)
                    Ti = ku.reissueGroupTicket(op.param1)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    km.updateGroup(X)
                    Ti = km.reissueGroupTicket(op.param1)
                    
            if op.param3 in Kmid:
                if op.param2 in Jmid:
                    X = km.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    km.updateGroup(X)
                    Ti = km.reissueGroupTicket(op.param1)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kr.updateGroup(X)
                    Ti = kr.reissueGroupTicket(op.param1)
                    
            if op.param3 in Lmid:
                if op.param2 in Kmid:
                    X = kr.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kr.updateGroup(X)
                    Ti = kr.reissueGroupTicket(op.param1)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kd.updateGroup(X)
                    Ti = kd.reissueGroupTicket(op.param1)
                    
            if op.param3 in Mmid:
                if op.param2 in Lmid:
                    X = kd.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kd.updateGroup(X)
                    Ti = kd.reissueGroupTicket(op.param1)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kw.updateGroup(X)
                    Ti = kw.reissueGroupTicket(op.param1) 
                    
            if op.param3 in Nmid:
                if op.param2 in Mmid:
                    X = kw.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kw.updateGroup(X)
                    Ti = kw.reissueGroupTicket(op.param1)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kn.updateGroup(X)
                    Ti = kn.reissueGroupTicket(op.param1)
                    
            if op.param3 in Omid:
                if op.param2 in Nmid:
                    X = kn.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kn.updateGroup(X)
                    Ti = kn.reissueGroupTicket(op.param1)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kt.updateGroup(X)
                    Ti = kt.reissueGroupTicket(op.param1)
                    
            if op.param3 in Pmid:
                if op.param2 in Omid:
                    X = kt .getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kt.updateGroup(X)
                    Ti = kt.reissueGroupTicket(op.param1)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ky.updateGroup(X)
                    Ti = ky.reissueGroupTicket(op.param1)
                  
            if op.param3 in Qmid:
                if op.param2 in Pmid:
                    X = ky.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ky.updateGroup(X)
                    Ti = ky.reissueGroupTicket(op.param1)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kh.updateGroup(X)
                    Ti = kh.reissueGroupTicket(op.param1)
                    
            if op.param3 in Rmid:
                if op.param2 in Qmid:
                    X = kh.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kh.updateGroup(X)
                    Ti = kh.reissueGroupTicket(op.param1)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kz.updateGroup(X)
                    Ti = kz.reissueGroupTicket(op.param1)
                    
            if op.param3 in Umid:
                if op.param2 in mid:
                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    sd.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    
            if op.param3 in mid:
                if op.param2 in Pmid:
                    X = ky.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ky.updateGroup(X)
                    Ti = ky.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    
            if op.param3 in mid:
                if op.param2 in Qmid:
                    X = kt.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kt.updateGroup(X)
                    Ti = kt.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    
            if op.param3 in mid:
                if op.param2 in Mmid:
                    X = kw.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    Ti = kw.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    
            if op.param3 in Amid:
                if op.param2 in Pmid:
                    X = ky.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ky.updateGroup(X)
                    Ti = ky.reissueGroupTicket(op.param1)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    
            if op.param3 in Amid:
                if op.param2 in Qmid:
                    X = kt.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kt.updateGroup(X)
                    Ti = kt.reissueGroupTicket(op.param1)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    
            if op.param3 in Bmid:
                if op.param2 in Pmid:
                    X = ky.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ky.updateGroup(X)
                    Ti = ky.reissueGroupTicket(op.param1)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    
            if op.param3 in Bmid:
                if op.param2 in Qmid:
                    X = kt.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kt.updateGroup(X)
                    Ti = kt.reissueGroupTicket(op.param1)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    
            if op.param3 in Cmid:
                if op.param2 in Pmid:
                    X = ky.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ky.updateGroup(X)
                    Ti = ky.reissueGroupTicket(op.param1)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    
            if op.param3 in Cmid:
                if op.param2 in Qmid:
                    X = kt.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kt.updateGroup(X)
                    Ti = kt.reissueGroupTicket(op.param1)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
    
        if op.type == 13:
            print op.param1
            print op.param2
            print op.param3
            if mid in op.param3:
                G = cl.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, matched_list)
                    
        #------Joined User Kick start------#
        if op.type == 17:
            if wait["Protectjoin"] == True:
              if op.param2 not in Bots:
                   random.choice(DEF).kickoutFromGroup(op.param1,[op.param2])
                   print "KICK MEMBER JOIN / BLOCK INVITE SEDANG ON"
        if op.type == 17:
            if wait["autoInvite"] == True:
              if op.param2 in admin:
                  return
              random.choice(DEF2).inviteIntoGroup(op.param1,[op.param3])
              print "MEMBER DI INVIT VIA CONTACT"

        if op.type == 17:
            if wait["sayWelcome"] == True:
              if op.param2 in Bots:
                  return
              ginfo = cl.getGroup(op.param1)
              contact = cl.getContact(op.param2)
              gCreator = ginfo.Creator.displayName
              image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
              cl.sendText(op.param1,"HAI KAK " + cl.getContact(op.param2).displayName + "\nWELCOME TO" + str(ginfo.name) + "\nBudayakan Cek Note\nDan Semoga Betah kk😆👌 ^_^\n\nCreator Group  :" + gCreator)
              cl.sendImageWithURL(op.param1,image)
              print "MEMBER JOIN TO GROUP"
  
        if op.type == 15:
            if wait["sayWelcome"] == True:
              if op.param2 in Bots:
                  return
              ginfo = cl.getGroup(op.param1)
              contact = cl.getContact(op.param2)
              cl.sendText(op.param1,"Good Bye " + cl.getContact(op.param2).displayName +  "\nJangan lupa Nextime Mampir lagi ke Room :" + str(ginfo.nane))
              #random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
              print "MEMBER HAS LEFT THE GROUP"
        #------Joined User Kick start------#
        
        if op.type == 19:
           if op.param2 not in Bots:
              print "MEMBER NG KICK MEMBER / BOT"
              random.choice(DEF).kickoutFromGroup(op.param1,[op.param2])
              random.choice(DEF).inviteIntoGroup(op.param1,[op.param3])
           else: 
               pass
        if op.type == 19:
           if op.param3 in admin:
               print "ADMIN DI KICK / LISA KICKER STANDBY"
               G = random.choice(KAC).getGroup(op.param1)
               G.preventJoinByTicket = False
               random.choice(KAC).updateGroup(G)
               Ticket = random.choice(KAC).reissueGroupTicket(op.param1)                                         
               satpam.acceptGroupInvitationByTicket(op.param1,Ticket)
               satpam2.acceptGroupInvitationByTicket(op.param1,Ticket)
               satpam2.inviteIntoGroup(op.param1,admin)
               satpam.kickoutFromGroup(op.param1,[op.param2])
               satpa2.inviteIntoGroup(op.param1,[op.param3])
               G.preventJoinByTicket = True                                                                      
               satpam.updateGroup(G)
               Ticket = satpam.reissueGroupTicket(op.param1)
               satpam.leaveGroup(op.param1)
               satpam2.leaveGroup(op.param1)
               random.choice(KAC).updateGroup(op.param1)
               kc.sendText(op.param1,"招待されたユーザの中に、ブラックリ\nストユーザとして認識されいる人がい\nたから、招待を取り消したよ(｀・ω・´)\n招待したユーザは一時的にブラックリ\nストに入ったので一時間以上まってから再招待してね☆\n\n"+datetime.today().strftime('%H:%M:%S'))
               c = Message(to=op.param1, from_=None, text=None, contentType=13)
               c.contentMetadata={'mid':op.param2}
               kc.sendMessage(c)
               wait["blacklist"][op.param2] = True
           else:
               pass

        if op.type == 19:
                if mid in op.param3:
                     if op.param2 in Bots:
                         pass
                     try:
                         G = random.choice(KAC).getGroup(op.param1)                                                        
                         G.preventJoinByTicket = False
                         random.choice(KAC).updateGroup(G)
                         Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                         satpam2.acceptGroupInvitationByTicket(op.param1,Ti)
                         satpam2.kickoutFromGroup(op.param1,[op.param2])
                         G = random.choice(KAC).getGroup(op.param1)
                         G.preventJoinByTicket = False
                         random.choice(KAC).updateGroup(G)
                         Ticket = random.choice(KAC).reissueGroupTicket(op.param1)
                         cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                         G = kk.getGroup(op.param1)
                         G.preventJoinByTicket = True
                         kk.updateGroup(G)
                         kc.sendText(op.param1,"招待されたユーザの中に、ブラックリ\nストユーザとして認識されいる人がい\nたから、招待を取り消したよ(｀・ω・´)\n招待したユーザは一時的にブラックリ\nストに入ったので一時間以上まってから再招待してね☆\n\n"+datetime.today().strftime('%H:%M:%S'))
                         c = Message(to=op.param1, from_=None, text=None, contentType=13)
                         c.contentMetadata={'mid':op.param2}
                         kc.sendMessage(c)
                         wait["blacklist"][op.param2] = True
                         print "AKUN BOT1 DI KICK / LISA KIKIL MASUK ROOM"
                     except:
                         pass
        
 
                if Amid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                        print "BOT 2 DI KICK"
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ki.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ki.updateGroup(G)
                    Ticket = ki.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Bmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT3 DI KICK"
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kk.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kk.updateGroup(G)
                    Ticket = kk.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Cmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 4 DI KICK"
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        kk.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kc.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kc.updateGroup(G)
                    Ticket = kc.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                
                if Dmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            print "BOT 5 DI KICK"
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ks.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ks.updateGroup(G)
                    Ticket = ks.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        
                if Emid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 6 DI KICK"
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                            
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ka.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ka.updateGroup(G)
                    Ticket = ka.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        
                if Fmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 7 DI KICK"
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kb.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kb.updateGroup(G)
                    Ticket = kb.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        
                if Gmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 8 DI KICK"
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ko.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ko.updateGroup(G)
                    Ticket = ko.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        
                if Hmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 9 DI KICK"
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ke.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ke.updateGroup(G)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        
                if Imid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:                        
                        print "BOT 10 DI KICK"
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti) 
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ku.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ku.updateGroup(G)
                    Ticket = ku.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True 
                                   
                if Jmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 11 DI KICK"
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = km.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    km.updateGroup(G)
                    Ticket = km.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True 
                                   
                if Kmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 12 DI KICK"
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kr.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kr.updateGroup(G)
                    Ticket = kr.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                                   
                if Lmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 13 DI KICK"
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti) 
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kd.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kd.updateGroup(G)
                    Ticket = kd.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                if Mmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 14 DI KICK"
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti) 
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kw.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kw.updateGroup(G)
                    Ticket = kw.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True 
                                   
                if Nmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 15 DI KICK"
                        cl.kickoutFromGroup(op.param1,[op.param2])           
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kn.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kn.updateGroup(G)
                    Ticket = kn.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        
                if Omid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 16 DI KICK"
                        cl.kickoutFromGroup(op.param1,[op.param2])           
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True 
                            
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kt.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kt.updateGroup(G)
                    Ticket = kt.reissueGroupTicket(op.param1)    
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True                                    
                            
                if Pmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 17 DI KICK"
                        cl.kickoutFromGroup(op.param1,[op.param2])           
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                            
                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ky.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ky.updateGroup(G)
                    Ticket = ky.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Qmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            print "BOT 18 DI KICK"
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kh.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kh.updateGroup(G)
                    Ticket = kh.reissueGroupTicket(op.param1)    
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Rmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        print "BOT 19 DI KICK"
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)                                                                                                                                                                          
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    km.acceptGroupInvitationByTicket(op.param1,Ti)
                    kr.acceptGroupInvitationByTicket(op.param1,Ti)
                    kd.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kn.acceptGroupInvitationByTicket(op.param1,Ti)
                    kt.acceptGroupInvitationByTicket(op.param1,Ti)
                    ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    kh.acceptGroupInvitationByTicket(op.param1,Ti)
                    kz.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kz.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kz.updateGroup(G)
                    Ticket = kz.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2]  = True

                if op.param3 in mid: #Akun Utama/Selbot Ke Kick
                  G = random.choice(KAC).getGroup(op.param1)
                  G.preventJoinByTicket = False                                                                               
                  random.choice(KAC).updateGroup(G)                                                                                           
                  Ticket = random.choice(KAC).reissueGroupTicket(op.param1)
                  satpam.acceptGroupInvitationByTicket(op.param1,Ticket)
                  satpam2.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  satpam.kickoutFromGroup(op.param1,[op.param2])
                  satpam2.inviteIntoGroup(op.param1,admin)
                  satpam2.inviteIntoGroup(op.param1,[op.param3])
                  G = ki.getGroup(op.param1)
                  G.preventJoinByTicket = False
                  ki.updateGroup(G)
                  ki.reissueGroupTicket(op.param1)
                  cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  G.preventJoinByTicket = True
                  cl.updateGroup(G)
                  satpam.leaveGroup(op.param1)
                  #wait["blacklist"][op.param2] = True
                  print "BOT 1  DI KICK"

                if op.param3 in owner: #Akun ownerKe Kick                                                                     
                  G = random.choice(KAC).getGroup(op.param1)                                                                  
                  G.preventJoinByTicket = False
                  cl.updateGroup(G)                                                                                           
                  Ticket = random.choice(KAC).reissueGroupTicket(op.param1)
                  satpam.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  satpam.kickoutFromGroup(op.param1,[op.param2])
                  G = satpam.getGroup(op.param1)
                  G.preventJoinByTicket = False
                  cl.updateGroup(G)
                  cl.reissueGroupTicket(op.param1)                                                                            
                  admin.acceptGroupInvitationByTicket(op.param1,Ticket)
                  time.sleep(0.01)
                  G.preventJoinByTicket = True                                                                                
                  cl.updateGroup(G)
                  satpam.leaveGroup(op.param1)
                  print "OWNER DI KICK"

                if op.param3 in Smid:
                  satpam2.getGroup(op.param1)
                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                  satpam2.kickoutFromGroup(op.param1,[op.param2])
                  satpam2.leaveFromGroup(op.param1)
                  print "LISA KICKER  DI KICK"
                if op.param3 in Tmid:
                  satpam.getGroup(op.param1)
                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                  satpam.kickoutFromGroup(op.param1,[op.param2])
                  satpam.leaveFromGroup(op.param1)
                  print "LISA KICKER 2 DI KICK"

        if op.type == 13:
            if mid in op.param3:
                G = cl.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, matched_list)
                    
        if op.type == 22:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
        if op.type == 24:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
        if op.type == 26:
            msg = op.message

            if wait["alwaysRead"] == True:
                if msg.toType == 0:
                    cl.sendChatChecked(msg.from_,msg.id)
                else:
                    cl.sendChatChecked(msg.to,msg.id)


        if op.type == 55:
                try:
                    if cctv['cyduk'][op.param1]==True:
                        print "SIDER SEDANG AKTIF"
                        if op.param1 in cctv['point']:
                            Name = sd.getContact(op.param2).displayName
                            if Name in cctv['sidermem'][op.param1]:
                                pass
                            else:
                                cctv['sidermem'][op.param1] += "\n• " + Name
                                if " " in Name:
                                    nick = Name.split(' ')
                                    if len(nick) == 2:
                                        sd.sendText(op.param1, "@"+Name,"" + " \n" + "" + str(pesan["sider1"]))
                                    else:
                                        sd.sendText(op.param1, "@"+Name,"" + " \n" + "" + str(pesan["sider2"]))
                                else:
                                    sd.sendText(op.param1, "@"+Name  + " \n" + "" + str(pesan["sider3"]))
                        else:
                            sd.sendText(op.param1, "Hahaha... " + "☞ " + nick[0]  + " ☜" + "\nBaru dateng ye...!!.\nYuk lah Ramein grupnya (^_-)(-__-)   ")
                    else:
                        pass
                except:
                    pass


        else:
            pass

            if msg.toType == 1:
                if wait["leaveRoom"] == True:
                    cl.leaveRoom(msg.to)
            if msg.contentType == 16:
                url = msg.contentMetadata("line://home/post?userMid="+mid+"&postId="+"new_post")
                cl.like(url[25:58], url[66:], likeType=1001)

        if op.type == 26: #awalnya 26,, utk selfbot jd 25
            msg = op.message
            if msg.contentType == 13:
                if wait["winvite"] == True:
                     if msg.from_ in admin:
                         _name = msg.contentMetadata["displayName"]
                         invite = msg.contentMetadata["mid"]
                         groups = cl.getGroup(msg.to)
                         pending = groups.invitee
                         targets = []
                         for s in groups.members:
                             if _name in s.displayName: 
                                 cl.sendText(msg.to,"-> " + _name + " was here")
                                 break
                             elif invite in wait["blacklist"]:
                                 ki.sendText(msg.to, _name + "このユーザはこのグループに招待できないよ( ´･ω･`)\n\n"+datetime.today().strftime('%H:%M:%S'))
                                 break
                             else:
                                 targets.append(invite)
                         if targets == []:
                             pass
                         else:
                             for target in targets:
                                 try:
                                     cl.findAndAddContactsByMid(target)
                                     cl.inviteIntoGroup(msg.to,[target])
                                     cl.sendText(msg.to,"Done Invite : \n➡" + _name)
                                     wait["winvite"] = False
                                     break
                                 except:
                                     try:
                                         ki.findAndAddContactsByMid(invite)
                                         ki.inviteIntoGroup(op.param1,[invite])
                                         ki.sendText(msg.to,"Done Invite : \n➡" + _name)
                                         wait["winvite"] = False
                                     except:
                                         cl.sendText(msg.to,"Limit the invitation!! please manual to invite \n\n"+datetime.today().strftime('%H:%M:%S'))
                                         wait["winvite"] = False
                                         break
                                         print "INVIT MEMBER"

        if op.type == 26: #awalnya 26,, utk selfbot jd 25                                                                                          
            msg = op.message
            if msg.contentType == 13:                                                                                                                  
                if wait["winvite2"] == True:
                     if msg.from_ in admin:
                         _name = msg.contentMetadata["displayName"]
                         invite = msg.contentMetadata["mid"]
                         groups = kk.getGroup(msg.to)
                         pending = groups.invitee
                         targets = []
                         for s in groups.members:
                             if _name in s.displayName: 
                                 kk.sendText(msg.to,"-> " + _name + " was here")
                                 break
                             elif invite in wait["blacklist"]:                                                                                                         
                                 ks.sendText(msg.to, _name + "このユーザはこのグループに招待できないよ( ´･ω･`)\n\n"+datetime.today().strftime('%H:%M:%S'))
                                 break
                             else:                                                                                                                                      
                                 targets.append(invite)                                                                                                         
                         if targets == []:
                             pass
                         else:
                             for target in targets:
                                 try:
                                     kk.findAndAddContactsByMid(target)
                                     kk.inviteIntoGroup(msg.to,[target])
                                     kk.sendText(msg.to,"Done Invite : \n➡" + _name)
                                     wait["winvite2"] = False
                                     break
                                 except:
                                     try:
                                         ks.findAndAddContactsByMid(invite)
                                         ks.inviteIntoGroup(op.param1,[invite])
                                         ks.sendText(msg.to,"Done Invite : \n➡" + _name)
                                         wait["winvite2"] = False
                                     except:
                                         kk.sendText(msg.to,"Limit the invitation!! please manual to invite  \n\n"+datetime.today().strftime('%H:%M:%S'))
                                         wait["winvite2"] = False
                                         break
                                         print "INVIT MEMBER"

        if op.type == 55:
            try:
              group_id = op.param1
              user_id=op.param2
              subprocess.Popen('echo "'+ user_id+'|'+str(op.createdTime)+'" >> dataSeen/%s.txt' % group_id, shell=True, stdout=subprocess.PIPE, )
            except Exception as e:
              print e
              
        if op.type == 26:
            msg = op.message
            if msg.contentType == 13:
               if wait["wblack"] == True:
                    if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        cl.sendText(msg.to,"already")
                        wait["wblack"] = False
                    else:
                        wait["commentBlack"][msg.contentMetadata["mid"]] = True
                        wait["wblack"] = False
                        cl.sendText(msg.to,"decided not to comment")

               elif wait["dblack"] == True:
                   if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        del wait["commentBlack"][msg.contentMetadata["mid"]]
                        kc.sendText(msg.to,"deleted")
                        wait["dblack"] = False

                   else:
                        wait["dblack"] = False
                        kk.sendText(msg.to,"このユーザはブラックリストに\n載っていないよ(｀・ω・´)\n※一時的なブラックリストに載\nている可能性あり。\n\n"+datetime.today().strftime('%H:%M:%S'))
               elif wait["wblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        ki.sendText(msg.to,"already")
                        wait["wblacklist"] = False
                   else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = False
                        kc.sendText(msg.to,"aded")

               elif wait["dblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"deleted")
                        wait["dblacklist"] = False

                   else:
                        wait["dblacklist"] = False
                        cl.sendText(msg.to,"このユーザはブラックリストに\n載っていないよ(｀・ω・´)\n※一時的なブラックリストに載\nている可能性あり。\n\n"+datetime.today().strftime('%H:%M:%S'))
               elif wait["contact"] == True:
                    msg.contentType = 0
                    kk.sendText(msg.to,"このユーザはブラックリストに載って\nいないよ(｀・ω・´)\n※一時的なブラックリストに載ってい\nる可能性あり。\n\n"+datetime.today().strftime('%H:%M:%S'))
                    print "SEND CONTACT"
                    #cl.sendText(msg.to,msg.contentMetadata["mid"])
                    #if 'displayName' in msg.contentMetadata:
                        #contact = cl.getContact(msg.contentMetadata["mid"])
                        #try:
                            #cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        #except:
                            #cu = ""
                        #cl.sendText(msg.to,"[displayName]:\n" + msg.contentMetadata["displayName"] + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
                    #else:
                        #contact = cl.getContact(msg.contentMetadata["mid"])
                        #try:
                            #cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        #except:
                            #cu = ""
                        #cl.sendText(msg.to,"[displayName]:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))

            elif msg.contentType == 16:
                if wait["timeline"] == True:
                    msg.contentType = 0
                    if wait["lang"] == "JP":
                        msg.text = "post URL\n" + msg.contentMetadata["postEndUrl"]
                    else:
                        msg.text = "URLâ†’\n" + msg.contentMetadata["postEndUrl"]
                    cl.sendText(msg.to,msg.text)
            elif msg.text is None:
                return

            elif msg.text in ["Set:help","Set help","set:help","set help"]:
              print "HELP SET MENU UTAMA"
              if msg.from_ in admin:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpMessage)
                else:
                    cl.sendText(msg.to,helpt)
            elif msg.text in ["Siri owner"]:
              if msg.from_ in admin:
                   msg.contentType = 13
                   msg.contentMetadata = {'mid': owner}
                   cl.sendMessage(msg)
                   print "KONTQK OWNER"
            elif ("Gname " in msg.text):
                if msg.from_ in admin:
                    if msg.toType == 2:
                        X = cl.getGroup(msg.to)
                        X.name = msg.text.replace("Gname ","")
                        cl.updateGroup(X)
                    else:
                        cl.sendText(msg.to,"It can't be used besides the group.")
                        print "GANTI NAMA ROOM"
            elif ("Siri2 gn " in msg.text):
                if msg.from_ in admin:
                    if msg.toType == 2:
                        X = ki.getGroup(msg.to)
                        X.name = msg.text.replace("Siri2 gn ","")
                        ki.updateGroup(X)
                    else:
                        ki.sendText(msg.to,"It can't be used besides the group.")
                        print "BOT 2 GANTI NAMA ROOM"
            elif ("Siri3 gn " in msg.text):
                if msg.from_ in admin:
                    if msg.toType == 2:
                        X = kk.getGroup(msg.to)
                        X.name = msg.text.replace("Siri3 gn ","")
                        kk.updateGroup(X)
                    else:
                        kk.sendText(msg.to,"It can't be used besides the group.")
                        print "BOT 3 GANTI NAMA ROOM"
            elif ("Siri3 gn " in msg.text):
                if msg.from_ in admin:
                    if msg.toType == 2:
                        X = kc.getGroup(msg.to)
                        X.name = msg.text.replace("Siri gn ","")
                        kc.updateGroup(X)
                    else:
                        kc.sendText(msg.to,"It can't be used besides the group.")
                        print "BOT 4 GANTI NAMA ROOM"
            elif "Kick me" in msg.text:
                cl.kickoutFromGroup(msg.from_)
                print "MINTA DI KICK"
            elif "Kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Kick ","")
                cl.kickoutFromGroup(msg.to,[midd])
                print "KICK VIA MID"
            elif "Parry kick " in msg.text:
              if msg.from_ in owner:
                midd = msg.text.replace("Bot2 kick ","")
                ki.kickoutFromGroup(msg.to,[midd])
            elif "Rakko kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Bot3 kick ","")
                kk.kickoutFromGroup(msg.to,[midd])
            elif "Doktor kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Bot4 kick ","")
                kc.kickoutFromGroup(msg.to,[midd])
            elif "Invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Invite ","")
                cl.findAndAddContactsByMid(midd)
                cl.inviteIntoGroup(msg.to,[midd])
            elif "Parry invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Parry invite ","")
                ki.findAndAddContactsByMid(midd)
                ki.inviteIntoGroup(msg.to,[midd])
            elif "Rakko invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Rakko invite ","u858d6fb9c80b8444097d05c7ec23803b")
                kk.findAndAddContactsByMid(midd)
                kk.inviteIntoGroup(msg.to,[midd])
            elif "Doktor invite " in msg.text:
              if msg.from_ in owner:
                midd = msg.text.replace("Doktor invite ","")
                kc.findAndAddContactsByMid(midd)
                kc.inviteIntoGroup(msg.to,[midd])
            elif msg.text in ["Siri contact","siri contact"]:
              if msg.from_ in admin:
                msg.contentType = 13
                msg.contentMetadata = {'mid': mid}
                cl.sendMessage(msg)

                msg.contentType = 13
                msg.contentMetadata = {'mid': Amid}
                ki.sendMessage(msg)

                msg.contentType = 13
                msg.contentMetadata = {'mid': Bmid}
                kk.sendMessage(msg)

                msg.contentType = 13
                msg.contentMetadata = {'mid': Cmid}
                kc.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Dmid}
                ks.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Emid}
                ka.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Fmid}
                kb.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Gmid}
                ko.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Hmid}
                ke.sendMessage(msg)
                                   
                msg.contentType = 13
                msg.contentMetadata = {'mid': Imid}
                ku.sendMessage(msg) 
                                   
                msg.contentType = 13
                msg.contentMetadata = {'mid': Jmid}
                km.sendMessage(msg)
                                   
                msg.contentType = 13
                msg.contentMetadata = {'mid': Kmid}
                kr.sendMessage(msg)
                                   
                msg.contentType = 13                                   
                msg.contentMetadata = {'mid': Lmid}
                kd.sendMessage(msg) 
                                   
                msg.contentType = 13
                msg.contentMetadata = {'mid': Mmid}
                kw.sendMessage(msg)
                                   
                msg.contentType = 13
                msg.contentMetadata = {'mid': Nmid}
                kn.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Omid}
                kt.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Pmid}
                ky.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Qmid}
                kh.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Rmid}
                kz.sendMessage(msg)
                
            elif msg.text in ["Me"]:
              if msg.from_ in admin:
                msg.contentType = 13
                msg.contentMetadata = {'mid': msg.from_}
                random.choice(KAC).sendMessage(msg)
            elif msg.text in ["Bot2"]:
              if msg.from_ in admin:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Bmid}
                kk.sendMessage(msg)
            elif msg.text in ["æ„›ã�®ãƒ—ãƒ¬ã‚¼ãƒ³ãƒˆ","Gift"]:
              if msg.from_ in admin:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '5'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["æ„›ã�®ãƒ—ãƒ¬ã‚¼ãƒ³ãƒˆ","Cv1 gift"]:
              if msg.from_ in admin:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '6'}
                msg.text = None
                ki.sendMessage(msg)
            elif msg.text in ["æ„›ã�®ãƒ—ãƒ¬ã‚¼ãƒ³ãƒˆ","Cv2 gift"]:
              if msg.from_ in admin:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '8'}
                msg.text = None
                kk.sendMessage(msg)
            elif msg.text in ["æ„›ã�®ãƒ—ãƒ¬ã‚¼ãƒ³ãƒˆ","Cv3 gift"]:
              if msg.from_ in admin:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '10'}
                msg.text = None
                kc.sendMessage(msg)
            elif msg.text in ["æ„›ã�®ãƒ—ãƒ¬ã‚¼ãƒ³ãƒˆ","All gift"]:
              if msg.from_ in admin:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '12'}
                msg.text = None
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)

            elif msg.text in ["Cancel","siri cancel invit","Siri cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        cl.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            kc.sendText(msg.to,"No one is inviting \n\n"+datetime.today().strftime('%H:%M:%S'))
                        else:
                            ki.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
    
            elif msg.text in ["Adminlist","adminlist"]:
              if admin == []:
                  cl.sendText(msg.to,"The stafflist is empty")
              else:
                  ks.sendText(msg.to,"待ってください")
                  mc = "Siri v10 Admin\n"
                  for mi_d in admin:
                      mc += "[🔷]" +cl.getContact(mi_d).displayName + "\n"
                  kk.sendText(msg.to, mc + "グルを作ったのはこの人だよ☆\n\n"+datetime.today().strftime('%H:%M:%S'))
                  print "[Command]Stafflist executed"
    
            elif msg.text in ["siri:groupcreator","Siri:groupcreator"]:                                                 
                if msg.toType == 2:
                      msg.contentType = 13
                      ginfo = cl.getGroup(msg.to)
                      gCreator = ginfo.creator.mid
                      try:
                          msg.contentMetadata = {'mid': gCreator}
                          gCreator1 = ginfo.creator.displayName
                      except:
                          gCreator = "Error"
                      cl.sendText(msg.to, gCreator1 + "\nグルを作ったのはこの人だよ☆\n\n" + datetime.today().strftime('%H:%M:%S'))
                      cl.sendMessage(msg)
            elif msg.text in ["Admin"]:
              if admin == []:
                  cl.sendText(msg.to,"Error sementara")
              else:
                  cl.sendText(msg.to,"待ってください")
                  mc = "═════════════\n   ADMIN LIST  \n═════════════\n\n"
                  for mi_d in admin:
                      mc += "☞" +cl.getContact(mi_d).displayName + "\n"
                  cl.sendText(msg.to,mc)
                  print "[Command]ADMIN executed"
            elif msg.text in ["Creator"]:
              if owner == []:
                  cl.sendText(msg.to,"Error sementara")
              else:
                  random.choice(KAC).sendText(msg.to,"待ってください")
                  mc = "Creator\n═══════════════\n"
                  for mi_d in owner:
                      mc += "[🔶]" +cl.getContact(mi_d).displayName + "\n"
                  cl.sendText(msg.to,mc)                                                                    
                  print "[Command]CREATOR executed"
    #----------------------TAMBAH TEMAN--------------------------#
            elif msg.text in ["Cancel invite","Bot cancel","Siri:招待キャンセル"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    G = kc.getGroup(msg.to)
                    if G.invitee is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        kc.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            kc.sendText(msg.to,"No one is inviting")
                        else:
                            kc.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        kc.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kc.sendText(msg.to,"Not for use less than group")
            #elif "gurl" == msg.text:
                #print cl.getGroup(msg.to)
                ##cl.sendMessage(msg)
            elif msg.text in ["Open url","Open qr","Buka url"]:
                if msg.from_ in owner:
                    if msg.toType == 2:
                        X = cl.getGroup(msg.to)
                        X.preventJoinByTicket = False
                        cl.updateGroup(X)
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Invite by link open \n\n"+datetime.today().strftime('%H:%M:%S'))
                        else:
                            cl.sendText(msg.to,"Already open")
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Can not be used outside the group")
                        else:
                            cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Siri2 url on","Siri2 link on"]:
                if msg.from_ in owner:
                    if msg.toType == 2:
                        X = cl.getGroup(msg.to)
                        X.preventJoinByTicket = False
                        ki.updateGroup(X)
                        if wait["lang"] == "JP":
                            ki.sendText(msg.to,"Qr open")
                        else:
                            ki.sendText(msg.to,"already open")
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Can not be used outside the group")
                        else:
                            cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Bot2 url on","Bot2 link on"]:
                if msg.grom_ in owner:
                    if msg.toType == 2:
                        X = kk.getGroup(msg.to)
                        X.preventJoinByTicket = False
                        kk.updateGroup(X)
                        if wait["lang"] == "JP":
                            kk.sendText(msg.to,"Qr Open Brother")
                        else:
                            kk.sendText(msg.to,"already open")
                    else:
                        if wait["lang"] == "JP":
                            kk.sendText(msg.to,"Can not be used outside the group")
                        else:
                            kk.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Bot3 url on","Bot3 link on"]:
                if msg.from_ in owner:
                    if msg.toType == 2:
                        X = kc.getGroup(msg.to)
                        X.preventJoinByTicket = False
                        kc.updateGroup(X)
                        if wait["lang"] == "JP":
                            kc.sendText(msg.to,"Qr Open")
                        else:
                            kc.sendText(msg.to,"already open")
                    else:
                        if wait["lang"] == "JP":
                            kc.sendText(msg.to,"Can not be used outside the group")
                        else:
                            kc.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Close url","Close qr","Siri:招待URL拒否"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"近いUrl \n\n"+datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Already close")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Bot1 url off","Bot1 link off"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ki.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    ki.updateGroup(X)
                    if wait["lang"] == "JP":
                        ki.sendText(msg.to,"Done")
                    else:
                        ki.sendText(msg.to,"already close")
                else:
                    if wait["lang"] == "JP":
                        ki.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ki.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Bot2 url off","Bot2 link off"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = kk.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    kk.updateGroup(X)
                    if wait["lang"] == "JP":
                        kk.sendText(msg.to,"Done")
                    else:
                        kk.sendText(msg.to,"already close")
                else:
                    if wait["lang"] == "JP":
                        kk.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kk.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Bot3 url off","Bot link off"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = kc.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    kc.updateGroup(X)
                    if wait["lang"] == "JP":
                        kc.sendText(msg.to,"Done")
                    else:
                        kc.sendText(msg.to,"already close")
                else:
                    if wait["lang"] == "JP":
                        kc.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kc.sendText(msg.to,"Not for use less than group")
            elif "Masuk " in msg.text.lower():
		rplace=msg.text.lower().rplace("Masuk ")
		if rplace == "on":
			wait["atjointicket"]=True
		elif rplace == "off":
			wait["atjointicket"]=False
		cl.sendText(msg.to,"Auto Join Group by Ticket is %s" % str(wait["atjointicket"]))
            elif '/ti/g/' in msg.text.lower():
		link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
		links = link_re.findall(msg.text)
		n_links=[]
		for l in links:
			if l not in n_links:
				n_links.append(l)
		for ticket_id in n_links:
			if wait["atjointicket"] == True:
				group=cl.findGroupByTicket(ticket_id)
				cl.acceptGroupInvitationByTicket(group.mid,ticket_id)
				cl.sendText(msg.to,"Sukses join ke grup %s" % str(group.name))
            elif msg.text == "Ginfo":
              if msg.from_ in admin:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        gCreator = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    if wait["lang"] == "JP":
                        if ginfo.invitee is None:
                            sinvitee = "0"
                        else:
                            sinvitee = str(len(ginfo.invitee))
                        if ginfo.preventJoinByTicket == True:
                            u = "close"
                        else:
                            u = "open"
                        cl.sendText(msg.to,"GROUP NAME:\n" + str(ginfo.name) + "\n[gid]\n" + msg.to + "\nCREATOR GROUP\n" + gCreator + "\nPROFILE STATUS\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus + "MEMBER:" + str(len(ginfo.members)) + "MEMBER PENDING:" + sinvitee + "people\nURL:" + u + "it is inside")
                    else:
                        cl.sendText(msg.to,"GROUP NAME\n" + str(ginfo.name) + "\n[gid]\n" + msg.to + "\nCREATOR GRROUP\n" + gCreator + "\nPROFILE STATUS\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
            elif "Id group" == msg.text:
              if msg.from_ in admin:
                kk.sendText(msg.to,msg.to)
            elif "My id" == msg.text:
              if msg.from_ in admin:
                random.choice(KAC).sendText(msg.to, msg.from_)
            elif "Id bot" == msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,mid)
                ki.sendText(msg.to,Amid)
                kk.sendText(msg.to,Bmid)
                kc.sendText(msg.to,Cmid)
                ks.sendText(msg.to,Dmid)
                ka.sendText(msg.to,Emid)
                kb.sendText(msg.to,Fmid)
                ko.sendText(msg.to,Gmid)
                ke.sendText(msg.to,Hmid)
                ku.sendText(msg.to,Imid)
                km.sendText(msg.to,Jmid)
                kr.sendText(msg.to,Kmid)
                kd.sendText(msg.to,Lmid)
                kw.sendText(msg.to,Mmid)
                kn.sendText(msg.to,Nmid)
                kt.sendText(msg.to,Omid)
                ky.sendText(msg.to,Pmid)
                kh.sendText(msg.to,Qmid)
                kz.sendText(msg.to,Rmid)
            elif "Id 1" == msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,mid)
            elif "Id 2" == msg.text:
                ki.sendText(msg.to,Amid)
            elif "Id 3" == msg.text:
                kk.sendText(msg.to,Bmid)
            elif "Id 4" == msg.text:
                kc.sendText(msg.to,Cmid)
            elif "Id 5" == msg.text:
                ks.sendText(msg.to,Dmid)
            elif "Id 6" == msg.text:
                ka.sendText(msg.to,Emid)
            elif "Id 7" == msg.text:
                kb.sendText(msg.to,Fmid)
            elif "Id 8" == msg.text:
                ko.sendText(msg.to,Gmid)
            elif "Id 9" == msg.text:
                ke.sendText(msg.to,Hmid)
            elif "Id 10" == msg.text:
                ku.sendText(msg.to,Imid)
            elif "Id 11" == msg.text:
                km.sendText(msg.to,Jmid)
            elif "Id 12" == msg.text:
                kr.sendText(msg.to,Kmid)
            elif "Id 13" == msg.text:
                kd.sendText(msg.to,Lmid)
            elif "Id 14" == msg.text:
                kw.sendText(msg.to,Mmid)
            elif "Id 15" == msg.text:
                kn.sendText(msg.to,Nmid)
            elif "Id 16" == msg.text:
                kt.sendText(msg.to,Omid)
            elif "Id 17" == msg.text:
                ky.sendText(msg.to,Pmid)
            elif "Id 18" == msg.text:
                kh.sendText(msg.to,Qmid)
            elif "Id 19" == msg.text:
                kz.sendText(msg.to,Rmid)
            elif msg.text in ["Wkwkwk","Wkwk","Wk","wkwkwk","wkwk","wk"]:
              if msg.from_ in owner:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "100",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                #cl.sendMessage(msg)
                #ki.sendMessage(msg)
                kk.sendMessage(msg)
            elif msg.text in ["Hehehe","Hehe","He","hehehe","hehe","he"]:
              if msg.from_ in owner:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "10",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                #ki.sendMessage(msg)
                kk.sendMessage(msg)
            elif msg.text in ["Galau"]:
              if msg.from_ in owner:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "9",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                #kk.sendMessage(msg)
            elif msg.text in ["You"]:
              if msg.from_ in owner:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "7",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                #kk.sendMessage(msg)
            elif msg.text in ["Hadeuh"]:
              if msg.from_ in owner:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "6",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                #kk.sendMessage(msg)
            elif msg.text in ["Please"]:
              if msg.from_ in owner:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "4",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                #ki.sendMessage(msg)
                kk.sendMessage(msg)
            elif msg.text in ["Haaa"]:
              if msg.from_ in owner:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "3",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                #kk.sendMessage(msg)
            elif msg.text in ["Lol"]:
              if msg.from_ in owner:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "110",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                #ki.sendMessage(msg)
                kk.sendMessage(msg)
            elif msg.text in ["Hmmm","Hmm","Hm","hmmm","hmm","hm"]:
              if msg.from_ in owner:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "101",
                                     "STKPKGID": "1",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
            elif msg.text in ["Welcome"]:
              if msg.from_ in owner:
                msg.contentType = 7
                msg.text = None
                msg.contentMetadata = {
                                     "STKID": "247",
                                     "STKPKGID": "3",
                                     "STKVER": "100" }
                ki.sendMessage(msg)
                #kk.sendMessage(msg)
            elif msg.text in ["TL: "]:
              if msg.from_ in admin:
                tl_text = msg.text.replace("TL: ","")
                cl.sendText(msg.to,"line://home/post?userMid="+mid+"&postId="+cl.new_post(tl_text)["result"]["post"]["postInfo"]["postId"])
            elif msg.text in ["Bot1 name "]:
              if msg.from_ in admin:
                string = msg.text.replace("Bot1 name ","")
                if len(string.decode('utf-8')) <= 20:
                    profile = cl.getProfile()
                    profile.displayName = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"name " + string + " done")
            elif msg.text in ["Bot2 rename "]:
              if msg.from_ in admin:
                string = msg.text.replace("Bot2 rename ","")
                if len(string.decode('utf-8')) <= 20:
                    profile_B = ki.getProfile()
                    profile_B.displayName = string
                    ki.updateProfile(profile_B)
                    ki.sendText(msg.to,"name " + string + " done")
            elif msg.text in ["Bot3 rename "]:
              if msg.from_ in admin:
                string = msg.text.replace("Bot3 rename ","")
                if len(string.decode('utf-8')) <= 20:
                    profile_B = kk.getProfile()
                    profile_B.displayName = string
                    kk.updateProfile(profile_B)
                    kk.sendText(msg.to,"name " + string + " done")
            elif msg.text in ["Mc "]:
              if msg.from_ in admin:
                mmid = msg.text.replace("Mc ","")
                msg.contentType = 13
                msg.contentMetadata = {"mid":mmid}
                cl.sendMessage(msg)
            elif msg.text in ["Block invite on","Blockinvite on"]:
              if msg.from_ in admin:
                if wait["Protectjoin"] == True:
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"ユーザによる招待を拒否しました(｀・ω・´)\n\n"+datetime.today().strftime('%H:%M:%S'))
                    else:
                        random.choice(KAC).sendText(msg.to,"done")
                else:
                    wait["Protectjoin"] = True
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"kick Joined Group On ôﾀﾔﾃôﾀﾆﾑlock.")
                    else:
                        random.choice(KAC).sendText(msg.to,"done")
            elif msg.text in ["Welcome on","Welcome:on"]:
              if msg.from_ in admin:
                if wait["welcom"] == True:
                    if wait["lang"] == "JP":
                        sd.sendText(msg.to,"Say Welcome di aktifkan")
                    else:
                        sd.sendText(msg.to,"Say welcome sudah aktif")
                else:
                    wait["welcom"] = True
                    if wait["lang"] == "JP":
                        sd.sendText(msg.to,"Welcome status on")
                    else:
                        sd.sendText(msg.to,"welcome status on")
            elif msg.text in ["Welcome off","Welcome:off"]:
              if msg.from_ in admin:
                if wait["welcom"] == False:
                    if wait["lang"] == "JP":
                        sd.sendText(msg.to,"Say Welcome di Nonaktifkan")
            elif msg.text in ["Autoinvite on","Auto invite on"]:
              if msg.from_ in admin:
                if wait["autoInvite"] == True:
                  if wait["Protectcancl"] == False:
                    random.choice(DEF2).sendText(msg.to,"Auto invite is Now Aktif")
            elif msg.text in ["Autoinvite off","Auto invite off"]:
              if msg.from_ in admin:
                if wait["autoInvite"] == False:
                  if wait["Protectcancl"] == True:
                    random.choice(DEF2).sendText(msg.to,"Auto invite NonAktif")
            elif msg.text in ["Block invite off","Blockinvite off"]:
              if msg.from_ in admin:
                if wait["Protectjoin"] == False:
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"ユーザによる招待を拒否しました(｀・ω・´)\n\n"+datetime.today().strftime('%H:%M:%S'))
                    else:
                        random.choice(KAC).sendText(msg.to,"done")
                else:
                    wait["Protectjoin"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"kick Joined Group Off")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Cancl on","Cancel on","Invite off"]:
              if msg.from_ in admin:
                if wait["Protectcancl"] == True:
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"取消しすべては引き起こします \n\n"+datetime.today().strftime('%H:%M:%S'))
                    else:
                        random.choice(KAC).sendText(msg.to,"done")
                else:
                    wait["Protectcancl"] = True
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"オフですべて引き起こされた取消し ^_^   \n\n"+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        random.choice(KAC).sendText(msg.to,"Status : ON")
            elif msg.text in ["Cancl off","Cancel off","Invite on"]:
              if msg.from_ in admin:
                if wait["Protectcancl"] == False:
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"ステータス：オフ \n\n"+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        random.choice(KAC).sendText(msg.to,"Status : OFF")
                else:
                    wait["Protectcancl"] = False
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"Cancel All Invited Off")
                    else:
                        random.choice(KAC).sendText(msg.to,"done")
            elif msg.text in ["Gr on","gr on","Protect on","PROTECT","Qr on"]:
              if msg.from_ in admin:
                if wait["Protectgr"] == True:
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"ステータス：ロックされます^_^ \n\n"+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        random.choice(KAC).sendText(msg.to,"Status : Locked")
                else:
                    wait["Protectgr"] = True
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"ステータス：ロックされます^_^  \n\n"+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        random.choice(KAC).sendText(msg.to,"done")
            elif msg.text in ["Gr off","gr off","Qr off"]:
              if msg.from_ in admin:
                if wait["Protectgr"] == False:
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"グループを保護してください：オフ(^_^;)  \n\n" + datetime.today().strftime('%H:%M:%S'))
                    else:
                        random.choice(KAC).sendText(msg.to,"Status : OFF"),
                else:
                    wait["Protectgr"] = False
                    if wait["lang"] == "JP":
                        random.choice(KAC).sendText(msg.to,"Protect Group Off")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Contact On","Contact on","contact on"]:
              if msg.from_ in admin:
                if wait["contact"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cek Mid Send Contact On")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["contact"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cek Mid On")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Contact Off","Contact off","contact off"]:
              if msg.from_ in admin:
                if wait["contact"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cek Mid Off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["contact"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Cek Mid Send Contact Off")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Join on","Auto join:on","è‡ªå‹•å�ƒåŠ ï¼šé–‹"]:
              if msg.from_ in admin:
                if wait["autoJoin"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["autoJoin"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Join off","Auto join:off","è‡ªå‹•å�ƒåŠ ï¼šé—œ"]:
              if msg.from_ in admin:
                if wait["autoJoin"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["autoJoin"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Gcancel:"]:
                try:
                    strnum = msg.text.replace("Gcancel:","")
                    if strnum == "off":
                        wait["autoCancel"]["on"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Invitation refused turned off\nTo turn on please specify the number of people and send")
                        else:
                            cl.sendText(msg.to,"å…³äº†é‚€è¯·æ‹’ç»�ã€‚è¦�æ—¶å¼€è¯·æŒ‡å®šäººæ•°å�‘é€�")
                    else:
                        num =  int(strnum)
                        wait["autoCancel"]["on"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,strnum + "The group of people and below decided to automatically refuse invitation")
                        else:
                            cl.sendText(msg.to,strnum + "ä½¿äººä»¥ä¸‹çš„å°�ç»„ç”¨è‡ªåŠ¨é‚€è¯·æ‹’ç»�")
                except:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Value is wrong")
                    else:
                        cl.sendText(msg.to,"Bizarre ratings")
            elif msg.text in ["Leave on","Auto leave:on"]:
              if msg.from_ in admin:
                if wait["leaveRoom"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["leaveRoom"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å¼€ã€‚")
            elif msg.text in ["Leave off","Auto leave:off"]:
              if msg.from_ in admin:
                if wait["leaveRoom"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["leaveRoom"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"already")
            elif msg.text in ["å…±æœ‰:ã‚ªãƒ³","Share on","Share on"]:
              if msg.from_ in admin:
                if wait["timeline"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["timeline"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å¼€ã€‚")
            elif msg.text in ["å…±æœ‰:ã‚ªãƒ•","Share off","Share off"]:
              if msg.from_ in admin:
                if wait["timeline"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["timeline"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å…³æ–­ã€‚")
            elif msg.text in ["Status"]:
              if msg.from_ in admin:                                                                                                                                     
                md = "═══════════════\n  Siriv10 Protector Status  \n═══════════════\n"
                if wait["Protectgr"] == True: md+="✔☞Protect QR [On]\n"                                                                                                  
                else: md+="❌☞Protect QR [Off]\n"
                if wait["Protectcancl"] == True: md+="✔☞Protect Invite [On]\n"
                else: md+="❌☞Protect Invite [Off]\n"                                                                                         
                if wait["contact"] == True: md+="✔☞Contact [On]\n"
                else: md+="❌☞Contact [Off]\n"
                if wait["autoJoin"] == True: md+="✔☞Auto Join [On]\n"
                else: md +="❌☞Auto Join [Off]\n"
                if wait["autoCancel"]["on"] == True:md+="✔☞Group Cancel " + str(wait["autoCancel"]["members"]) + "\n"
                else: md+= "❌☞Group Cancel [Off]\n"
                if wait["leaveRoom"] == True: md+="✔☞Auto Leave [On]\n"
                else: md+="❌☞Auto Leave [Off]\n"
                if wait["timeline"] == True: md+="✔☞Share [On]\n"
                else:md+="❌☞Share [Off]\n"
                if wait["autoAdd"] == True: md+="✔☞Auto Add [On]\n"
                else:md+="❌☞Auto Add [Off]\n"
                if wait["alwaysRead"] == True: md+="✔☞Auto read [On]\n"
                else:md+="❌☞Auto Read [Off]\n"
                if wait["welcom"] == True: md+="✔☞ Welcome [On]\n"
                else:md+="❌☞Welcome  [Off]\n"
                if wait["commentOn"] == True: md+="✔☞Comment [On]\n"
                else:md+="❌☞Comment [Off]\n═══════════════\n     SiriChan v10\n═══════════════\n"
                cl.sendText(msg.to,md + "\n" + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Set:check"]:                                                                                                          
              #if msg.from_ in admin:
                ginfo = cl.getGroup(msg.to)
                Gcreator = ginfo.creator.displayName
                kontak = cl.getGroup(msg.to)
                group = kontak.members
                #for mi_d in Creator
                mi_d = 'ub542d871ea20170d941cc026c27eb4e6'
                md = "このグループでは以下のように設定されています(｀・ω・´)\n\n"
                if wait["autoCancel"] == True: md+="ユーザによる招待拒否 : オン\n"
                else:md+="ユーザによる招待拒否 : オフ\n"
                if wait["Protectgr"] == True: md+="URL招待拒否 : オン\n"
                else:md+="URL招待拒否 : オフ\n"
                if wait["autoJoin"] == True: md+="グループ作成者ロック : オン\n現在の作成者 : "+Gcreator +"\n"                                   
                else: md +="グループ作成者ロック : オフ\n現在の作成者 : "+Gcreator +"\n"
                if wait["timeline"] == True: md+="グループ名ロック : オン\n"
                else: md +="グループ名ロック : オフ\n"
                if wait["leaveRoom"] == True: md+="アイコンロック : オン\n現在の予備作成者 :" +  cl.getContact(mi_d).displayName +"\n"
                else: md +="アイコンロック : オフ\n現在の予備作成者 :" +   cl.getContact(mi_d).displayName +"\n"                                            
                if wait["contact"] == True: md+="らっこさん : オン\n"
                else: md+="らっこさん : オフ\n"
                if wait["autoAdd"] == True:md+="スタンプ規制 : オン\n"
                else: md+= "スタンプ規制 : オフ.\n"
                if wait["alwaysRead"] == True:md+="応答 : オン\n"
                else: md+= "応答 : オフ\n"
                if wait["commentOn"] == True: md+="╠Language : Japanese\n"
                else:md+="Language : Japanese\n"
                if wait["contact"] == True: md+="独自ホワイト&ブラック件数 : 1\n"
                else:md+="独自ホワイト&ブラック件数 : 0\n"
                if wait["comment"] == True: md+="メンバー数 : %i" % len(group)+"\n"
                else:md+="メンバー数 : %i" % len(group)+"\n"
                if wait["autoJoin"] == True: md+="招待ユーザ数 : 1\n"
                else:md+="招待ユーザ数 : 1\n"
                if wait["Protectcancl"] == True: md+="追加保護ボット招待可能数 : 7\n"
                else:md+="追加保護ボット招待可能数 : 7\n"
                if wait["sider"] == True: md+="追加保護ボット招待数 : 6\n"
                else:md+="追加保護ボット招待数 : 6  "
                cl.sendText(msg.to,md)
            elif "Change sider1x: " in msg.text:                                                     
              if msg.from_ in admin:                                                                      
                pesan["sider1"] = msg.text.replace("Change sider1x: ","")
                cl.sendText(msg.to,"Message sider change to:\n" + pesan["sider1"] +"\n"+jam)
            elif "Change sider2x: " in msg.text:                 
              if msg.from_ in admin:
                pesan["sider2"] = msg.text.replace("Change sider2x: ","")
                cl.sendText(msg.to,"Message sider2 change to:\n" + pesan["sider2"] +"\n"+jam)
            elif "Change sider3x: " in msg.text:                
              if msg.from_ in admin:
                pesan["sider3"] = msg.text.replace("Change sider3x: ","")
                cl.sendText(msg.to,"Message sider3 change to:\n" + pesan["sider3"] +"\n"+jam)
            elif "album merit " in msg.text:
              if msg.from_ in admin:
                gid = msg.text.replace("album merit ","")
                album = cl.getAlbum(gid)
                if album["result"]["items"] == []:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"There is no album")
                    else:
                        cl.sendText(msg.to,"ç›¸å†Œæ²¡åœ¨ã€‚")
                else:
                    if wait["lang"] == "JP":
                        mg = "The following is the target album"
                    else:
                        mg = "ä»¥ä¸‹æ˜¯å¯¹è±¡çš„ç›¸å†Œ"
                    for y in album["result"]["items"]:
                        if "photoCount" in y:
                            mg += str(y["title"]) + ":" + str(y["photoCount"]) + "sheet\n"
                        else:
                            mg += str(y["title"]) + ":0sheet\n"
                    cl.sendText(msg.to,mg)
            elif "Invitemeto: " in msg.text:
                if msg.from_ in admin:
                    gid = msg.text.replace("Invitemeto: ","")
                    if gid == "":
                        cl.sendText(msg.to,"Invalid group id")
                    else:
                        try:
                            cl.findAndAddContactsByMid(msg.from_)
                            ki.findAndAddContactsByMid(msg.from_)
                            kk.findAndAddContactsByMid(msg.from_)                                                            
                            kc.findAndAddContactsByMid(msg.from_)
                            ks.findAndAddContactsByMid(msg.from_)
                            random.choice(KAC).inviteIntoGroup(gid,[msg.from_])
                        except:
                            cl.sendText(msg.to,"Mungkin Saya Tidak Di Dalaam Grup Itu")
            elif "Album " in msg.text:
              if msg.from_ in admin:
                gid = msg.text.replace("Album ","")
                album = cl.getAlbum(gid)
                if album["result"]["items"] == []:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"There is no album")
                    else:
                        cl.sendText(msg.to,"ç›¸å†Œæ²¡åœ¨ã€‚")
                else:
                    if wait["lang"] == "JP":
                        mg = "The following is the target album"
                    else:
                        mg = "ä»¥ä¸‹æ˜¯å¯¹è±¡çš„ç›¸å†Œ"
                    for y in album["result"]["items"]:
                        if "photoCount" in y:
                            mg += str(y["title"]) + ":" + str(y["photoCount"]) + "sheet\n"
                        else:
                            mg += str(y["title"]) + ":0sheet\n"
            elif "Album remove " in msg.text:
              if msg.from_ in admin:
                gid = msg.text.replace("Album remove ","")
                albums = cl.getAlbum(gid)["result"]["items"]
                i = 0
                if albums != []:
                    for album in albums:
                        cl.deleteAlbum(gid,album["id"])
                        i += 1
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,str(i) + "Deleted albums")
                else:
                    cl.sendText(msg.to,str(i) + "åˆ é™¤äº†äº‹çš„ç›¸å†Œã€‚")
            #elif msg.text in ["Assalamualaikum","hai","Hai","halo","Halo","huy","iya","trimakasih","kenapa","oh","assalamualaikum","ehm","hmm","Hmm"]:
              #if wait["alwaysRead"] == True:
                #Pesan = ["そ、そうですか・・・・","コマンドが理解できなかったよ>_<","しりちゃんのヘルプは、「Siri:ヘルプ」って打ってみてね☆","はい！なにか御用ですか？"]
                #Kirim = random.choice(Pesan)
                #cl.sendText(msg.to, Kirim)
            elif msg.text in ["Group id"]:
              if msg.from_ in admin:
                gid = cl.getGroupIdsJoined()
                h = ""
                for i in gid:
                    h += "[%s]:\n%s\n" % (cl.getGroup(i).name,i)
                cl.sendText(msg.to,h)
            elif msg.text in ["Cancelall","Cancel all"]:
              if msg.from_ in admin:
                gid = cl.getGroupIdsInvited()
                for i in gid:
                    cl.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"All invitations have been refused \n\n" + datetime.today().strftime('%H:%M:%S'))
                else:
                    cl.sendText(msg.to,"æ‹’ç»�äº†å…¨éƒ¨çš„é‚€è¯·ã€‚")
            elif "Album removeat’" in msg.text:
                gid = msg.text.replace("Album removeat’","")
                albums = cl.getAlbum(gid)["result"]["items"]
                i = 0
                if albums != []:
                    for album in albums:
                        cl.deleteAlbum(gid,album["id"])
                        i += 1
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,str(i) + "Albums deleted")
                else:
                    cl.sendText(msg.to,str(i) + "åˆ é™¤äº†äº‹çš„ç›¸å†Œã€‚")
            elif msg.text in ["Add on","Bot add:on","è‡ªå‹•è¿½åŠ ï¼šé–‹"]:
              if msg.from_ in admin:
                if wait["autoAdd"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["autoAdd"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å¼€ã€‚")
            elif msg.text in ["Add off","Auto add:off","è‡ªå‹•è¿½åŠ ï¼šé—œ"]:
              if msg.from_ in admin:
                if wait["autoAdd"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["autoAdd"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å…³æ–­ã€‚")
            elif "Message change: " in msg.text:
                wait["message"] = msg.text.replace("Message change: ","")
                cl.sendText(msg.to,"message changed")
            elif "Message add: " in msg.text:
                wait["message"] = msg.text.replace("Message add: ","")
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"message changed")
                else:
                    cl.sendText(msg.to,"doneã€‚")
            elif msg.text in ["Message","è‡ªå‹•è¿½åŠ å•�å€™èªžç¢ºèª�"]:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"message change to\n\n" + wait["message"])
                else:
                    cl.sendText(msg.to,"The automatic appending information is set as followsã€‚\n\n" + wait["message"])
            elif "Comment:" in msg.text:
                c = msg.text.replace("Comment:","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"message changed")
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"changed\n\n" + c)
            elif "Add comment:" in msg.text:
                c = msg.text.replace("Add comment:","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"String that can not be changed")
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"changed\n\n" + c)
            elif msg.text in ["Comment on","Comment:on"]:
              if msg.from_ in admin:
                if wait["commentOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"already on")
                else:
                    wait["commentOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å¼€ã€‚")
            elif msg.text in ["Autoread on","Read:on"]:
                wait["alwaysRead"] = True
                cl.sendText(msg.to,"Auto read On")

            elif msg.text in ["Autoread off","Read:off"]:
                wait["alwaysRead"] = False
                cl.sendText(msg.to,"Auto read Off")

            elif msg.text in ["Comment on","Comment off"]:
              if msg.from_ in admin:
                if wait["commentOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"already off")
                else:
                    wait["commentOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å…³æ–­ã€‚")
            elif msg.text in ["Comment","ç•™è¨€ç¢ºèª�"]:
                cl.sendText(msg.to,"message changed to\n\n" + str(wait["comment"]))
            elif msg.text in ["Send url"]:
                if msg.from_ in admin:
                    if msg.toType == 2:
                        x = cl.getGroup(msg.to)
                        if x.preventJoinByTicket == True:
                            x.preventJoinByTicket = False
                            cl.updateGroup(x)
                        gurl = cl.reissueGroupTicket(msg.to)
                        cl.sendText(msg.to,"line://ti/g/" + gurl)
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Can't be used outside the group")
                        else:
                            cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Send qr"]:
                if msg.from_ in owner:
                    if msg.toType == 2:
                        x = cl.getGroup(msg.to)
                        if x.preventJoinByTicket == True:
                            x.preventJoinByTicket = False
                            ki.updateGroup(x)
                        gurl = ki.reissueGroupTicket(msg.to)
                        ki.sendText(msg.to,"line://ti/g/" + gurl)
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Can't be used outside the group")
                        else:
                            cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Siri:招待URL生成"]:
                if msg.from_ in owner:
                    if msg.toType == 2:
                        x = cl.getGroup(msg.to)
                        if x.preventJoinByTicket == True:
                            x.preventJoinByTicket = False
                            kk.updateGroup(x)
                        gurl = kk.reissueGroupTicket(msg.to)
                        kk.sendText(msg.to,"line://ti/g/" + gurl)
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Can't be used outside the group")
                        else:
                            cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Kirim url"]:
                if msg.from_ in owner:
                    if msg.toType == 2:
                        x = cl.getGroup(msg.to)
                        if x.preventJoinByTicket == True:
                            x.preventJoinByTicket = False
                            kc.updateGroup(x)
                        gurl = kc.reissueGroupTicket(msg.to)
                        kc.sendText(msg.to,"line://ti/g/" + gurl)
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Can't be used outside the group")
                        else:
                            cl.sendText(msg.to,"Not for use less than group")
            elif msg.text in ["Comment blk "]:
                wait["wblack"] = True
                cl.sendText(msg.to,"add to comment bl")
            elif msg.text in ["Comment wlk "]:
                wait["dblack"] = True
                cl.sendText(msg.to,"wl to comment bl")
            elif msg.text in ["Comment bl confirm"]:
                if wait["commentBlack"] == {}:
                    cl.sendText(msg.to,"confirmed")
                else:
                    cl.sendText(msg.to,"Blacklist")
                    mc = ""
                    for mi_d in wait["commentBlack"]:
                        mc += "" +cl.getContact(mi_d).displayName + "\n"
                    cl.sendText(msg.to,mc)
        #-------------Fungsi Jam on/off Start-------------------#            
            elif msg.text in ["Jam on","Clock on"]:
              if msg.from_ in owner:
                if wait["clock"] == True:
                    sd.sendText(msg.to,"SiderBot jam on")
                else:
                    wait["clock"] = True
                    now2 = datetime.now()
                    nowT = datetime.strftime(now2,"(%H:%M)")
                    profile = sd.getProfile()
                    profile.displayName = wait["cName18"] + nowT
                    sd.updateProfile(profile)
                    sd.sendText(msg.to,"Jam Always On")
            elif msg.text in ["Clock off","Jam off"]:
              if msg.from_ in admin:
                if wait["clock"] == False:
                    sd.sendText(msg.to,"Sider bot jam off")
                else:
                    wait["clock"] = False
                    sd.sendText(msg.to,"The clock is dead")
         #-------------Fungsi Jam on/off Finish-------------------#           
         
         #-------------Fungsi Change Clock Start------------------#
            elif msg.text in ["Change clock"]:
              if msg.from_ in owner:
                n = msg.text.replace("Change clock","")
                if len(n.decode("utf-8")) > 13:
                    sd.sendText(msg.to,"changed")
                else:
                    wait["cName"] = n
                    sd.sendText(msg.to,"changed to\n\n" + n)
         #-------------Fungsi Change Clock Finish-----------------#           
        
         #-------------Fungsi Jam Update Start---------------------#            
            elif msg.text in ["Jam update","Update jam","Clock update"]:
              if msg.from_ in owner:
                if wait["clock"] == True:
                    now2 = datetime.now()
                    nowT = datetime.strftime(now2,"(%H:%M)")
                    profile = sd.getProfile()
                    profile.displayName = wait["cName4"] + nowT
                    sd.updateProfile(profile)
                    sd.sendText(msg.to,"Sukses update")
                else:
                    sd.sendText(msg.to,"Aktifkan jam terlebih dulu")
         #-------------Fungsi Jam Update Finish------------------#

         #----------------Fungsi Join Group Start-----------------------#
            elif msg.text in ["Siri login","siri login"]:
              if msg.from_ in admin:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = cl.reissueGroupTicket(msg.to)
                        ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        ks.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        cl.sendText(msg.to,"どうぞ、Sirichan v10オプションのためのコマンド（オプションに追加してください）を送ってください  \n\n" + datetime.today().strftime('%H:%M:%S'))
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                        print "SIRI IS COMPLETED!!!!"
                        G.preventJoinByTicket(G)
                        cl.updateGroup(G)
            elif msg.text in ["Add optional"]:
              if msg.from_ in admin:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)                                                                               
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = cl.reissueGroupTicket(msg.to)
                        ka.acceptGroupInvitationByTicket(msg.to,Ticket)
                        kb.acceptGroupInvitationByTicket(msg.to,Ticket)
                        ko.acceptGroupInvitationByTicket(msg.to,Ticket)
                        ke.acceptGroupInvitationByTicket(msg.to,Ticket)
                        ku.acceptGroupInvitationByTicket(msg.to,Ticket)
                        km.acceptGroupInvitationByTicket(msg.to,Ticket)                        
                        kr.acceptGroupInvitationByTicket(msg.to,Ticket)
                        kd.acceptGroupInvitationByTicket(msg.to,Ticket)
                        kw.acceptGroupInvitationByTicket(msg.to,Ticket)
                        kn.acceptGroupInvitationByTicket(msg.to,Ticket)
                        kt.acceptGroupInvitationByTicket(msg.to,Ticket)
                        ky.acceptGroupInvitationByTicket(msg.to,Ticket)
                        kh.acceptGroupInvitationByTicket(msg.to,Ticket)
                        kz.acceptGroupInvitationByTicket(msg.to,Ticket)
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                        print "OPTION IS COMPLETED!!!!"
                        G.preventJoinByTicket(G)
                        cl.updateGroup(G)
                        
            elif msg.text in ["Siri kicker"]:
              if msg.from_ in admin:
                        G = ki.getGroup(msg.to)                                                            
                        ginfo = ki.getGroup(msg.to)
                        G.preventJoinByTicket = False                                                      
                        ki.updateGroup(G)
                        invsend = 0
                        Ticket = ki.reissueGroupTicket(msg.to)
                        satpam.acceptGroupInvitationByTicket(msg.to,Ticket)
                        satpam2.acceptGroupInvitationByTicket(msg.to,Ticket)
                        satpam.sendText(msg.to,"コマンドが理解できなかったよ>_< \n\n" + datetime.today().strftime('%H:%M:%S'))
                        time.sleep(0.5)
                        satpam2.leaveGroup(msg.to)
                        satpam.leaveGroup(msg.to)
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                        print "SATPAM OK"                                                         
                        G.preventJoinByTicket(G)
                        cl.updateGroup(G)

            elif msg.text in ["Undang bos"]:
              if msg.from_ in admin:
                        G = ki.getGroup(msg.to)
                        ginfo = ki.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        ki.updateGroup(G)
                        invsend = 0
                        Ticket = ki.reissueGroupTicket(msg.to)
                        satpam.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        R = satpam.getGroup(msg.to)
                        ginfo = satpam.getGroup(msg.to)
                        R.preventJoinByTicket = False
                        satpam.updateGroup(R)
                        invsend = 0
                        Ticket = satpam.reissueGroupTicket(msg.to)
                        cl.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        satpam.sendText(msg.to,"Masuk Bos")
                        satpam.leaveGroup(msg.to)
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                        print "BOS BOT MASUK"
                        G.preventJoinByTicket(G)
                        cl.updateGroup(G)
            elif msg.text in ["Bot sider masuk"]:
              if msg.from_ in admin:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = ki.reissueGroupTicket(msg.to)
                        sd.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        sd.sendText(msg.to,"Assalamualaikum kk....(^_-)\n Bot sider datang untuk menyelamatkan bumi...hehehe *^O^*\nKlick 「Sider on」Untuk mengAktifkan Aim ok Kk!! (￣∇￣)")
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)                                                                                 
                        print "BOT SIDER MASUK !!"                                                                     
                        G.preventJoinByTicket(G)
                        cl.updateGroup(G)
            elif msg.text in ["Siri:reinvite","Siri reinvite"]:
              if msg.from_ in admin:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = cl.reissueGroupTicket(msg.to)
                        ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        ks.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        G = ki.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        ki.updateGroup(G)
                        G = ks.getGroup(msg.to)
                        ginfo = ks.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        ks.updateGroup(G)
                        invsend = 0
                        Ticket = ks.reissueGroupTicket(msg.to)
                        ka.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kb.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        ko.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        ke.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        ku.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        km.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        G = ko.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        ko.updateGroup(G)
                        G = kk.getGroup(msg.to)
                        ginfo = kk.getGroup(msg.to)                                                                                 
                        G.preventJoinByTicket = False
                        kk.updateGroup(G)                                                                                           
                        invsend = 0
                        Ticket = kk.reissueGroupTicket(msg.to)
                        kr.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kd.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kw.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kn.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kt.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        ky.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kh.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kz.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        G = ki.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        ki.updateGroup(G)
                        print "SIRI IS COMPLETED!!!!"
                        G.preventJoinByTicket(G)
                        ki.updateGroup(G)

            elif msg.text in ["Brother3 go","Brother3 masuk"]:
              if msg.from_ in owner:
                        G = kk.getGroup(msg.to)
                        ginfo = kk.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        kk.updateGroup(G)
                        invsend = 0
                        Ticket = ki.reissueGroupTicket(msg.to)
                        cl.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        ks.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                        print "BROTHERS IS COMPLETED!!!!"
                        G.preventJoinByTicket(G)
                        cl.updateGroup(G)
            elif msg.text in ["Brother3 go","Brother3 masuk"]:
              if msg.from_ in owner:
                        G = kk.getGroup(msg.to)
                        ginfo = kk.getGroup(msg.to)
                        G.preventJoinByTicket = False                                                             
                        kk.updateGroup(G)
                        invsend = 0
                        ka.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kb.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        ko.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        ke.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        ku.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        km.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kr.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kd.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kw.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kn.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kt.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kt.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        ky.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kh.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        kz.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.1)
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                        print "BROTHERS IS COMPLETED!!!!"
                        G.preventJoinByTicket(G)
                        cl.updateGroup(G)
            
            elif msg.text in ["Lisa join"]:
              if msg.form_ in admin:
                  x = ki.getGroup(msg.to)
                  x.preventJoinByTicket = False
                  ki.updateGroup(x)
                  invsend = 0
                  Ti = ki.reissueGroupTicket(msg.to)
                  cl.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = ki.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  ki.updateGroup(G)
                  Ticket = ki.reissueGroupTicket(msg.to)

            elif msg.text in ["Parry join"]:
              if msg.from_ in admin:
                  x = cl.getGroup(msg.to)
                  x.preventJoinByTicket = False
                  cl.updateGroup(x)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  ki.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = cl.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  cl.updateGroup(G)
                  Ticket = cl.reissueGroupTicket(msg.to)

            elif msg.text in ["Rakko join"]:
              if msg.from_ in admin:
                  x = cl.getGroup(msg.to)
                  x.preventJoinByTicket = False
                  cl.updateGroup(x)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  kk.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = cl.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  cl.updateGroup(G)
                  Ticket = cl.reissueGroupTicket(msg.to)

            elif msg.text in ["Doctor join"]:
              if msg.from_ in admin:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  kc.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = cl.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  cl.updateGroup(G)
                  Ticket = cl.reissueGroupTicket(msg.to)
            elif msg.text in ["Eliza join"]:
              if msg.from_ in admin:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  ks.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = cl.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  cl.updateGroup(G)
                  Ticket = cl.reissueGroupTicket(msg.to)
            elif msg.text in ["Add1 join"]:
              if msg.from_ in admin:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  ka.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = cl.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  cl.updateGroup(G)
                  Ticket = cl.reissueGroupTicket(msg.to)
    #----------------------Fungsi Join Group Finish---------------#

    #-------------Fungsi Leave Group Start---------------#
            elif msg.text in ["Siri bye"]:
              if msg.from_ in owner:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ki.leaveGroup(msg.to)
                        kk.leaveGroup(msg.to)
                        kc.leaveGroup(msg.to)
                        ks.leaveGroup(msg.to)
                        ka.leaveGroup(msg.to)
                        kb.leaveGroup(msg.to)
                        ko.leaveGroup(msg.to)
                        ke.leaveGroup(msg.to)
                        ku.leaveGroup(msg.to)
                        km.leaveGroup(msg.to)
                        kr.leaveGroup(msg.to)
                        kd.leaveGroup(msg.to)
                        kw.leaveGroup(msg.to)
                        kn.leaveGroup(msg.to)
                        kt.leaveGroup(msg.to)
                        ky.leaveGroup(msg.to)
                        kh.leaveGroup(msg.to)
                        kz.leaveGroup(msg.to)
                        sd.leaveGroup(msg.to)
                        cl.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Option bye"]:
              if msg.from_ in owner:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ka.leaveGroup(msg.to)
                        kb.leaveGroup(msg.to)
                        ko.leaveGroup(msg.to)
                        ke.leaveGroup(msg.to)
                        ku.leaveGroup(msg.to)
                        km.leaveGroup(msg.to)
                        kr.leaveGroup(msg.to)
                        kd.leaveGroup(msg.to)
                        kw.leaveGroup(msg.to)
                        kn.leaveGroup(msg.to)
                        kt.leaveGroup(msg.to)
                        ky.leaveGroup(msg.to)
                        kh.leaveGroup(msh.to)
                        kz.leaveGroup(msg.to)
                    except:
                        pass
            elif "Leave on: " in msg.text:
                ng = msg.text.replace("Leave on: ","")
                gid = cl.getGroupIdsJoined()
                if msg.from_ in owner:
                    for i in gid:
                        h = cl.getGroup(i).name
                        if h == ng:                                          
                            cl.sendText(i,"Bye")
                            ki.leaveGroup(i)
                            kk.leaveGroup(i)
                            kc.leaveGroup(i)
                            ks.leaveGroup(i)
                            ka.leaveGroup(i)
                            kb.leaveGroup(i)
                            ko.leaveGroup(i)
                            ke.leaveGroup(i)
                            ku.leaveGroup(i)
                            km.leaveGroup(i)
                            kr.leaveGroup(i)
                            kd.leaveGroup(i)
                            kw.leaveGroup(i)
                            kn.leaveGroup(i)
                            kt.leaveGroup(i)
                            ky.leaveGroup(i)
                            kh.leaveGroup(i)
                            kz.leaveGroup(i)
                            sd.leaveGroup(i)
                            cl.leaveGroup(i)
                            cl.sendText(msg.to,"Success Left ["+ h +"] group")
                        else:
                            pass
                else:
                    cl.sendText(msg.to,"Ur not owner ^_^")

            elif "Leave semua grup" == msg.text:
                gid = cl.getGroupIdsJoined()
                if msg.from_ in Creator:
                    for i in gid:
                        cl.sendText(i,"Bye..all")
                        ki.leaveGroup(i)
                        kk.leaveGroup(i)
                        kc.leaveGroup(i)
                        ks.leaveGroup(i)
                        ka.leaveGroup(i)
                        kb.leaveGroup(i)
                        ko.leaveGroup(i)
                        ke.leaveGroup(i)
                        ku.leaveGroup(i)
                        km.leaveGroup(i)
                        kr.leaveGroup(i)
                        kd.leaveGroup(i)
                        kw.leaveGroup(i)
                        kn.leaveGroup(i)
                        kt.leaveGroup(i)
                        ky.leaveGroup(i)
                        kh.leaveGroup(i)
                        kz.leaveGroup(i)
                        sd.leaveGroup(i)
                        cl.leaveGroup(i)
                    cl.sendText(msg.to,"Success Leave All Group")
                else:
                    cl.sendText(msg.to,"Ur not Admin")

            elif msg.text in ["Bye bot sider"]:
              if msg.from_ in admin:
                if msg.toType == 2:                                                                    
                    ginfo = sd.getGroup(msg.to)                                                        
                    try:
                        sd.sendText(msg.to,"ヽ(`Д´)ﾉ Aim di usir.....\nkaka jahadddd....~>_<~")
                        time.sleep(1.0)
                        sd.leaveGroup(msg.to)                                                          
                    except:                                                                                
                        pass
            elif msg.text in ["Bye lisa"]:                                                              
              if msg.from_ in owner:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        cl.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye parry"]:
              if msg.from_ in owner:
                if msg.toType == 2:
                    ginfo = ki.getGroup(msg.to)
                    try:
                        ki.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye rakko"]:
              if msg.from_ in owner:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kk.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye doctor"]:
              if msg.from_ in owner:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kc.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye eliza"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ks.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye op1"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ka.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye op2"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kb.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye op3"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ko.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye op4"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ke.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye op5"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ku.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye op6"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        km.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye op7"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kr.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye op8"]:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kd.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye op9"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kw.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye bot10"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kn.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye bot11"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kt.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye bot12"]:
              if msg.from_ in owner:                     
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ky.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye bot13"]:
              if msg.from_ in owner:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kh.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Bye bot14"]:
              if msg.from_ in owner:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kz.leaveGroup(msg.to)
                    except:
                        pass
    #-------------Fungsi Leave Group Finish---------------#
    
    #-------------Fungsi Tag All Start---------------#
            elif msg.text in ["Bot tag"]:
                if msg.from_ in admin:
                    group = sd.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]

                    cb = ""
                    cb2 = ""
                    strt = int(0)
                    akh = int(0)
                    for md in nama:
                          akh = akh + int(6)

                          cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""

                          strt = strt + int(7)
                          akh = akh + 1
                          cb2 += "@nrik \n"

                    cb = (cb[:int(len(cb)-1)])
                    msg.contentType = 0
                    msg.text = cb2
                    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}

                    try:
                        sd.sendMessage(msg)
                        #sd.sendMessage(msg)
                    except Exception as error:
                        print error
    #-------------Fungsi Tag All Finish---------------#
            elif msg.text in ["Memberlist"]:
                kontak = cl.getGroup(msg.to)
                group = kontak.members
                num=1
                msgs="LIST MEMBER"                                                                   
                for ids in group:
                    msgs+="\n[%i] %s" % (num, ids.displayName)
                    num=(num+1)
                msgs+="\n═════════════\n\nTotal Members : %i" % len(group)
                cl.sendText(msg.to, msgs)
            elif msg.text in ["Bot Like", "Bot like"]: #Semua Bot Ngelike Status Akun Utam              
              if msg.from_ in owner:                                                                      
                print "[Command]Like executed"                                                            
                cl.sendText(msg.to,"Kami Siap Like Status Owner")
                try:
                  likePost()
                except:
                  pass

            elif msg.text in ["Like temen", "Like teman"]: #Semua Bot Ngelike Status T              
              if msg.from_ in owner:                                                                      
                print "[Command]Like executed"
                cl.sendText(msg.to,"Kami Siap Like Status Teman Boss")
                try:
                  autolike()
                except:
                  pass

         #----------------Fungsi Banned Kick Target Start-----------------------#
            elif msg.text in ["Kill ban"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    G = kk.getGroup(msg.to)                                                                                     
                    ginfo = kk.getGroup(msg.to)
                    G.preventJoinByTicket = False
                    kk.updateGroup(G)
                    invsend = 0
                    Ticket = ki.reissueGroupTicket(msg.to)
                    satpam.acceptGroupInvitationByTicket(msg.to,Ticket)
                    time.sleep(0.1)
                    group = satpam.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        satpam.leaveGroup(msg.to)
                        G = cl.getGroup(msg.to)                                                               
                        G.preventJoinByTicket = True
                        random.choice(KAC).updateGroup(G)
                        return
                    for jj in matched_list:
                        try:
                            satpam.kickoutFromGroup(msg.to,[jj])
                            ks.sendText(msg.to,"このユーザはブラックリストに載っていないよ(｀・ω・´)\n※一時的なブラックリストに載っている可能性あり。\n\n09:37:05")
                            satpam.leaveGroup(msg.to)
                            G.preventJoinByTicket = True
                            random.choice(KAC).updateGroup(G)
                            print (msg.to,[jjl])
                            satpam.leaveGroup(msg.to)
                            random.choice(KAC).updateGroup(G)
                        except:
                            pass
         #----------------SIDER BOT----------------------#
            elif "Mid @" in msg.text:
              if msg.from_ in admin:
                _name = msg.text.replace("Mid @","")                                                              
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                        random.choice(KAC).sendText(msg.to, g.mid)                                                    
                    else:
                        pass
            elif "Sider on" in msg.text:
              if msg.from_ in admin:
                try:
                    del cctv['point'][msg.to]                                                                                   
                    del cctv['sidermem'][msg.to]
                    del cctv['cyduk'][msg.to]
                except:
                    pass                                                                                                    
                    cctv['point'][msg.to] = msg.id
                cctv['sidermem'][msg.to] = ""
                cctv['cyduk'][msg.to]=True                                                                                  
                wait["Sider"] = True
                cl.sendText(msg.to,"Sider Aktif")

            elif "Sider off" in msg.text:
              if msg.from_ in admin:
                if msg.to in cctv['point']:
                    cctv['cyduk'][msg.to]=False
                    wait["Sider"] = False                                                                                       
                    sd.sendText(msg.to, "Sider NonAktifkan")
                else:
                    cl.sendText(msg.to, "Not Set")

            elif "BUBARKAN!" in msg.text:
              if msg.from_ in owner:
                if msg.toType == 2:
                    print "ok"
                    _name = msg.text.replace("BUBARKAN!","")
                    gs = ki.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    ki.sendText(msg.to,"TERIMAKASIH SEBELUMNYA")
                    kk.sendText(msg.to,"KAMI HANYALAH BOT")
                    kc.sendText(msg.to,"APALAH DAYA,,CUMA MENJALANKAN PERINTAH!!!")
                    msg.contentType = 13
                    msg.contentMetadata = {'mid': mid}
                    ks.sendMessage(msg)
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        ki.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                          if target not in Bots:
                            try:
                                klist=[cl,ki,kk,kc,ks,ka,kb,ko,ke,ku,km,kr,kd,kw,kn,kt,ky,kh,kz,satpam]
                                kicker=random.choice(klist)
                                kicker.kickoutFromGroup(msg.to,[target])
                                print (msg.to,[g.mid])
                            except:
                                ki.sendText(msg.to,"Group cleanse")
                                
            elif "Siri bom" in msg.text:
              if msg.from_ in owner:
                if msg.toType == 2:
                    print "ok"
                    _name = msg.text.replace("Siri bom","")
                    gs = ki.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    ki.sendText(msg.to,"Ga usah di tangkis..")
                    kk.sendText(msg.to,"LEMESIN AJE,YE! \nDiem diem Duduk manisðﾟﾘﾎ")
                    kc.sendText(msg.to,"Bos aim Lagi Kesel ðﾟﾑﾇ")
                    msg.contentType = 13
                    msg.contentMetadata = {'mid': mid}
                    ks.sendMessage(msg)
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        ki.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                          if target not in Bots:
                            try:
                                klist=[cl,ki,kk,kc,ks,ka,kb,ko,ke,ku,km,kr,kd,kw,kn,kt,ky,kh,kz]
                                kicker=random.choice(klist)
                                kicker.kickoutFromGroup(msg.to,[target])
                                print (msg.to,[g.mid])
                            except:
                                ki.sendText(msg.to,"Start")

        #----------------Fungsi Kick User Target Start----------------------#
            elif "Kill " in msg.text:
                  if msg.from_ in admin:
                       nk0 = msg.text.replace("Kill ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    klist=[cl,ki,kk,kc,ks,ka,kb,ko,ke,ku,km,kr,kd,kw,kn,kt,ky,kh,kz,satpam]
                                    kicker=random.choice(klist)
                                    kicker.kickoutFromGroup(msg.to,[target])
                                    print (msg.to,[g.mid])
                                except:
                                    ki.sendText(msg.to,"このユーザはブラックリストに\n載っていないよ(｀・ω・´)\n※一時的なブラックリストに載\nている可能性あり.\n\n02:11:54")

            elif "HAJAR " in msg.text:
                  if msg.from_ in admin:
                       nk0 = msg.text.replace("HAJAR ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:                                                                                                 
                                    klist=[cl,ki,kk,kc,ks,ka,kb,ko,ke,ku,km,kr,kd,kw,kn,kt,ky,kh,kz,satpam]
                                    kicker=random.choice(klist)
                                    kicker.kickoutFromGroup(msg.to,[target])
                                    print (msg.to,[g.mid])
                                except:
                                    pass
            #elif msg.text in ["Crash","crash"]:
                    #if msg.from_ not in admin:
                        #if msg.toType == 2:
                            #random.choice(KAC).kickoutFromGroup(msg.to,[msg.from_])
                            #cl.sendText(msg.to,"BLACKLIST(｀・ω・´)")
            #elif msg.text in ["Kick on","!kick on","kickall","!salken ya","!kickall"]:
                    #if msg.from_ not in admin:
                        #if msg.toType == 2:
                            #random.choice(KAC).kickoutFromGroup(msg.to,[msg.from_])
                            #cl.sendText(msg.to,"BLACKLIST(｀・ω・´)")
                            #print "user nulis kick on"
    
            elif msg.text in ["Kickall"]:
                    if msg.from_ not in admin:
                        if msg.toType == 2:
                            random.choice(KAC).kickoutFromGroup(msg.to,[msg.from_])                                                  
                            cl.sendText(msg.to,"BLACKLIST(｀・ω・´)")
                            print "user nulis kickall"

            elif msg.text.lower() in dangerMessage:
                    if msg.from_ not in admin:
                        if msg.toType == 2:                                                                                             
                            random.choice(KAC).kickoutFromGroup(msg.to,[msg.from_])
                            cl.sendText(msg.to,"BLACKLIST(｀・ω・´)")
                            print "user nulis komanfo danger"

            #elif msg.text in ["Kick:on"]:
                    #if msg.from_ not in admin:
                        #if msg.toType == 2:
                            #random.choice(KAC).kickoutFromGroup(msg.to,[msg.from_])                                                     
                            #cl.sendText(msg.to,"BLACKLIST(｀・ω・´)")
                            #print "user nulis kick:on"

            #elif msg.text in "Kick @":
                #if msg.from_ not in admin:
                    #if msg.toType == 2:
                        #random.choice(KAC).kickoutFromGroup(msg.to,[msg.from_])
                        #cl.sendText(msg.to,"BLACKLIST(｀・ω・´)")
                        #print "user nulis kick @"

            #elif msg.text in "Kill":
                #if msg.from_ not in admin:
                    #if msg.toType == 2:
                        #random.choice(KAC).kickoutFromGroup(msg.to,[msg.from_])
                        #cl.sendText(msg.to,"BLACKLIST(｀・ω・´)")
                        #print "user nulis kill"

            #elif msg.text.lower() in "Fuck @":
                #if msg.from_ not in admin:
                    #if msg.toType == 2:
                        #random.choice(KAC).kickoutFromGroup(msg.to,[msg.from_])
                        #cl.sendText(msg.to,"BLACKLIST(｀・ω・´)")
        #----------------Fungsi Kick User Target Finish----------------------#      
            elif "Blacklist @ " in msg.text:
              if msg.from_ in admin:
                _name = msg.text.replace("Blacklist @ ","")
                _kicktarget = _name.rstrip(' ')
                gs = ki2.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _kicktarget == g.displayName:
                        targets.append(g.mid)
                        if targets == []:
                            cl.sendText(msg.to,"Not found")
                        else:
                            for target in targets:
                                try:
                                    wait["blacklist"][target] = True
                                    f=codecs.open('st2__b.json','w','utf-8')
                                    json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                    k3.sendText(msg.to,"Succes Cv")
                                except:
                                    ki.sendText(msg.to,"error")
            
            #----------------Fungsi Banned User Target Start-----------------------#
            elif "Banned @" in msg.text:
              if msg.from_ in admin:
                if msg.toType == 2:
                    print "[Banned] Sukses"
                    _name = msg.text.replace("Banned @","")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    gs = ki.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Dilarang Banned Bot")
                    else:
                        for target in targets:
                            try:
                                wait["blacklist"][target] = True
                                f=codecs.open('st2__b.json','w','utf-8')
                                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendText(msg.to,"Akun telah sukses di banned")
                            except:
                                ki.sendText(msg.to,"Error")
            #----------------Fungsi Banned User Target Finish-----------------------# 
            elif "Music " in msg.text:
                say = msg.text.replace("Music ","")
                lang = 'id'
                tts = gTTS(text=Voice, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")
            
    #---Sc jika ada orang yg tag kita langsung di respon bot---
            elif "Fancytext: " in msg.text:
              if msg.from_ in admin:
                    txt = msg.text.replace("Fancytext: ", "")
                    cl.kedapkedip(msg.to,txt)
                    print "[Command] Kedapkedip"
            elif "cover @" in msg.text:
              if msg.from_ in admin:
                if msg.toType == 2:
                    cover = msg.text.replace("cover @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.channel.getHome(target)
                                objId = h["result"]["homeInfo"]["objectId"]
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/myhome/c/download.nhn?userid=" + target + "&oid=" + objId)
                            except Exception as error:
                                print error
                                cl.sendText(msg.to,"Upload image failed.")

            elif "Cover @" in msg.text:
              if msg.from_ in admin:
                if msg.toType == 2:
                    cover = msg.text.replace("Cover @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.channel.getHome(target)
                                objId = h["result"]["homeInfo"]["objectId"]
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/myhome/c/download.nhn?userid=" + target + "&oid=" + objId)
                            except Exception as error:
                                print error
                                cl.sendText(msg.to,"Upload image failed.")

            elif "pp @" in msg.text:
              if msg.from_ in admin:
                if msg.toType == 2:
                    cover = msg.text.replace("pp @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)                                                                                                                                                       
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.getContact(target)
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + h.pictureStatus)
                            except Exception as error:
                                print error
                                cl.sendText(msg.to,"Upload image failed.")

            elif "Pp @" in msg.text:
              if msg.from_ in admin:
                if msg.toType == 2:
                    cover = msg.text.replace("Pp @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.getContact(target)
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + h.pictureStatus)
                            except Exception as error:
                                print error
                                cl.sendText(msg.to,"Upload image failed.")

            elif msg.text.lower() in ["pap owner","pap creator"]:
                            if msg.from_ in admin:
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/0hNPsZGNvyEX9OIz0w4GxuKHJmHxI5DRc3NkJaETwkRklqGwQoJkNbTGklHRo2G1B7cxFXH2NxSU03")
            elif "Getgroup image" in msg.text:
              if msg.from_ in admin:
                group = cl.getGroup(msg.to)
                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                cl.sendImageWithURL(msg.to,path)

            elif "Getprofile" in msg.text:
              if msg.from_ in admin:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]                                                                                                       
                contact = cl.getContact(key1)
                cu = cl.channel.getCover(key1)
                path = str(cu)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                try:
                    cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nBio :\n" + contact.statusMessage)
                    cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                    cl.sendImageWithURL(msg.to,image)
                    cl.sendText(msg.to,"Cover " + contact.displayName)
                    cl.sendImageWithURL(msg.to,path)
                except:
                    pass

            elif "Copy1 @" in msg.text:
              if msg.from_ in admin:                                                                  
                   print "lisa copy profile"
                   _name = msg.text.replace("Copy1 @","")
                   _nametarget = _name.rstrip('  ')
                   gs = cl.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       cl.sendText(msg.to, "Not Found...")
                   else:
                       for target in targets:
                            try:
                               cl.CloneContactProfile(target)
                               cl.sendText(msg.to, "Niru profil artis")
                            except Exception as e:
                                print e
                                
            elif "Copy2 @" in msg.text:
              if msg.from_ in admin:
                   print "parry copy profile"
                   _name = msg.text.replace("Copy2 @","")
                   _nametarget = _name.rstrip('  ')
                   gs = ki.getGroup(msg.to)
                   targets = []
                   for g in gs.members:                                                                   
                       if _nametarget == g.displayName:
                           targets.append(g.mid)                                                      
                   if targets == []:                                                                     
                       ki.sendText(msg.to, "Not Found...")
                   else:                                                                                  
                       for target in targets:
                            try:
                               ki.CloneContactProfile(target)
                               ki.sendText(msg.to, "Nempel profil artis")
                            except Exception as e:
                                print e

            elif "Copy3 @" in msg.text:
              if msg.from_ in admin:
                   print "rakko copy profile"
                   _name = msg.text.replace("Copy3 @","")
                   _nametarget = _name.rstrip('  ')
                   gs = kk.getGroup(msg.to)
                   targets = []
                   for g in gs.members:                                                                   
                       if _nametarget == g.displayName:
                           targets.append(g.mid)                                                      
                   if targets == []:                                                                     
                       kk.sendText(msg.to, "Not Found...")
                   else:                                                                                  
                       for target in targets:
                            try:
                               kk.CloneContactProfile(target)
                               kk.sendText(msg.to, "Nempel profil artis")
                            except Exception as e:
                                print e

            elif "Copy4 @" in msg.text:
              if msg.from_ in admin:
                   print "doctorA copy profile"
                   _name = msg.text.replace("Copy4 @","")
                   _nametarget = _name.rstrip('  ')
                   gs = kc.getGroup(msg.to)
                   targets = []
                   for g in gs.members:                                                                   
                       if _nametarget == g.displayName:
                           targets.append(g.mid)                                                      
                   if targets == []:                                                                     
                       kc.sendText(msg.to, "Not Found...")
                   else:                                                                                  
                       for target in targets:
                            try:
                               kc.CloneContactProfile(target)
                               kc.sendText(msg.to, "Nempel profil artis")
                            except Exception as e:
                                print e

            elif "Copy5 @" in msg.text:
              if msg.from_ in admin:
                   print "Elisah copy profile"
                   _name = msg.text.replace("Copy5 @","")
                   _nametarget = _name.rstrip('  ')
                   gs = ks.getGroup(msg.to)
                   targets = []
                   for g in gs.members:                                                                   
                       if _nametarget == g.displayName:
                           targets.append(g.mid)                                                      
                   if targets == []:                                                                     
                       ks.sendText(msg.to, "Not Found...")
                   else:                                                                                  
                       for target in targets:
                            try:
                               ks.CloneContactProfile(target)
                               ks.sendText(msg.to, "Nempel profil artis")
                            except Exception as e:
                                print e

            elif "Copy6 @" in msg.text:
              if msg.from_ in admin:
                   print "5 bot utama copy profile"
                   _name = msg.text.replace("Copy6 @","")
                   _nametarget = _name.rstrip('  ')
                   gs = ki.getGroup(msg.to)
                   gs = kk.getGroup(msg.to)
                   gs = kc.getGroup(msg.to)
                   gs = ks.getGroup(msg.to)
                   gs = cl.getGroup(msg.to)
                   targets = []
                   for g in gs.members:                                                                   
                       if _nametarget == g.displayName:
                           targets.append(g.mid)                                                      
                   if targets == []:                                                                     
                       cl.sendText(msg.to, "Not Found...")
                   else:                                                                                  
                       for target in targets:
                            try:
                               ki.CloneContactProfile(target)
                               kk.CloneContactProfile(target)
                               kc.CloneContactProfile(target)
                               ks.CloneContactProfile(target)
                               cl.CloneContactProfile(target)
                               cl.sendText(msg.to, "siri copy profil artis")
                            except Exception as e:
                                print e

            elif "Op copy @" in msg.text:
              if msg.from_ in admin:
                   print "10 bot op copy profile"
                   _name = msg.text.replace("Op copy @","")
                   _nametarget = _name.rstrip('  ')
                   gs = ka.getGroup(msg.to)
                   gs = kb.getGroup(msg.to)
                   gs = ko.getGroup(msg.to)
                   gs = ke.getGroup(msg.to)
                   gs = ku.getGroup(msg.to)
                   gs = km.getGroup(msg.to)
                   gs = kr.getGroup(msg.to)
                   gs = kd.getGroup(msg.to)
                   gs = kw.getGroup(msg.to)
                   gs = kn.getGroup(msg.to)
                   gs = kt.getGroup(msg.to)
                   gs = ky.getGroup(msg.to)
                   gs = kh.getGroup(msg.to)
                   gs = kz.getGroup(msg.to)
                   gs = cl.getGroup(msg.to)
                   targets = []
                   for g in gs.members:                                                                   
                       if _nametarget == g.displayName:
                           targets.append(g.mid)                                                      
                   if targets == []:                                                                     
                       cl.sendText(msg.to, "Not Found...")
                   else:                                                                                  
                       for target in targets:
                            try:
                               ka.CloneContactProfile(target)
                               kb.CloneContactProfile(target)
                               ko.CloneContactProfile(target)
                               ke.CloneContactProfile(target)
                               ku.CloneContactProfile(target)
                               km.CloneContactProfile(target)
                               kr.CloneContactProfile(target)
                               kd.CloneContactProfile(target)
                               kw.CloneContactProfile(target)
                               kn.CloneContactProfile(target)
                               kt.CloneContactProfile(target)
                               ky.CloneContactProfile(target)
                               kh.CloneContactProfile(target)
                               kz.CloneContactProfile(target)
                               ka.sendText(msg.to, "siri copy profil artis")
                            except Exception as e:
                                print e

            elif msg.text in ["Backup1","Back1"]:
                if msg.from_ in admin:
                    try:
                        cl.updateDisplayPicture(backupX1.pictureStatus)
                        cl.updateProfile(backupX1)
                        cl.sendText(msg.to, "Refreshed.")
                    except Exception as e:
                        cl.sendText(msg.to, str(e))
                        
            elif msg.text in ["Backup2","Back2"]:
                if msg.from_ in admin:
                    try:
                        ki.updateDisplayPicture(backupX2.pictureStatus)
                        ki.updateProfile(backupX2)
                        ki.sendText(msg.to, "Thanks")
                    except Exception as e:
                        ki.sendText(msg.to, str(e))
                                   
            elif msg.text in ["Backup3","Back3"]:
                if msg.from_ in admin:
                    try:
                        kk.updateDisplayPicture(backupX3.pictureStatus)
                        kk.updateProfile(backupX3)
                        kk.sendText(msg.to, "Refreshed.")
                    except Exception as e:
                        kk.sendText(msg.to, str(e))
                        
            elif msg.text in ["Backup4","Back4"]:
                if msg.from_ in admin:
                    try:
                        kc.updateDisplayPicture(backupX4.pictureStatus)
                        kc.updateProfile(backupX4)
                        kc.sendText(msg.to, "Thanks")
                    except Exception as e:
                        kc.sendText(msg.to, str(e))

            elif msg.text in ["Backup5","Back5"]:
                if msg.from_ in admin:
                    try:
                        ks.updateDisplayPicture(backupX5.pictureStatus)
                        ks.updateProfile(backupX5)
                        ks.sendText(msg.to, "Refreshed.")
                    except Exception as e:
                        ks.sendText(msg.to, str(e))
                        
            elif msg.text in ["Backup6","Back6"]:
                if msg.from_ in admin:
                    try:
                        ka.updateDisplayPicture(backupX6.pictureStatus)
                        ka.updateProfile(backupX6)
                        ka.sendText(msg.to, "Thanks")
                    except Exception as e:
                        ka.sendText(msg.to, str(e))
                                   
            elif msg.text in ["Backup7","Back7"]:
                if msg.from_ in admin:
                    try:
                        kb.updateDisplayPicture(backupX7.pictureStatus)
                        kb.updateProfile(backupX7)
                        kb.sendText(msg.to, "Refreshed.")
                    except Exception as e:
                        kb.sendText(msg.to, str(e))
                        
            elif msg.text in ["All backup","All back"]:
                if msg.from_ in admin:
                    try:
                        ki.updateDisplayPicture(backupX2.pictureStatus)
                        ki.updateProfile(backupX2)
                                   
                        kk.updateDisplayPicture(backupX3.pictureStatus)
                        kk.updateProfile(backupX3)
                                   
                        kc.updateDisplayPicture(backupX4.pictureStatus)
                        kc.updateProfile(backupX4)
                                   
                        ks.updateDisplayPicture(backupX5.pictureStatus)
                        ks.updateProfile(backupX5)

                        cl.updateDisplayPicture(backupX1.pictureStatus)
                        cl.updateProfile(backupX1)       
                        cl.sendText(msg.to, "refresh....")
                    except Exception as e:
                        cl.sendText(msg.to, str(e))
            elif msg.text in ["All op backup","All op back"]:
                if msg.from_ in admin:
                    try:
                        ka.updateDisplayPicture(backupX6.pictureStatus)
                        ka.updateProfile(backupX6)
                                   
                        kb.updateDisplayPicture(backupX7.pictureStatus)
                        kb.updateProfile(backupX7)
                                   
                        ko.updateDisplayPicture(backupX8.pictureStatus)
                        ko.updateProfile(backupX8)
                                   
                        ke.updateDisplayPicture(backupX9.pictureStatus)
                        ke.updateProfile(backupX9)

                        ku.updateDisplayPicture(backupX10.pictureStatus)
                        ku.updateProfile(backupX10)
                                   
                        km.updateDisplayPicture(backupX11.pictureStatus)
                        km.updateProfile(backupX11)
                                   
                        kr.updateDisplayPicture(backupX12.pictureStatus)
                        kr.updateProfile(backupX12)
                                   
                        kd.updateDisplayPicture(backupX13.pictureStatus)
                        kd.updateProfile(backupX13)

                        kw.updateDisplayPicture(backupX14.pictureStatus)
                        kw.updateProfile(backupX14)
                                 
                        kn.updateDisplayPicture(backupX15.pictureStatus)
                        kn.updateProfile(backupX15)
                                   
                        kt.updateDisplayPicture(backupX16.pictureStatus)
                        kt.updateProfile(backupX16)
                                   
                        ky.updateDisplayPicture(backupX17.pictureStatus)
                        ky.updateProfile(backupX517)

                        kh.updateDisplayPicture(backupX18.pictureStatus)
                        kh.updateProfile(backupX18)
                                   
                        kz.updateDisplayPicture(backupX19.pictureStatus)
                        kz.updateProfile(backupX19)      
                        ka.sendText(msg.to, "all copy refresh....")
                    except Exception as e:
                        ka.sendText(msg.to, str(e))
                                   
            elif "Music " in msg.text:
                say = msg.text.replace("Music ","")
                lang = 'id'
                tts = gTTS(text=Voice, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")
            elif "@Riki " in msg.text:
                tanya = msg.text.replace("@Riki ","")
                jawab = ("Jgn Tag Si Riki...","Berisik jgn tag si Riki...,","Sekali lagi nge tag gw sumpahin jomblo seumur hidup")
                jawaban = random.choice(jawab)
                cl.sendText(msg.to,jawaban)
                
            elif "Stealhome @" in msg.text:
              if msg.from_ in admin:
                print "[Command]dp executing"                                                                     
                _name = msg.text.replace("Stealhome @","")
                _nametarget = _name.rstrip('  ')                                                                  
                gs = cl.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _nametarget == g.displayName:
                        targets.append(g.mid)
                if targets == []:
                    ki.sendText(msg.to,"Contact not found")
                else:
                    for target in targets:
                        try:
                            contact = cl.getContact(target)
                            cu = cl.channel.getCover(target)
                            path = str(cu)
                            cl.sendImageWithURL(msg.to, path)
                        except:
                            pass
                print "[Command]dp executed"
                
            elif "Stealdp @" in msg.text:
              if msg.from_ in admin:
                print "[Command]dp executing"
                _name = msg.text.replace("Stealdp @","")                                                          
                _nametarget = _name.rstrip('  ')
                gs = cl.getGroup(msg.to)                                                                          
                targets = []
                for g in gs.members:                                                                                  
                    if _nametarget == g.displayName:
                        targets.append(g.mid)                                                                     
                if targets == []:
                    ki.sendText(msg.to,"Contact not found")
                else:
                    for target in targets:
                        try:
                            contact = cl.getContact(target)
                            path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            cl.sendImageWithURL(msg.to, path)
                        except:
                            pass
                            
            elif "StealG" in msg.text:
                    group = cl.getGroup(msg.to)
                    cl.sendMessage(msg.to,"Group Photo:\n=> http://dl.profile.line-cdn.net/" + group.pictureStatus + "")
            elif "Spam @" in msg.text:
              if msg.from_ in admin:
                _name = msg.text.replace("Spam @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                       cl.sendText(g.mid,"Spam")
                       cl.sendText(g.mid,"Spam")
                       cl.sendText(g.mid,"Spam")
                       cl.sendText(g.mid,"Spam")
                       cl.sendText(g.mid,"Spam")
                       cl.sendText(g.mid,"Spam")
                       cl.sendText(g.mid,"STICKER GRATIS ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.")
                       cl.sendText(g.mid,"STICKER FREE ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.")
                       cl.sendText(g.mid,"Spam")
                       cl.sendText(g.mid,"Spam")
                       cl.sendText(g.mid,"Spam")
                       cl.sendText(g.mid,"Spam")
                       cl.sendText(g.mid,"Spam")
                       cl.sendText(msg.to, "Done")
                       print " Spammed !"
            
            #----------------Fungsi Unbanned User Target Start-----------------------#
            elif "Unban @" in msg.text:
              if msg.from_ in admin:
                if msg.toType == 2:
                    print "[Unban] Sukses"
                    _name = msg.text.replace("Unban @","")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    gs = ki.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"there is..")
                        ki.sendText(msg.to,"There is..")                                              
                    else:
                        for target in targets:
                            try:
                                del wait["blacklist"][target]
                                f=codecs.open('st2__b.json','w','utf-8')
                                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendText(msg.to,"Account clear")
                            except:
                                ki.sendText(msg.to,"Error")
           #----------------Fungsi Unbanned User Target Finish-----------------------#
           
        #-------------Fungsi Spam Start---------------------#
            elif msg.text in ["Up&","up&","Up Chat&","Up chat&","up chat&","Upchat&","upchat&"]:
              if msg.from_ in owner:
                cl.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                ki.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                kk.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                cl.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                ki.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                kk.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                cl.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                ki.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                kk.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                cl.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                ki.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                kk.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                cl.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                ki.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                kk.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                cl.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                ki.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                kk.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                cl.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                ki.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                kk.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                cl.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                ki.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                kk.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                cl.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                ki.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                kk.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                cl.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                ki.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
                kk.sendText(msg.to,"P ôﾀﾔﾃôﾀﾆﾶsquared up!ôﾏ﾿﾿")
        #-------------Fungsi Spam Finish---------------------#
            elif "Midd @" in msg.text:
              if msg.from_ in admin:
                _name = msg.text.replace("Midd @","")                                                      
                _nametarget = _name.rstrip(' ')                                                           
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                        random.choice(KAC).sendText(msg.to, g.mid)
                    else:
                        pass

        #-------------Fungsi Broadcast Start------------#
            elif msg.text in ["Glistmid"]:
              if msg.from_ in admin:
                gruplist = kr.getGroupIdsJoined()                                                                 
                kontak = kr.getGroups(gruplist)
                num=1
                msgs="═════════List GrupMid═════════"
                for ids in kontak:
                    msgs+="\n[%i] %s" % (num, ids.id)
                    num=(num+1)
                msgs+="\n═════════List GrupMid═════════\n\nTotal Grup : %i" % len(kontak)
                kr.sendText(msg.to, msgs)

            elif 'Group list' in msg.text.lower():
              if msg.from_ in mid or admin:
                gs = cl.getGroupIdsJoined()
                L = "『 Groups List 』\n"
                for i in gs:
                    L += "[≫] %s \n" % (cl.getGroup(i).name + " | [ " + str(len (cl.getGroup(i).members)) + " ]")
                cl.sendText(msg.to, L + "\nTotal Group : [ " + str(len(gs)) +" ]")
            elif "Invite me " in msg.text:
              if msg.from_ in mid or admin:
                         gid = cl.getGroupIdsJoined()
		         for i in gid:
			        cl.findAndAddContactsByMid(msg.from_)
                                cl.inviteIntoGroup(i,[msg.from_])
			        cl.sendText(msg.to, "successfully invited you to all groups")
            elif "Steal group pict" in msg.text:
              if msg.from_ in mid or admin:
					group = cl.getGroup(msg.to)
					path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                        cl.sendImageWithURL(msg.to,path)
            elif "Say " in msg.text:
              if msg.from_ in admin:
				bctxt = msg.text.replace("Say ","")
				ki.sendText(msg.to,(bctxt))
				kk.sendText(msg.to,(bctxt))
				kc.sendText(msg.to,(bctxt))
       #--------------Fungsi Broadcast Finish-----------#
            elif msg.text in ["List group"]:
              if msg.from_ in admin:
                    gid = cl.getGroupIdsJoined()
                    h = ""
                    jml = 0
                    for i in gid:
                        gn = cl.getGroup(i).name
                        h += "♦【%s】\n" % (gn)
                        jml += 1
                    cl.sendText(msg.to,"↘=======[List Group]=======↙\n"+ h +"\nTotal Group: "+str(jml))
            elif msg.text in ["Cv say hi"]:
                ki.sendText(msg.to,"Hi buddy ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
#_____________________________Respon Bot_____________________________#
            elif msg.text in ["Siri:backup","siri:backup","Siri:backup"]:                                                                 
              if msg.from_ in owner:
                    wek = cl.getContact(mid)                                                                          
                    a = wek.pictureStatus
                    r = wek.displayName                                                                               
                    i = wek.statusMessage
                    wek2 = ki.getContact(Amid)                                                                          
                    a = wek2.pictureStatus
                    r = wek2.displayName                                                                               
                    i = wek2.statusMessage
                    wek3 = kk.getContact(Bmid)                                                                          
                    a = wek3.pictureStatus
                    r = wek3.displayName                                                                               
                    i = wek3.statusMessage
                    wek4 = kc.getContact(Cmid)                                                                          
                    a = wek4.pictureStatus
                    r = wek4.displayName                                                                               
                    i = wek4.statusMessage
                    wek5 = ks.getContact(Dmid)                                                                          
                    a = wek5.pictureStatus
                    r = wek5.displayName                                                                               
                    i = wek5.statusMessage
                    wek6 = ka.getContact(Emid)                                                                          
                    a = wek6.pictureStatus
                    r = wek6.displayName                                                                               
                    i = wek6.statusMessage
                    wek7 = kb.getContact(Fmid)                                                                          
                    a = wek7.pictureStatus
                    r = wek7.displayName                                                                               
                    i = wek7.statusMessage
                    wek8 = ko.getContact(Gmid)                                                                          
                    a = wek8.pictureStatus
                    r = wek8.displayName                                                                               
                    i = wek8.statusMessage
                    wek9 = ke.getContact(Hmid)                                                                          
                    a = wek9.pictureStatus
                    r = wek9.displayName                                                                               
                    i = wek9.statusMessage
                    wek10 = ku.getContact(Imid)                                                                          
                    a = wek10.pictureStatus
                    r = wek20.displayName                                                                               
                    i = wek10.statusMessage
                    wek11 = km.getContact(Jmid)                                                                          
                    a = wek11.pictureStatus
                    r = wek11.displayName                                                                               
                    i = wek11.statusMessage
                    wek12 = kr.getContact(Kmid)                                                                          
                    a = wek12.pictureStatus
                    r = wek12.displayName                                                                               
                    i = wek12.statusMessage
                    wek13 = kd.getContact(Lmid)                                                                          
                    a = wek13.pictureStatus
                    r = wek13.displayName                                                                               
                    i = wek13.statusMessage
                    wek14 = kw.getContact(Mmid)                                                                          
                    a = wek14.pictureStatus
                    r = wek14.displayName                                                                               
                    i = wek14.statusMessage
                    wek15 = kn.getContact(Nmid)                                                                          
                    a = wek15.pictureStatus
                    r = wek15.displayName                                                                               
                    i = wek15.statusMessage
                    wek16 = kt.getContact(Omid)                                                                          
                    a = wek16.pictureStatus
                    r = wek16.displayName                                                                               
                    i = wek16.statusMessage
                    wek17 = ky.getContact(Pmid)                                                                          
                    a = wek17.pictureStatus
                    r = wek17.displayName                                                                               
                    i = wek17.statusMessage
                    wek18 = kh.getContact(Qmid)                                                                          
                    a = wek18.pictureStatus
                    r = wek18.displayName                                                                               
                    i = wek18.statusMessage
                    wek19 = kz.getContact(Rmid)                                                                          
                    a = wek19.pictureStatus
                    r = wek19.displayName                                                                               
                    i = wek19.statusMessage
                    s = open('mydn.txt',"w")
                    s.write(r)
                    s.close()
                    t = open('mysm.txt',"w")
                    t.write(i)
                    t.close()                                                                                         
                    u = open('myps.txt',"w")
                    u.write(a)
                    u.close()
                    kk.sendText(msg.to,"バックアップを更新しました。\n現在、合計で1個のバックアッ\nを保存しています(｀・ω・´)\n\n " + datetime.today().strftime('%H:%M:%S'))
                    print wek                                                                          
                    print a                                                                            
                    print r
            elif msg.text in ["Siri:version","siri:version","siri:Version"]:
                cl.sendText(msg.to,"私のバージョンは、10.4.0 (Build 10018 Jan 04 2018 11:13:58)だよ☆\n-----------------------\nもう一人で開発する規模じゃない気がする>_<\n-----------------------\nv2:全蹴りbot対策導入しました\nv3:新機能を入れられるように改善しました\nv4:高速化(｀・ω・´)\nv5:信頼性うｐ\nv6:機能追加追加〜♪\nv7:LINEの仕様変更に対応>_<\nv8:5人でグル守るぞぉ(｀・ω・´)\nv9:LEGY仮対応\nv10:LEGYに本格対応☆\n-----------------------\nメンテナンスモード : Off\nServer : Tokyo \n\n " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Siri backups","siri backups","Siri Backups"]:
              if msg.from_ in admin:
                ki.sendText(msg.to,"バックアップを更新しました。\n現在、合計で13個のバックアッ\nを保存しています(｀・ω・´)\n\n " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Siri:backup","siri:backup"]:
                kk.sendText(msg.to,"グループアイコンが設定されていないので\nアイコンロックできないよ>_<\n\n " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["siri:help","Siri:help","Siri:Help"]:
                cl.sendText(msg.to,"しりちゃんは以下のコマンドが使えます。\n---\n「Siri:オフ」：しりちゃんを黙らせます。\n「Siri:オン」：しりちゃんを喋らせます。\n---\n「Siri:招待URL拒否」：URL/QRを使用した招待をブロックします。\n---\n「Siri:バックアップ」：メンバーリストを保存します。\n「Siri:グル作成者」：LINEに情報が残っている場合、グルの作成者を表示します。\n「Siri:予備作成者」：設定されている予備作成者を表示します。\n---\n「Siri:招待URL生成」：グループに参加するためのURLを発行します。\n「Siri:招待キャンセル」：すべての招待をキャンセルしま\n「Siri:bye」:しりちゃんを退会させ完全にしりちゃんの機能を止めます。\n「Siri:招待回数」：残りの招待可能回数を表示します。\n「Siri:追加アカウント購入」：追加アカウントの招待可能数を購入します。\n「Siri:ログイン」：グループを復元したいときに使用します\n「Siri:隠しコマンド」:隠しコマンド。\n---\n「Siri:絵の作者」：しりちゃんに使っている絵の作者を出します\n「Siri:作者」:しりちゃんの作者を表示します。\n---\n\n「Siri:バージョン」：しりちゃんのバージョンを表示します\n「Siri:ヘルプ」：しりちゃんが使えるコマンドを表示します。\n---\n「設定:ヘルプ」：グループ内で使用する細かな設定集一覧です\n\n---\n「Siri:荒らし報告」：荒らしユーザを通報す\nるためのアカウントを表示します。\n---\n「既読ポイント設定」：らっこさんで既読を確認するポイントを設定します。\n「既読確認」：らっこさんで設定したポイン\nトに既読をつけたユーザを表示します。\n---\n\nEnglish Commands is here → http://sirichan.xyz/blog/85.html\n\nしりちゃんをグループに招待するには招待権\nの購入が必要です\n詳しくは→http://sirichan.xyz/2015/10/v6.html\n\nたまにこのヘルプを覗くとコマンドが増えて\nたりするかもね(｀・ω・´)\n\nそれでは、快適(?)なしりちゃんライフを！\nhttp://sirichan.xyz/\nhttp://twitter.com/sirichan_line\n\n※このヘルプは、グループでは1\n分に一回のみ表示できます\n\n "+ datetime.today().strftime('%H:%M:%S'))
            #elif msg.text in ["Set:check","set:check","Set:Check","set check","Set check"]:
                #kk.sendText(msg.to,"このグループでは以下のように設定されています(｀・ω・´)\n\nユーザによる招待拒否 : オフ\nURL招待拒否 : オン\nグループ作成者ロック : オン\n現在の作成者 : \nグループ名ロック : オフ\nアイコンロック : オフ\n予備作成者 : ナシ\nらっこさん : オン\nスタンプ規制 : オフ\n応答 : オン\nLanguage : Japanese\nSelect 「Status」for english help\n独自ホワイト&ブラック件数 : 0\nメンバー数 : 1\n招待ユーザ数 : 2\n追加保護ボット招待可能数 : 7\n追加保護ボット招待数 : 0\n\n" + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["siri on","On","Siri on","Siri on","Siri:on"]:
                BRB =[ki,kk,kc,ks]
                random.choice(BRB).sendText(msg.to,"こんにちは！ \n\n "  + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Siri:off","siri:off","Siri off","siri off"]:
                BRB =[ki,kk,kc,ks]
                random.choice(BRB).sendText(msg.to,"バイバイ(^^)/~ \n\n" + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Set:changeowner"]:
                ki.sendText(msg.to,"「owner」「設定:確認」以外のコマンドは、グループ作成者以外は使用できないよ>_<\nグループ作成者は「admin/adminlist」で確認できるよ☆ \n\n " + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Kick saya","Kick aku"]:
                cl.updateGroup(msg.to)
                cl.KickOutFromGroup(op.param1,op.param2)
            elif msg.text in ["@-Black Dragon V9- "]:
                kr.sendText(msg.to,"Yes! Ready To Blaclist Member")
            elif msg.text in ["@-King Arthur- "]:
                Ko.sendText(msg.to,"Agen Protector ready to kick out")
            elif msg.text in ["@  ","@-The little Dog- "]:
                cl.sendText(msg.to,"Anda memanggil saya")
                cl.sendText(msg.to,"what happen?")
            elif msg.text in ["Unicode"]:
              if msg.from_ in owner:
                random.choice(KAC).sendText(msg.to,"ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.ABCDEFGHIJKLMNOPQRSTUVWXYZ.")
            elif msg.text in ["Set:changenamelock:on","set:changenamelock on","Name lock on"]:
              if msg.from_ in admin:
                ki.sendText(msg.to,"グループ名ロックしました(｀・ω・´)\n\n" + datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Set:Iconlock on","Set icon lock on","Iconlock:on","Set iconlock:on"]:
              if msg.from_ in admin:
                kk.sendText(msg.to,"アイコンロックしました(｀・ω・´)\n\n18:21:04 \n\n" + datetime.today().strftime('%H:%M:%S'))
              
#--------------------------------------------------------------------#

            #elif msg.text in ["Cv say hinata pekok"]:
                #ki.sendText(msg.to,"Hinata pekok ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
                #kk.sendText(msg.to,"Hinata pekok ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
                #kc.sendText(msg.to,"Hinata pekok ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
            #elif msg.text in ["Cv say didik pekok"]:
                #ki.sendText(msg.to,"Didik pekok ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
                #kk.sendText(msg.to,"Didik pekok ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
                #kc.sendText(msg.to,"Didik pekok ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
            #elif msg.text in ["Selamat datang"]:
                #ki.sendText(msg.to,"Semoga betah ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
                #kk.sendText(msg.to,"Salkomsel ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
                #kz.sendText(msg.to,"jangan nakal ya!!! ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
            #elif msg.text in ["Cv say chomel pekok"]:
                #ki.sendText(msg.to,"Chomel pekok ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
                #kk.sendText(msg.to,"Chomel pekok ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
                #kc.sendText(msg.to,"Chomel pekok ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
            #elif msg.text in ["welcome"]:
                #ki.sendText(msg.to,"Selamat datang kk!!")
                #kk.sendText(msg.to,"Jangan nakal ok!")
#-----------------------------------------------
            #elif msg.text in ["PING","Ping","ping"]:
                #ki.sendText(msg.to,"PONG ôﾀﾨﾁôﾀﾄﾻdouble thumbs upôﾏ﾿﾿ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
                #kk.sendText(msg.to,"PONG ôﾀﾨﾁôﾀﾄﾻdouble thumbs upôﾏ﾿﾿ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
                #kc.sendText(msg.to,"PONG ôﾀﾨﾁôﾀﾄﾻdouble thumbs upôﾏ﾿﾿ôﾀﾜﾁôﾀﾅﾔHar Harôﾏ﾿﾿")
#-----------------------------------------------
            elif "Searchid: " in msg.text:
              if msg.from_ in mid or admin:
                msgg = msg.text.replace('Searchid: ','')
                conn = cl.findContactsByUserid(msgg)
                if True:
                   msg.contentType = 13
                   msg.contentMetadata = {'mid': conn.mid}
                   cl.sendText(msg.to,"http://line.me/ti/p/~" + msgg)
                   kk.sendMessage(msg)
            elif msg.text in ["Remove all chat"]:
	      if msg.from_ in mid or admin:
		cl.removeAllMessages(op.param2)
		ki.removeAllMessages(op.param2)
		kk.removeAllMessages(op.param2)
		kc.removeAllMessages(op.param2)
		ks.removeAllMessages(op.param2)
		cl.sendText(msg.to,"Removed all chat")
            elif "Recover" in msg.text:
             if msg.from_ in mid or admin:
		thisgroup = cl.getGroups([msg.to])
		Mids = [contact.mid for contact in thisgroup[0].members]
		mi_d = Mids[:33]
		cl.createGroup("Recover", mi_d)
		cl.sendText(msg.to,"Success recover")
            elif "kedapkedip " in msg.text.lower():
              if msg.from_ in mid or admin:
                txt = msg.text.replace("kedapkedip ", "")
                cl.kedapkedip(msg.to,txt)
                print "[Command] Kedapkedip"
            elif "Steal mid" in msg.text:
              if msg.from_ in mid or admin:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                cl.sendText(msg.to,"Mc: " + key1)
            elif "Steal contact" in msg.text:
              if msg.from_ in mid or admin:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]                
                mmid = cl.getContact(key1)
                msg.contentType = 13
                msg.contentMetadata = {"mid": key1}
                cl.sendMessage(msg)#=================
       #-------------Fungsi Respon Start---------------------#
            elif msg.text in ["Backup:on"]:
              if msg.from_ in mid or admin:
                if wait["Backup"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"backup has been active\n\n"+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"backup has been enable\n\n"+ datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["Backup"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"backup has been active\n\n"+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"backup has been enable\n\n"+ datetime.today().strftime('%H:%M:%S'))
            elif msg.text in ["Backup:off"]:
              if msg.from_ in mid or admin:
                if wait["Backup"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"backup has been unactive\n\n"+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"backup has been desable\n\n"+ datetime.today().strftime('%H:%M:%S'))
                else:
                    wait["Backup"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"backup has been unactive\n\n"+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"backup has been desable\n\n"+ datetime.today().strftime('%H:%M:%S'))
                                   
            elif msg.text in ["Respon","respon","Respon Dong","respon dong"]:
              if msg.from_ in owner:
                cl.sendText(msg.to,name1)
                ki.sendText(msg.to,name2)
                kk.sendText(msg.to,name3)
                kc.sendText(msg.to,name4)
                ks.sendText(msg.to,name5)
                ka.sendText(msg.to,name6)
                kb.sendText(msg.to,name7)
                ko.sendText(msg.to,name8)
                ke.sendText(msg.to,name9)
                ku.sendText(msg.to,name10)
                km.sendText(msg.to,name11)
                kr.sendText(msg.to,name12)
                kd.sendText(msg.to,name13)
                kw.sendText(msg.to,name14)
                kn.sendText(msg.to,name15)
                kt.sendText(msg.to,name16)
                ky.sendText(msg.to,name17)
                kz.sendText(msg.to,name18)
                kh.sendText(msg.to,name19)
                sd.sendText(msg.to,"Aku mah apa Tuh..!! Cuma Bot")
      #-------------Fungsi Respon Finish---------------------#

      #-------------  FUNGSI BOT CHATTTt---------------------#
            elif msg.text in ["Chat on","Chat:on"]:
              if msg.from_ in admin:
                if wait["chat"] == True:
                    sd.sendText(msg.to,"Auto Chat On")
                else:
                    sd.sendText(msg.to,"Sudah on")
            elif msg.text in ["Chat off","Chat:off"]:
              if msg.from_ in admin:
                if wait["chat"] == False:
                    sd.sendText(msg.to,"Auto Chat sudah off")
                else:
                    sd.sendText(msg.to,"Sudah off")
            elif msg.text in ["Assalamualaikum","Asalamualaikum"]:
                if wait["chat"] == True:
                    contact = sd.getContact(msg.from_)
                    cName = contact.displayName
                    sd.sendText(msg.to,"Waalaikumsalam Wr.Wb...^_^  \n" + cName +" Silahkan masuk")
            elif msg.text in ["Hai bot","Bot","bot"]:
                if wait["chat"] == True:
                    contact = sd.getContact(msg.from_)
                    cName = contact.displayName
                    sapa = ["Hai kak ! \n "+cName +" Apa kabar..","Hai "+cName,"Iya kk @"+cName+ " bot Hadir","kk "+cName+" Manggil aku ada apa ","Oit...da paan kak @"+cName]
                    sapa2 = random.choice(sapa)
                    sd.sendText(msg.to,sapa2)
            elif msg.text in ["Sepi","sepi"]:
                if wait["chat"] == True:
                    contact = sd.getContact(msg.from_)
                    cName = contact.displayName
                    sd.sendText(msg.to,"Lagi pada Kojom kak!! \n"+ cName +"\n Kk jones ya..sini Aim Temenin")
            elif msg.text in ["Wkwkwk"]:
                if wait["chat"] == True:
                    contact = sd.getContact(msg.from_)
                    cName = contact.displayName
                    sd.sendText(msg.to,"Ih... ga punya tikel ya kak "+cName)
            elif msg.text in ["Halo","Hallo"]:
                if wait["chat"] == True:
                    contact = sd.getContact(msg.from_)
                    cName = contact.displayName
                    sd.sendText(msg.to,"Halo kak @"+ cName + " Ada Yang Bisa Saya Bantu")
            elif msg.text in ["Salken","Salken semua"]:
                if wait["chat"] == True:
                    contact = sd.getContact(msg.from_)
                    cName = contact.displayName                                                                       
                    sd.sendText(msg.to,"Salken juga kk @@"+ cName + " Jangan lupa bahagia..^_^")
            elif msg.text in ["Typo","Salah ketik"]:
                if wait["chat"] == True:
                    contact = sd.getContact(msg.from_)
                    cName = contact.displayName
                    sd.sendText(msg.to,"Hhhhh jempol mu lenjeh kak "+ cName + "kondisikan donk")
            elif msg.text in ["Diem bot"]:
                if wait["chat"] == True:
                    contact = sd.getContact(msg.from_)
                    cName = contact.displayName
                    A = ["Apa lu kk " + cName +" Bawel","Iya Aim diem deh..(>﹏<) kk @" + cName,"Dari tadi juga diem kak " + cName]
                    AB = random.choice(A)
                    sd.sendText(msg.to,AB)
            elif msg.text in ["Rame"]:                                                                        
                if wait["chat"] == True:
                    contact = sd.getContact(msg.from_)
                    cName = contact.displayName
                    AC = ["Biasa kak " + cName +" Ibu2 arisan..😂😂😂","Hhhh Klo sepi di kuburan kak " + cName,"Iya Tuh Rame Sndrian aja y..😁"]
                    AS = random.choice(A)
                    sd.sendText(msg.to,AS)
            elif msg.text in ["Sore","Met sore"]:                                                                        
                if wait["chat"] == True:
                    contact = sd.getContact(msg.from_)
                    cName = contact.displayName
                    A = ["Sore juga kak " + cName +" \nSore gni enak ny ngpayn kak..","Selamt Sore juga " + cName,"Btw lgi ngpyn kak..😎","Mt sore juga kak " + cName +"\nJangan lupa Mandi ya..bau😂😂😂"]
                    AB = random.choice(A)
                    sd.sendText(msg.to,AB)
            elif msg.text in ["Ok","Oke","Ok!"]:                                                                      
                if wait["chat"] == True:
                    contact = sd.getContact(msg.from_)
                    cName = contact.displayName
                    A = [cName + "Ok....sippp😂 ",cName +" Siappp Brother","Sippppp ntappp " + cName]
                    AB = random.choice(A)
                    sd.sendText(msg.to,AB)
      #-------------Fungsi Balesan Respon Finish---------------------#

       #-------------Fungsi Speedbot Start---------------------#
            elif msg.text in ["Owner"]:
              mdd ='u0b57006bd3ce6aec2975f70aba64f1e8'
              msg.contentType = 13
              msg.contentMetadata = {'mid': mdd}
              cl.sendText(msg.to)
            elif msg.text in ["Speedbot","Sp"]:
              if msg.from_ in admin:
                start = time.time()
                cl.sendText(msg.to, "Waiting...")
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "%sseconds" % (elapsed_time))
            elif msg.text in ["Runtime"]:
              if msg.from_ in admin:
                eltime = time.time() - mulai
                van = "Siriv10 running at "+waktu(eltime)
                cl.sendText(msg.to,van)
      #-------------Fungsi Speedbot Finish---------------------#

      #-------------Fungsi Banned Send Contact Start------------------#
            elif msg.text in ["Set invite"]:
              if msg.from_ in admin:
                 wait["winvite"] = True
                 cl.sendText(msg.to,"please send contact to invite (>﹏<)")
            elif msg.text in ["Siri invite"]:
              if msg.from_ in admin:
                 wait["winvite2"] = True
                 kk.sendText(msg.to,"Please send contact to invite ^_^")
            elif msg.text in ["Ban"]:
                if msg.from_ in admin:
                    wait["wblacklist"] = True
                    kc.sendText(msg.to,"send contact")
            elif msg.text in ["Unban"]:
                if msg.from_ in owner:
                    wait["dblacklist"] = True
                    cl.sendText(msg.to,"send contact")
            elif msg.text in ["ListGr"]: #Melihat List Group
              if msg.from_ in mid or admin:
                gids = cl.getGroupIdsJoined()
                h = ""
                for i in gids:
                  #####gn = cl.getGroup(i).name
                  h += "[•]%s Member\n" % (cl.getGroup(i).name   +"👉"+str(len(cl.getGroup(i).members)))
                  cl.sendText(msg.to,"=======[List Group]======\n"+ h +"Total Group :"+str(len(gids)))

            elif msg.text in ["LG2"]: #Melihat List Group + ID Groupnya (Gunanya Untuk Perintah InviteMeTo:)
              if msg.from_ in mid or admin:
                gid = cl.getGroupIdsJoined()
                h = ""
                for i in gid:
                  h += "[%s]:%s\n" % (cl.getGroup(i).name,i)
                  cl.sendText(msg.to,h)
      #-----------SPAM CRASH------------------#
            elif 'CRASH' in msg.text:
              if msg.from_ in owner:
                msg.contentType = 13
                msg.contentMetadata = {'mid': "NADYA,'"}
                cl.sendMessage(msg)
            elif 'BLANK' in msg.text:
              if msg.from_ in owner:
                msg.contentType = 13
                msg.contentMetadata = {'mid': "NADYA,'"}
                cl.sendMessage(msg)
      #-------------Fungsi Bannlist Start------------------#          
            elif msg.text in ["Banlist"]:
                if msg.from_ in admin:
                    if wait["blacklist"] == {}:
                        cl.sendText(msg.to,"Tidak Ada Akun Terbanned")
                    else:
                        ki.sendText(msg.to,"Blacklist user")
                        mc = ""
                        for mi_d in wait["blacklist"]:
                            mc += "->" +cl.getContact(mi_d).displayName + "\n"
                        cl.sendText(msg.to,mc)
      #-------------Fungsi Bannlist Finish------------------#  
            elif msg.text == "Setpoint":
                if msg.from_ in owner:
                    quote = ["Set the lastseens'point (｀・ω・´) \n\n10:45:20","Set the lastseens'point (｀・ω・´) \n\n11:36:10","Set the lastseens'point (｀・ω・´) \n\n18:52:15","Set the lastseens'point (｀・ω・´) \n\n05:19:12","Set the lastseens'point (｀・ω・´) \n\n01:25:12"]
                    DN = random.choice(quote)
                    cl.sendText(msg.to,DN)
                    try:
                      del wait2['readPoint'][msg.to]
                      del wait2['readMember'][msg.to]
                    except:
                        pass
                    now2 = datetime.now()
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = ""
                    wait2['setTime'][msg.to] = datetime.strftime(now2,"%H:%M")
                    wait2['ROM'][msg.to] = {}
                    #print wait2
                
            elif msg.text == "Viewlast":
               if msg.from_ in owner:
	            if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                            #print rom
                               chiya += rom[1] + "\n"
                               
                        kk.sendText(msg.to, "-------------------------%s\n「(>﹏<)\n[%s]"  % (wait2['readMember'][msg.to],chiya,setTime[msg.to]))
                    else:
                        kc.sendText(msg.to, "Please Set 「Setlastpoint」for point set\n「Viewlastseen」view read point (｀・ω・´) \n\n" + datetime.today().strftime('%H:%M:%S')) 

            elif msg.text == "setpoint":
                if msg.from_ in owner:
                    ki.sendText(msg.to,"Set the lastseens' point(｀・ω・´)  \n\n" +  datetime.today().strftime('%H:%M:%S'))
                    try:
                      del wait2['readPoint'][msg.to]
                      del wait2['readMember'][msg.to]
                    except:
                        pass
                    now2 = datetime.now()
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = ""
                    wait2['ROM'][msg.to] = {}                                                                                                             
                    #print wait2

            elif msg.text == "Cctv":
                if msg.from_ in owner:                                                                   
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                            #print rom
                               chiya += rom[1] + "\n"

                        kc.sendText(msg.to, "||ðﾟﾔﾥDI READ OLEHðﾟﾔﾥ||%s\nðﾟﾛﾡTHE BROTHER HOOD BOTðﾟﾛﾡ\n\n||ðﾟﾔﾥPELAKU CCTVðﾟﾔﾥ||\n%sðﾟﾒﾥCCTVðﾟﾒﾥ\n☞Bintian\n☞Panuan\n☞Kurapan\n☞Kudisan\n\nAmin...Ya ALLAH\nRead and View at:\n[%s]"  % (wait2['readMember'][msg.to],chiya,setTime[msg.to]))
                    else:
                        kc.sendText(msg.to, "☡Klik 「setlastpoint」Dulu Oneng\nBaru klik 「Cctv」]\n\n" + datetime.today().strftime('%H:%M:%S'))
                        
            elif msg.text == "setpoint":
                if msg.from_ in owner:
                    cl.sendText(msg.to, "Set the lastseens' point(｀・ω・´) \n\n" + datetime.today().strftime('%H:%M:%S'))
                    try:
                      del wait2['readPoint'][msg.to]
                      del wait2['readMember'][msg.to]
                    except:
                        pass
                    now2 = datetime.now()
                    wait2['readPoint'][msg.to] = msg.id
                    wait2['readMember'][msg.to] = ""
                    wait2['ROM'][msg.to] = {}
                    #print wait2

            elif msg.text == "viewseen":
                if msg.from_ in owner:
                    if msg.to in wait2['readPoint']:
                        if wait2["ROM"][msg.to].items() == []:
                            chiya = ""
                        else:
                            chiya = ""
                            for rom in wait2["ROM"][msg.to].items():
                            #print rom
                               chiya += rom[1] + "\n"

                        kk.sendText(msg.to, "||ðﾟﾌﾟTHE ONE WHO READðﾟﾌﾟ||\nðﾟﾔﾥ===============ðﾟﾔﾥ%s\n--Sirichan v10--\n\n||ðﾟﾔﾥits SIDER ðﾟﾔﾥ||\n%sCCTV\nReeading at:\n[%s]" % (wait2['readMember'][msg.to],chiya,setTime[msg.to]))
                    else:
                        kc.sendText(msg.to, "☡Klik [Setlaspoint] Proses Reading\nBaru klik [Sider]To view Sider \n\n" + datetime.today().strftime('%H:%M:%S'))

            elif msg.text in ["Setlastpoint","setlastpoint"]:                                                                                     
                subprocess.Popen("echo '' > dataSeen/"+msg.to+".txt", shell=True, stdout=subprocess.PIPE)                                    
                kk.sendText(msg.to,"Set the lastseens' point(｀・ω・´)\n\n" + datetime.today().strftime('%H:%M:%S'))
                print "Setview"
                
            elif msg.text in ["Viewlastseent","Viewlastseen","viewlastseen"]:
                lurkGroup = ""
                dataResult, timeSeen, contacts, userList, timelist, recheckData = [], [], [], [], [], []
                with open('dataSeen/'+msg.to+'.txt','r') as rr:
                    contactArr = rr.readlines()
                    for v in xrange(len(contactArr) -1,0,-1):                                                                                                                                               
                        num = re.sub(r'\n', "", contactArr[v])
                        contacts.append(num)
                        pass
                    contacts = list(set(contacts))
                    for z in range(len(contacts)):
                        arg = contacts[z].split('|')
                        userList.append(arg[0])
                        timelist.append(arg[1])
                    uL = list(set(userList))
                    for ll in range(len(uL)):
                        try:
                            getIndexUser = userList.index(uL[ll])
                            timeSeen.append(time.strftime("%H:%M:%S", time.localtime(int(timelist[getIndexUser]) / 1000)))
                            recheckData.append(userList[getIndexUser])
                        except IndexError:
                            conName.append('nones')
                            pass
                    contactId = cl.getContacts(recheckData)
                    for v in range(len(recheckData)):
                        dataResult.append(contactId[v].displayName + ' ('+timeSeen[v]+')')
                        pass
                    if len(dataResult) > 0:
                        tukang = "・"
                        grp = '\n・'.join(str(f) for f in dataResult)
                        total = '\n\nThese %iuesrs have seen at the lastseen point(｀・ω・´)\n\n (%s)' % (len(dataResult), datetime.now().strftime('%H:%M:%S'))
                        kk.sendText(msg.to, "%s %s %s" % (tukang, grp, total))
                        subprocess.Popen("echo '' > dataSeen/"+msg.to+".txt", shell=True, stdout=subprocess.PIPE)
                    else:
                        kk.sendText(msg.to,"No Viewer(｀・ω・´)\n\n" + datetime.today().strftime('%H:%M:%S'))
                    print "Viewseen"
#-----------------------
            elif msg.text in ["Cek ban"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    cocoa = ""
                    for mm in matched_list:
                        cocoa += mm + "\n"
                    cl.sendText(msg.to,cocoa + "")
            elif msg.text in ["Kill baned"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        cl.sendText(msg.to,"There was no blacklist user")                                         
                        return
                    for jj in matched_list:
                        cl.kickoutFromGroup(msg.to,[jj])
                        ki.kickoutFromGroup(msg.to,[jj])
                        kk.kickoutFromGroup(msg.to,[jj])
                        kc.kickoutFromGroup(msg.to,[jj])
                    cl.sendText(msg.to,"eksekusi.....")
                    ki.sendText(msg.to,"Blacklist kickout")
            elif msg.text in ["Siri:restart"]:
                if msg.from_ in owner:
                    cl.sendText(msg.to, "Restarting.....\n    Please wait!!!")
                    restart_program()
                    print "@Restart"
                else:
                    cl.sendText(msg.to, "No Access")
                    
            elif msg.text in [".Restart"]:
                if msg.from_ in admin:
                    cl.sendText(msg.to, "Restarting oleh admin\n    Please wait!!!")                                                  
                    restart_program()
                    print "@Restart"
                else:
                    cl.sendText(msg.to, "No Access")
            elif msg.text in ["Turn off"]:
                if msg.from_ in owner:
                 try:                                                                                          
                     import sys
                     sys.exit()                                                                            
                 except:
                     pass
                                   
            elif msg.text in ["Clear"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.invitee]
                    for _mid in gMembMids:
                        cl.cancelGroupInvitation(msg.to,[_mid])
                    cl.sendText(msg.to,"I pretended to cancel and canceled.")                    
            elif "random: " in msg.text:
              if msg.from_ in admin:
                if msg.toType == 2:
                    strnum = msg.text.replace("random: ","")
                    source_str = 'abcdefghijklmnopqrstuvwxyz1234567890@:;./_][!&%$#)(=~^|'
                    try:
                        num = int(strnum)
                        group = cl.getGroup(msg.to)
                        for var in range(0,num):
                            name = "".join([random.choice(source_str) for x in xrange(10)])
                            time.sleep(0.01)
                            group.name = name
                            cl.updateGroup(group)
                    except:
                        cl.sendText(msg.to,"Error")
            elif "albumat'" in msg.text:
                try:
                    albumtags = msg.text.replace("albumat'","")
                    gid = albumtags[:6]
                    name = albumtags.replace(albumtags[:34],"")
                    cl.createAlbum(gid,name)
                    cl.sendText(msg.to,name + "created an album")
                except:
                    cl.sendText(msg.to,"Error")
            elif "fakecat'" in msg.text:
                try:
                    source_str = 'abcdefghijklmnopqrstuvwxyz1234567890@:;./_][!&%$#)(=~^|'
                    name = "".join([random.choice(source_str) for x in xrange(10)])
                    anu = msg.text.replace("fakecat'","")
                    cl.sendText(msg.to,str(cl.channel.createAlbum(msg.to,name,anu)))
                except Exception as e:
                    try:
                        cl.sendText(msg.to,str(e))
                    except:
                        pass
#------CCTV------#
        if op.type == 55:
          try:
            if op.param1 in wait2['readPoint']:
              Name = cl.getContact(op.param2).displayName
              if Name in wait2['readMember'][op.param1]:
                 pass
              else:                                                                                               
                 wait2['readMember'][op.param1] += "\n[ðﾟﾌﾟ]" + Name
                 wait2['ROM'][op.param1][op.param2] = "[ðﾟﾌﾟ]" + Name
            else:
              cl.sendText                                                                                   
          except:
             pass
        #if op.type == 55:
          #try:                                                                                                
            #if op.param1 in wait2['readPoint']:
              #Name = ki.getContact(op.param2).displayName
              #if Name in wait2['readMember'][op.param1]:                                                           
                 #pass
              #else:   
                 #wait2['readMember'][op.param1] += "\n[ðﾟﾔﾥ]" + Name
                 #wait2['ROM'][op.param1][op.param2] = "[ðﾟﾔﾥ]" + Name
            #else:
              #ki.sendText
          #except:
             #pass
        #if op.type == 55:
          #try:                                                                                                
            #if op.param1 in wait2['readPoint']:
              #Name = kk.getContact(op.param2).displayName
              #if Name in wait2['readMember'][op.param1]:                                                           
                 #pass
              #else:              
                 #wait2['readMember'][op.param1] += "\n[♻]" + Name
                 #wait2['ROM'][op.param1][op.param2] = "[♻]" + Name
            #else:
              #kk.sendText
          #except:
             #pass
        #if op.type == 55:
          #try:                                                                                                
            #if op.param1 in wait2['readPoint']:
              #Name = kc.getContact(op.param2).displayName
              #if Name in wait2['readMember'][op.param1]:                                                           
                 #pass
              #else:
                 #wait2['readMember'][op.param1] += "\n[ðﾟﾔﾒ]" + Name
                 #wait2['ROM'][op.param1][op.param2] = "[ðﾟﾔﾒ]" + Name
            #else:
              #kc.sendText
          #except:
             #pass
        #if op.type == 55:
          #try:                                                                                                
            #if op.param1 in wait2['readPoint']:
              #Name = ks.getContact(op.param2).displayName
              #if Name in wait2['readMember'][op.param1]:                                                           
                 #pass
              #else:
                 #wait2['readMember'][op.param1] += "\n[ðﾟﾍﾒ]" + Name
                 #wait2['ROM'][op.param1][op.param2] = "[ðﾟﾍﾒ]" + Name
            #else:
              #ks.sendText
          #except:
             #pass
#--------WELCOME TO BOT---------#
        if op.type == 17:
          #if wait["welcom"] == True:
           if op.param2 in Bots:
              return
           ginfo = cl.getGroup(op.param1)
           contact = cl.getContact(op.param2)
           image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
           cl.sendImageWithURL(op.param1,image)
           sd.sendText(op.param1, "HAIY....Kk " + contact.displayName + "\nWelcome To : " + str(ginfo.name) + "\nJANGANLUPA CEK NOTE Ya kk \n\n---------------\nFounder Grup " + str(ginfo.name) + " :\n" + ginfo.creator.displayName)
           print "MEMBER HAS JOIN THE GROUP"
        if op.type == 15:
          #if wait["welcom"] == True:
           if op.param2 in Bots:
              return
           ginfo = cl.getGroup(op.param1)
           contact = cl.getContact(op.param2)
           image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
           sd.sendText(op.param1, "Good Bye Kak " + contact.displayName + "Baperan\nJangan Lupa Bahagia 😃😃")
           sd.sendImageWithURL(op.param1,image)
           print "MEMBER HAS LEFT THE GROUP"
#-----------------------#
        if op.type == 59:
            print op


     except Exception as error:
        print error
def a2():
    now2 = datetime.now()
    nowT = datetime.strftime(now2,"%M")
    if nowT[14:] in ["10","20","30","40","50","00"]:
        return False
    else:
        return True
def autolike():
    for zx in range(0,20):
      hasil = cl.activity(limit=20)
      if hasil['result']['posts'][zx]['postInfo']['liked'] == False:
        try:
          cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          cl.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"ðﾟﾑﾉAuto Like by BOT PROTECT�\n\n™Auto Like By THE BROTHERs")
          satpam.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          satpam.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Aku Juga Ikutin Boss Aku Like Status Kamu Ka\n\n Like Back ya")
          ki.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1002)
          ki.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Minat Botchat,SiriV10,BotProtect,Selfbot hubungi me\n\n Like Back ya")
          kk.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1003)
          kk.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Aku Juga Ikutin Boss Aku Like Status Kamu Ka\n\n Like Back ya")
          kc.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1004)
          kc.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Aku Juga Ikutin Boss Aku Like Status Kamu Ka\n\n Like Back ya")
          ks.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1005)
          ks.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Aku Juga Ikutin Boss Aku Like Status Kamu Ka\n\n Like Back ya")
          ka.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1006)
          ka.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Aku Juga Ikutin Boss Aku Like Status Kamu Ka\n\n Like Back donk")
          kb.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1007)
          kb.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Aku Juga Ikutin Boss Aku Like Status Kamu Ka\n\n Like Back bosssss")
          ku.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1008)
          ku.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Aku Juga Ikutin Boss Aku Like Status Kamu Ka\n\n Like Back ok!!!")
          ke.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1009)
          ke.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"JANGAN LUPA KK order  songbook smule,follower & Bot protect nya!!ðﾟﾘﾍ\n\n Like Back")
          ko.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1001)
          ko.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Aku Juga Ikutin Boss Aku Like Status Kamu Ka\n\n Like Back boss")
          print "Like"
        except:
          pass
      else:
          print "Already Liked"
time.sleep(0.60)
#thread3 = threading.Thread(target=autolike)
#thread3.daemon = True
#thread3.start()
#--------------------
def likePost():
    for zx in range(0,20):
        hasil = cl.activity(limit=20)
        if hasil['result']['posts'][zx]['postInfo']['liked'] == False:
            if hasil['result']['posts'][zx]['userInfo']['mid'] in owner:
                try:
                    cl.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1005)
                    ki.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1004)
                    kk.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1005)
                    kc.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1005)
                    ks.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1005)
                    ka.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1005)
                    kb.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1005)
                    ku.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1005)
                    ke.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1003)
                    ko.like(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],likeType=1004)
                    cl.comment(hasil['result']['posts'][zx]['userInfo']['mid'],hasil['result']['posts'][zx]['postInfo']['postId'],"Auto like by THE PROTECTOR BROTHER HOOD")
                    print "Like"
                except:
                    pass
            else:
                print "Status Sudah di Like Boss"

def nameUpdate():
    while True:
        try:
        #while a2():
            #pass
            if wait["clock"] == True:
                now2 = datetime.now()
                nowT = datetime.strftime(now2,"(%H:%M)")
                profile = cl.getProfile()
                profile.displayName = wait["cName"]
                cl.updateProfile(profile)

                profile2 = ki.getProfile()
                profile2.displayName = wait["cName2"]
                ki.updateProfile(profile2)

                profile3 = kk.getProfile()
                profile3.displayName = wait["cName3"]
                kk.updateProfile(profile3)

                profile4 = kc.getProfile()
                profile4.displayName = wait["cName4"]
                kc.updateProfile(profile4)

                profile5 = ks.getProfile()
                profile5.displayName = wait["cName5"]
                ks.updateProfile(profile5a)

                profile6 = ka.getProfile()
                profile6.displayName = wait["cName6"]
                ka.updateProfile(profile6)

                profile7 = kb.getProfile()
                profile7.displayName = wait["cName7"]
                kb.updateProfile(profile7)

                profile8 = ko.getProfile()
                profile8.displayName = wait["cName8"]
                ko.updateProfile(profile8)
                
                profile9 = ke.getProfile()
                profile9.displayName = wait["cName9"]
                ke.updateProfile(profile9)
                
                profile10 = ku.getProfile()
                profile10.displayName = wait["cName10"]
                ku.updateProfile(profile10)
            time.sleep(600)
        except:
            pass
thread2 = threading.Thread(target=nameUpdate)
thread2.daemon = True
thread2.start()

while True:
    try:
        Ops = cl.fetchOps(cl.Poll.rev, 5)
    except EOFError:
        raise Exception("It might be wrong revision\n" + str(cl.Poll.rev))

    for Op in Ops:
        if (Op.type != OpType.END_OF_OPERATION):
            cl.Poll.rev = max(cl.Poll.rev, Op.revision)
            bot(Op)
