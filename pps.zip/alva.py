# -*- coding: utf-8 -*-
#PANGERANKOYN_Bot

import LINETCR
from LINETCR.lib.curve.ttypes import *
from datetime import datetime
from bs4 import BeautifulSoup
from threading import Thread
from googletrans import Translator
from gtts import gTTS
from time import sleep
import time,pytz,random,sys,json,codecs,threading,glob,urllib,urllib2,urllib3,re,ast,os,subprocess,requests,tempfile

token1 ="Eqp47qpGDcHY3bQFqmH1.Fsdo339JYvsyr3iL7MIhOq.sRDbl0cocU/Z3YZx4XSZeOAxV/HVlvdtq3tkvpLUHAQ=" #akun utms u7d20cedf7f63c95498477225ee6887a1
token2 ="EqwiNYRau1SJHnogUoZ3.085IAtfc7rjNNxR4nPloyW.E2OEJlWcd+/wEonRP4Hb/CZlt8w1N9YFFi0M1Hsjyk8="# mr haq   ud3ce62693142ed12679d7af83692ce63
token3 ="EqnGdliU47SaayFqufab.NxTNTLuviSEBJLh6ECbA/W.TO19ChYZbPzt/91nD9QOQq6szvOcu2ZiWaNnUI0i62c=" #u9d7b67b6551522c79b8e51fa79c05afb
token4 ="EqSs8iRQsNBhaNTKxghf.IEzQat2i0mZH3YmkiU1shW.1SjUcHSwXKTbVVLjeXNvuQTapdP5xpiV4nLJBuyLec4=" #u89e66a013d88d0cce1df230a22ed521f
token5 ="EqrtF0xTgIAPmpo65lec.X2nSvsEfkSCkBcbDwJyRJa./WGOR/iSYt8+bEtiCSl+zNG18/MORfqR3HImX3CaN6k=" #uc7636c5527852ac70a6c205d5a362b8c
token6 =""
cl = LINETCR.LINE()
#nadya.login(qr=True)
cl.login(token=token1)
cl.loginResult()
print "193 Login Success\n\n=====[Sukses Login]====="

ki = LINETCR.LINE()
#ki.login(qr=True)
ki.login(token=token2)
ki.loginResult()                                                                                                                             
print "Ki-Login Success\n"

kk = LINETCR.LINE()
#kk.login(qr=True)
kk.login(token=token3)
kk.loginResult()
print "Kk-Login Success\n"

kc = LINETCR.LINE()
#kc.login(qr=True)
kc.login(token=token4)
kc.loginResult()
print "Kc-Login Success\n"

ks = LINETCR.LINE()
#kr.login(qr=True)
ks.login(token=token5)
ks.loginResult()
print "Ks-Login Success\n"

ka = LINETCR.LINE()
#km.login(qr=True)
ka.login(token=token5)
ka.loginResult()
print "ALVA PRO 5\n\nLOGIN TANGGAL 13 MarEt 18"

reload(sys)
sys.setdefaultencoding('utf-8')

login = "13 mArcH 2018"
expired = "13 ApRiL 2018"

About ="""
══════════════════
            ⚜ About ⚜
══════════════════
Nama bot : """ + cl.getProfile().displayName +"""
Mid bot  : """ + cl.getProfile().mid +"""
Login tanggal : """+login+"""
Exp   tanggal : """+expired+"""
Type Token    : Chrome Os /9.0
token : """+token1+"""

══════════════════
══════════════════"""

Helpset ="""
══════════════════
              👿 HELP SET 👿
══════════════════
          🍒 Help mode On Off 🍒

🔘 「All protect」on / off (Protect grup)
🔘 「Auto add」on/off (add frend auto)
🔘 「Auto cancel」on/off(auto cancel invt)
🔘 「Join cancel」on/off (Left dari undangan)
🔘 「Invite」on/off (Auto undang mmber)
🔘 「Url」on / off (Buka tutup Qr)
🔘 「Qr」on/off (ngBlock Qr)
🔘 「Join」on / off (Auto join undangan)
🔘 「Respon」on / off (Respon tag auto Text)
🔘 「Respon1」on / off (Respon tag cover)
🔘 「Respon2」on / off (Respon blank)
🔘 「Respon3」on / off (Respon Send INBOX)
🔘 「Respon4」on / off (Respon inbok spam)
🔘 「Respon5」on / off (Respon image jones)
🔘 「Respon6」on / off (Respon Text tikel)
🔘 「Respon kick」on/off (ngtag = Kick)
🔘 「All respon」on/off (Semua respon Off)
🔘 「Sider」:on/off (Check cctv on sider)
🔘 「Invite pro」on/off」(Protect kickjoin)
🔘 「Auto kick」on/off」(Auto kick)
🔘 「Comment」on/off (Komentar auto like)
🔘 「K on/ Contact」 on/off」 (Info kontak)
🔘 「Always read」on/off (Selalu baca)
🔘 「Sambutan」on/off (welcome/sambutan)
══════════════════
      🔔 Mode Ganti Text message 🔔
══════════════════
🔘 「Change message:」(Ganti pesan addfrend)
🔘 「Change comment:」(Ganti text like TL)
🔘 「Change welcome:」(Ganti text sambutan)
🔘 「Change bye:」(Ganti text Bye msgs)
🔘 「Change sider1:」(Ganti text Sider cek)
🔘 「Change sider2:」(Ganti text Sider2 cek)
🔘 「Change respon:」(Ganti text respon)
🔘 「Change respon1:」 (Ganti txt respon1)
🔘 「Change respon2:」(Ganti text respon2)
🔘 「Change respon3:」(Ganti text respon3)
🔘 「Change respon4:」(Ganti text respon4)
🔘 「Change respon5:」(Ganti text respon5)
🔘 「Change respon6:」(Ganti text respon6)
══════════════════
      🔘Cek Recheck on "Set/Status🔘
══════════════════"""

HELPMESSAGE ="""
════════════════
           👿 """ + cl.getProfile().displayName + """ 👿
════════════════
─┅═❂❂❂❂❂❂❂❂❂❂❂❂‮─┅
════════════════
🍒 Help ☞ Key ☞(Bantuan)
🍒 Help set ☞ (bantuan setting)
🍒 Ginfo ☞(Cek info Grup)
🍒 Creator / Owner ☞(Cek editing)
🍒 Gcreator ☞(Cek pembuat Grup)
🍒 List grup ☞(cek jumlah room)
🍒 Join grup: ☞ (Join via Gid)
🍒 Leave grup: ☞ (Leave grup via Gid)
🍒 Pict grup: ☞(View Logo grup)
🍒 Status ☞ Set(Cek setting mode)
🍒 ToLak ☞ (Menolak semua undangan)
🍒 Invit gcreator ☞ (invit pmbuat rom)
🍒 NgGift ☞ Gift @ Gift1 2 3 4
═══════════════
🍒 Tagall , Tag all , Ngtag , Cium ,Cipok
🍒 Kiss ☞ Ngtag juga
🍒 Cek , Point☞( point read)
🍒 Cctv , Tes ☞ (Check sider)
🍒 Mid bot ☞ (Cek All mid bot)
🍒 My bot ☞ (Contact bot)
🍒 Respon ☞ (Respon nama bot)
🍒 Absen ☞ (Cek absensi bot)
🍒 Invite ☞(Invite via contact)
🍒 Auto like☞ (yng suka like2)
🍒 Clone grup ☞(Darurat copy grup)
🍒 Gn  ☞(Ganti nma grup)
🍒 Invite creator ☞(undang creator)
🍒 Bc:  ☞(Broadcast)
🍒 Setbackup , Back ☞(Back profile)
🍒 Mirip @ ☞ (copy profile)
🍒 Jadi @ ☞ (copy profile)
🍒 Cover☞ (Steal Image cover)
🍒 Dp ☞(Steal image Dp )
🍒 Musik / Musrik ☞(Cari musik)
🍒 Youtubevideo: ☞(Search video)
════════════════
🍒 Welcome to ☞(sambitan)
🍒 Playstore ☞(search app)
🍒 Mid @ ☞ (cek mid)
🍒 Namaku (Ganti namamu)
🍒 Image (search image)
🍒 Memlist ☞(Cek list member)
🍒 Kalender  ☞(Tanggalan)
🍒 Removechat ☞(Hapus semua chatmu)⚠
🍒 Google: ☞(search di mbah gugel)
🍒 Gruplist ☞(Cek Ur grup)
🍒 Fancyteks ☞ (Teks kedip2)
🍒 Clear ban ☞ (Hapus banned)
════════════════
═══════════════
🔘 #EROR ☞ crash LINE
🔘 Spam tikel @ ☞ (spm tikel Tag)
🔘 Spam kontak @ ☞(spm kontak me)
🔘 Spam gift @ ☞ (Spam ngGift Tag)
🔘 Gift spam ☞ (Spam,by Contact)
🔘 Spam eror @ ☞ (Spm kontak blank)
🔘 Spam Gc ☞ (spam invit room)
🔘 Spam: ☞ (Spam text 20)
🔘 Spam50 ☞ (Spam text 50)
🔘 Spam100 ☞ (spam text 100)
🔘 Spam150 ☞ (spam text 150)
🔘 Spam200☞ 300 ☞ 400 ☞ 500 ☞ 1000
🔘 Spam1 contact ☞(Spam by send contact)
🔘 Spam2 contact ☞ (spam Hank)
🔘 TEST @ ☞(Spam text via Tag)
🔘 Cancel ☞ (Membatalkan invite)
🔘 Speed , Sp ☞(Cek speed bot)
🔘 Tendang @☞ (Kick member By tag)
🔘 Bom @ Kikuk @ ☞(Kick by Tag)
🔘 Fuck @ ☞ (kick,via tag)
🔘 Hajar ☞ (kick banned)
🔘 Bom all ☞(kick smua member)
🔘 KELUAR DARI ROOM ☞(kluar semua  dr grup)
🔘 Masuk kuy ☞ (Invite All bot)
🔘 Pulang kuy ☞ (Bot get Out Room)
🔘 Ok ikut ☞ (Admin self Left)
🔘 Aim left , Aim out ☞(keluar grup)
🔘 Runtime ☞ (Cek run bot)
🔘 Reset ☞(Restart ulang)
🔘 About ☞ (Cek versi bot)
══════════════════
   👤 line.me/ti/p/~anto_sahaja2 👤
══════════════════
    👿 START ON """+login+""" MARCH 18 👿
══════════════════"""

skin1 ="""
════════════════
             👿 """ + cl.getProfile().displayName + """ 👿
════════════════
─┅═❂❂❂❂❂❂❂❂❂❂❂❂‮─┅
════════════════
🍒 нelp ☞ ĸey ☞(вanтυan)
🍒 нelp ѕeт ☞ (вanтυan ѕeттιng)
🍒 gιnғo ☞(ceĸ ιnғo grυp)
🍒 creaтor / owner ☞(ceĸ edιтιng)
🍒 gcreaтor ☞(ceĸ peмвυaт grυp)
🍒 lιѕт grυp ☞(ceĸ jυмlaн rooм)
🍒 joιn grυp: ☞ (joιn vιa gιd)
🍒 leave grυp: ☞ (leave grυp vιa gιd)
🍒 pιcт grυp: ☞(vιew logo grυp)
🍒 ѕтaтυѕ ☞ ѕeт(ceĸ ѕeттιng мode)
🍒 Tolak ☞ (tolak,smua umdangan)
════════════════
🍒 тagall , тag all , ngтag , cιυм ,cιpoĸ
🍒 ceĸ , poιnт☞( poιnт read)
🍒 ccтv , тeѕ ☞ (cнecĸ ѕιder)
🍒 мιd вoт ☞ (ceĸ all мιd вoт)
🍒 мy вoт ☞ (conтacт вoт)
🍒 reѕpon ☞ (reѕpon naмa вoт)
🍒 aвѕen ☞ (ceĸ aвѕenѕι вoт)
🍒 ιnvιтe ☞(ιnvιтe vιa conтacт)
🍒 aυтo lιĸe☞ (yng ѕυĸa lιĸe2)
🍒 clone grυp ☞(darυraт copy grυp)
🍒 gn  ☞(ganтι nмa grυp)
🍒 ιnvιтe creaтor ☞(υndang creaтor)
🍒 вc:  ☞(вroadcaѕт)
🍒 ѕeтвacĸυp , вacĸ ☞(вacĸ proғιle)
🍒 мιrιp @ ☞ (copy proғιle)
🍒 cover☞ (ѕтeal ιмage cover)
🍒 dp ☞(ѕтeal ιмage dp )
🍒 мυѕιĸ / мυѕrιĸ ☞(carι мυѕιĸ)
🍒 yoυтυвevιdeo: ☞(ѕearcн vιdeo)
════════════════
🍒 welcoмe тo ☞(ѕaмвιтan)
🍒 playѕтore ☞(ѕearcн app)
🍒 мιd @ ☞ (ceĸ мιd)
🍒 naмaĸυ (ganтι naмaмυ)
🍒 ιмage (ѕearcн ιмage)
🍒 мeмlιѕт ☞(ceĸ lιѕт мeмвer)
🍒 ĸalender  ☞(тanggalan)
🍒 reмovecнaт ☞(нapυѕ ѕeмυa cнaтмυ)⚠
🍒 google: ☞(ѕearcн dι мвaн gυgel)
🍒 grυplιѕт ☞(ceĸ υr grυp)
🍒 ғancyтeĸѕ ☞ (тeĸѕ ĸedιт2)
════════════════
════════════════
🔘 ѕpaм tikel @ ☞(spam t by,tag)
🔘 ѕpaм kontak @ ☞(Spam Me)
🔘 ѕpaм gift @ ☞ (By tag)
🔘 Gift ѕpaм ☞ (By kontak)
🔘 ѕpaм gc ☞ (ѕpaм ιnvιт rooм)
🔘 ѕpaм: ☞ (ѕpaм тeхт 20)
🔘 ѕpaм50 ☞ (ѕpaм тeхт 50)
🔘 ѕpaм100 ☞ (ѕpaм тeхт 100)
🔘 ѕpaм200 300 400 500 1000 ☞(ѕpaм тeхт)
🔘 ѕpaм1 conтacт ☞(ѕpaм вy ѕend conтacт)
🔘 ѕpaм2 conтacт ☞ (ѕpaм нanĸ)
🔘 тeѕт @ ☞(ѕpaм тeхт vιa тag)
🔘 cancel ☞ (мeмвaтalĸan ιnvιтe)
🔘 ѕpeed , ѕp ☞(ceĸ ѕpeed вoт)
🔘 тendang @☞ (ĸιcĸ мeмвer вy тag)
🔘 вoм @ ĸιĸυĸ @ ☞(ĸιcĸ вy тag)
🔘 нajar ☞ (ĸιcĸ ѕeмυa мeмвer)
🔘 тendang all ☞(ĸιcĸ ѕмυa мeмвer)
🔘 ĸelυar grυp ☞(ĸlυar ѕeмυa  dr grυp)
🔘 мaѕυĸ ĸυy ☞ (ιnvιтe all вoт)
🔘 pυlang ĸυy ☞ (вoт geт oυт rooм)
🔘 oĸ ιĸυт ☞ (adмιn ѕelғ leғт)
🔘 aιм leғт , aιм oυт ☞(ĸelυar grυp)
🔘 reѕeт ☞(reѕтarт υlang)
🔘 aвoυт ☞ (ceĸ verѕι вoт)
══════════════════
   👤 line.me/ti/p/~anto_sahaja2 👤
══════════════════
     👿 ѕтarт on """+login+""" 👿
══════════════════"""

skin2 ="""
═════════════════
            👿 """ + cl.getProfile().displayName + """ 👿
═════════════════
👿⚜⚜⚜⚜⚜⚜⚜⚜⚜⚜⚜⚜⚜👿
═════════════════
♻ Help ☞ Key ☞(Bantuan)
♻ Help set ☞ (Bantuan Setting)
♻ Ginfo ☞(Cek info Grup)
♻ My token ☞ (Type Token mu)⚠
♻ Creator / Owner ☞(Cek editing)
♻ Gcreator ☞(Cek pembuat Grup)
♻ List grup ☞(cek jumlah room)
♻ Join grup: ☞ (Join via Gid)
♻ Leave grup: ☞ (Leave grup via Gid)
♻ Pict grup: ☞(View Logo grup)
♻ Status ☞ Set(Cek setting mode)
♻ 「Gift/Gift1/2/3/4/5/6/7/8」
♻ Tagall , Tag all , Ngtag , Cium ,Cipok
♻ Cek , Point☞( point read)
♻ Cctv , Tes ☞ (Check sider)
♻ Mid bot ☞ (Cek All mid bot)
♻ My bot ☞ (Contact bot)
♻ Respon ☞ (Respon nama bot)
♻ Absen ☞ (Cek absensi bot)
♻ Invite ☞(Invite via contact)
♻ Auto like☞ (yng suka like2)
♻ Clone grup ☞(Darurat copy grup)
♻ Gn  ☞(Ganti nma grup)
♻ Invite creator ☞(undang creator)
♻ Bc:  ☞(Broadcast)
♻ Setbackup , Back ☞(Back profile)
♻ Mirip @ ☞ (copy profile)
♻ Cover☞ (Steal Image cover)
♻ Dp ☞(Steal image Dp )
♻ Musik / Musrik ☞(Cari musik)
♻ Youtubevideo: ☞(Search video)
♻ Welcome to ☞(sambitan)
♻ Playstore ☞(search app)
♻ Mid @ ☞ (cek mid)
♻ Namaku (Ganti namamu)
♻ Image (search image)
♻ Memlist ☞(Cek list member)
♻ Kalender  ☞(Tanggalan)
♻ Removechat ☞(Hapus semua chatmu)⚠
♻ Google: ☞(search di mbah gugel)
♻ Gruplist ☞(Cek Ur grup)
♻ Fancyteks ☞ (Teks kedit2)
════════════════
☞DONT KLIK IF  U NOT UNDERSTAND☜
════════════════
♻ Spam Gc ☞ (spam invit room)
♻ Spam: ☞ (Spam text 20)
♻ Spam300 ☞ (Spam text 300)
♻ Spam500 ☞ (spam text 500)
♻ Spam1000 ☞ (spam text 1000)
♻ Spam1 contact ☞(Spam by send contact)
♻ Spam2 contact ☞ (spam Hank)
♻ TEST @ ☞(Spam text via Tag)
♻ Cancel ☞ (Membatalkan invite)
♻ Speed , Sp ☞(Cek speed bot)
♻ Tendang @☞ (Kick member By tag)
♻ Bom @ Kikuk @ ☞(Kick by Tag)
♻ Hajar ☞ (kick semua member)
♻ Tendang all ☞(kick smua member)
♻ KELUAR GRUP ☞(kluar semua  dr grup)
♻ Masuk kuy ☞ (Invite All bot)
♻ Pulang kuy ☞ (Bot get Out Room)
♻ Ok ikut ☞ (Admin self Left)
♻ Aim left , Aim out ☞(keluar grup)
♻ Reset ☞(Restart ulang)
♻ About ☞ (Cek versi bot)
══════════════════
   👤 line.me/ti/p/~anto_sahaja2 👤
══════════════════
      👿 START ON  """+login+""" 👿
══════════════════"""

skin3 ="""
════════════════
             👿 """ + cl.getProfile().displayName + """ 👿
════════════════
─┅═❂❂❂❂❂❂❂❂❂❂❂❂‮─┅
════════════════
🔘 нelp ☞ ĸey ☞(вanтυan)
🔘 нelp ѕeт ☞ (вanтυan ѕeттιng)
🔘 gιnғo ☞(ceĸ ιnғo grυp)
🔘 мy тoĸen ☞ (тype тoĸen мυ)⚠
🔘 creaтor / owner ☞(ceĸ edιтιng)
🔘 gcreaтor ☞(ceĸ peмвυaт grυp)
🔘 lιѕт grυp ☞(ceĸ jυмlaн rooм)
🔘 joιn grυp: ☞ (joιn vιa gιd)
🔘 leave grυp: ☞ (leave grυp vιa gιd)
🔘 pιcт grυp: ☞(vιew logo grυp)
🔘 ѕтaтυѕ ☞ ѕeт(ceĸ ѕeттιng мode)
════════════════
🔘 тagall , тag all , ngтag , cιυм ,cιpoĸ
🔘 ceĸ , poιnт☞( poιnт read)
🔘 ccтv , тeѕ ☞ (cнecĸ ѕιder)
🔘 мιd вoт ☞ (ceĸ all мιd вoт)
🔘 мy вoт ☞ (conтacт вoт)
🔘 reѕpon ☞ (reѕpon naмa вoт)
🔘 aвѕen ☞ (ceĸ aвѕenѕι вoт)
🔘 ιnvιтe ☞(ιnvιтe vιa conтacт)
🔘 aυтo lιĸe☞ (yng ѕυĸa lιĸe2)
🔘 clone grυp ☞(darυraт copy grυp)
🔘 gn  ☞(ganтι nмa grυp)
🔘 ιnvιтe creaтor ☞(υndang creaтor)
🔘 вc:  ☞(вroadcaѕт)
🔘 ѕeтвacĸυp , вacĸ ☞(вacĸ proғιle)
🔘 мιrιp @ ☞ (copy proғιle)
🔘 cover☞ (ѕтeal ιмage cover)
🔘 dp ☞(ѕтeal ιмage dp )
🔘 мυѕιĸ / мυѕrιĸ ☞(carι мυѕιĸ)
🔘 yoυтυвevιdeo: ☞(ѕearcн vιdeo)
════════════════
🔘 welcoмe тo ☞(ѕaмвιтan)
🔘 playѕтore ☞(ѕearcн app)
🔘 мιd @ ☞ (ceĸ мιd)
🔘 naмaĸυ (ganтι naмaмυ)
🔘 ιмage (ѕearcн ιмage)
🔘 мeмlιѕт ☞(ceĸ lιѕт мeмвer)
🔘 ĸalender  ☞(тanggalan)
🔘 reмovecнaт ☞(нapυѕ ѕeмυa caтмυ)⚠
🔘 google: ☞(ѕearcн dι мвaн gυgel)
🔘 grυplιѕт ☞(ceĸ υr grυp)
🔘 ғancyтeĸѕ ☞ (тeĸѕ ĸedιт2)
════════════════
════════════════
🔘 ѕpaм gc ☞ (ѕpaм ιnvιт rooм)
🔘 ѕpaм: ☞ (ѕpaм тeхт 20)
🔘 ѕpaмх ☞ (ѕpaм тeхт 300)
🔘 ѕpaмх2 ☞ (ѕpaм тeхт 500)
🔘 ѕpaмх3 ☞ (ѕpaм тeхт 1000)
🔘 ѕpaм1 conтacт ☞(ѕpaм вy ѕend conтacт)
🔘 ѕpaм2 conтacт ☞ (ѕpaм нanĸ)
🔘тeѕт @ ☞(ѕpaм тeхт vιa тag)
🔘 cancel ☞ (мeмвaтalĸan ιnvιтe)
🔘 ѕpeed , ѕp ☞(ceĸ ѕpeed вoт)
🔘 тendang @☞ (ĸιcĸ мeмвer вy тag)
🔘 вoм @ ĸιĸυĸ @ ☞(ĸιcĸ вy тag)
🔘 нajar ☞ (ĸιcĸ ѕeмυa мeмвer)
🔘 тendang all ☞(ĸιcĸ ѕмυa мeмвer)
🔘 ĸelυar grυp ☞(ĸlυar ѕeмυa  dr grυp)
🔘 мaѕυĸ ĸυy ☞ (ιnvιтe all вoт)
🔘 pυlang ĸυy ☞ (вoт geт oυт rooм)
🔘 oĸ ιĸυт ☞ (adмιn ѕelғ leғт)
🔘 aιм leғт , aιм oυт ☞(ĸelυar grυp)
🔘 reѕeт ☞(reѕтarт υlang)
🔘 aвoυт ☞ (ceĸ verѕι вoт)
══════════════════
   👤 line.me/ti/p/~anto_sahaja2 👤
══════════════════
        👿 ѕтarт on """+login+""" 👿
══════════════════"""

skin4 ="""
════════════════
           👿 """ + cl.getProfile().displayName + """ 👿
════════════════
─┅═❂❂❂❂❂❂❂❂❂❂❂❂‮─┅
════════════════
🔘 Help ☞ Key ☞(Bantuan)
🔘 Help set ☞ (bantuan setting)
🔘 Ginfo ☞(Cek info Grup)
🔘 My token ☞ (Type Token mu)⚠
🔘 Creator / Owner ☞(Cek editing)
🔘 Gcreator ☞(Cek pembuat Grup)
🔘 List grup ☞(cek jumlah room)
🔘 Join grup: ☞ (Join via Gid)
🔘 Leave grup: ☞ (Leave grup via Gid)
🔘 Pict grup: ☞(View Logo grup)
🔘 Status ☞ Set(Cek setting mode)
═══════════════
🔘 Tagall , Tag all , Ngtag , Cium ,Cipok
🔘 Cek , Point☞( point read)
🔘 Cctv , Tes ☞ (Check sider)
🔘 Mid bot ☞ (Cek All mid bot)
🔘 My bot ☞ (Contact bot)
🔘 Respon ☞ (Respon nama bot)
🔘 Absen ☞ (Cek absensi bot)
🔘 Invite ☞(Invite via contact)
🔘 Auto like☞ (yng suka like2)
🔘 Gn  ☞(Ganti nma grup)
🔘 Invite creator ☞(undang creator)
🔘 Bc:  ☞(Broadcast)
🔘 Setbackup , Back ☞(Back profile)
🔘 Mirip @ ☞ (copy profile)
🔘 Cover☞ (Steal Image cover)
🔘 Dp ☞(Steal image Dp )
🔘 Musik / Musrik ☞(Cari musik)
🔘 Youtubevideo: ☞(Search video)
════════════════
🔘 Welcome to ☞(sambitan)
🔘 Playstore ☞(search app)
🔘 Mid @ ☞ (cek mid)
🔘 Namaku (Ganti namamu)
🔘 Image (search image)
🔘 Memlist ☞(Cek list member)
🔘 Kalender  ☞(Tanggalan)
🔘 Removechat ☞(Hapus semua chatmu)⚠
🔘 Google: ☞(search di mbah gugel)
🔘 Gruplist ☞(Cek Ur grup)
🔘 Fancyteks ☞ (Teks kedit2)
═══════════════
════════════════
🔘 Spam Gc ☞ (spam invit room)
🔘 Spam: ☞ (Spam text 20)
🔘 Spam300 ☞ (Spam text 300)
🔘 Spam500 ☞ (spam text 500)
🔘 Spam1000 ☞ (spam text 1000)
🔘 Spam1 contact ☞(Spam by send contact)
🔘 Spam2 contact ☞ (spam Hank)
🔘 TEST @ ☞(Spam text via Tag)
🔘 Cancel ☞ (Membatalkan invite)
🔘 Speed , Sp ☞(Cek speed bot)
🔘 Tendang @☞ (Kick member By tag)
🔘 Bom @ Kikuk @ ☞(Kick by Tag)
🔘 Hajar ☞ (kick semua member)
🔘 Tendang all ☞(kick smua member)
🔘 KELUAR GRUP ☞(kluar semua  dr grup)
🔘 Masuk kuy ☞ (Invite All bot)
🔘 Pulang kuy ☞ (Bot get Out Room)
🔘 Ok ikut ☞ (Admin self Left)
🔘 Aim left , Aim out ☞(keluar grup)
🔘 Reset ☞(Restart ulang)
🔘 About ☞ (Cek versi bot)
══════════════════
   👤 line.me/ti/p/~anto_sahaja2 👤
══════════════════
      👿 START ON """+login+""" 👿
══════════════════"""

dangerMessage = ["Kill","Kick @","cleanse","group cleansed.","mulai",".winebot",".kickall","mayhem","kick on","makasih :d","!kickall","nuke","Kick:on"]
KAC=[cl,ki,kk,kc,ks,ka]
mid = cl.getProfile().mid
Amid = ki.getProfile().mid
Bmid = kk.getProfile().mid
Cmid = kc.getProfile().mid
Dmid = ks.getProfile().mid
Emid = ka.getProfile().mid
Bots=[mid,Amid,Bmid,Cmid,Dmid,Emid]
Creator=[mid]
admin=[mid,Amid]
Anto="ufb484c768b5da9de91722b2cf5a19cd3"

contact = cl.getProfile()
backup1 = cl.getProfile()
backup1.displayName = contact.displayName
backup1.statusMessage = contact.statusMessage                        
backup1.pictureStatus = contact.pictureStatus

name1 = cl.getProfile().displayName
name2 = ki.getProfile().displayName
name3 = kk.getProfile().displayName
name4 = kc.getProfile().displayName
name5 = ks.getProfile().displayName
name6 = ka.getProfile().displayName

tz = pytz.timezone("Asia/Jakarta")
timeZone = datetime.now(tz=tz)
jam = timeZone.today().strftime('%H:%M:%S')

wait = {
    "Bot":True,
    "LeaveRoom":True,
    "autoAdd":True,
    "AutoJoin":False,
    "AutoJoinCancel":False,
    "memberscancel":30,
    "Members":1,
    "AutoCancel":False,
    "AutoKick":False,
    'pap':{},
    'invite':{},
    'steal':{},
    'gift':{},
    'likeOn':{},
    "spam1":{},
    "spam2":{},
    "jones":False,
    "jones2":True,
    "koplok":False,
    'detectMention':False,
    'kickMention':False,
    "respone3":False,
    "sepamRes":False,
    "koynRes":False,
    "sticker":False,
    'timeline':True,
    "Timeline":True,
    "comment":"Bot Auto Like ©By : Anto sahaja\nContact Me : 👉 line.me/ti/p/~anto_sahaja2",    
    "commentOn":True,
    "commentBlack":{},
    "message":"Thx For Add Me (^_^)\nSedia:\n         Siri V10 up to v11\n         Songbook smule\n         VIP smule android\n         Follower smule\n         Bot self(Bot akun sendiri)\n         Sewa Bot Protect 20akun/5\n\nJANGAN LUPA ORDER YE BEB!!!\nContact me di line.me/ti/p/~anto_sahaja2 or line.me/ti/p/~anto_sahaja1",
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Qr":False,
    "Contact":False,
    "Sambutan":True,
    "ngundang":False,
    "Ghost":False,
    "inviteprotect":False,
    "alwaysRead":False,
    "tag":False,
    "Sider":{},
    "Simi":{},    
    "lang":"JP",
    "BlGroup":{}
}

settings = {
    "simiSimi":{}
    }
    
cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}    

wait2 = {
    "readPoint":{},
    "readMember":{},
    "setTime":{},
    "ROM":{}
    }

mimic = {
    "copy":False,
    "copy2":False,
    "status":False,
    "target":{}
    }

pesan = {
    "respon":"\n aĸoн lagι ѕιвυĸ pc aja ya !!! 😘",
    "respon1":"\nтag вalιĸ aн... ѕυe ngтag мυlυ!! 😃😃",
    "respon2":"\nнσяεεε.... кεηα sραм ℓσн!!! 😂😂",
    "respon3":"нαι..α∂α ρεяℓυ αρα тα∂ι мαηggιℓ2 ∂ι яσσм\nηgαנαкιη ηιкυηg үα!!!",
    "responkick":"\n∂ιвιℓαηg!η gσsαн ηgтαg\nαкυ кιcк ηιн..(>﹏<)",
    "welcom":"\nsεмσgα вεтαн & נαηgαη ℓυρα вαнαgια.^_^",
    "bye":"papay...\nѕaмpaι jυмpa lagι !!😃",
    "sidr1":"\nHai kk....sini Masuk\nRame in Rom",
    "sidr2":"\nEh ada kaK anu Baru dateng ya..",
    "sidr3":"\nнaι ĸĸ....ѕιnι dong cнaт\nвιar raмe...😘😘😘",
    "spamr":"sραм ∂υ∂υℓ",
    "respon4":"\nнaнa...ĸena ѕpaм deн тag aĸoн  😂😂😂😂",
    "respon5":"\njoneѕ nιн....нoввy nya ngтag...\n nι ∂ια penaмpaĸannya 😂😂😂😂",
    "respon6":"\nĸalo мo nιĸυng goѕaн ngтag\n langѕυng pc aja",
    }
stikers = {
    "stikres00":'149',
    "stikres01":'2',
    "stikres02":'100',
    }
    
setTime = {}
setTime = wait2['setTime']
mulai = time.time() 
start = time.time()

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request    
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"


def _images_get_next_item(s):
    start_line = s.find('rg_di')
    if start_line == -1:    
        end_quote = 0
        link = "no_links"
        return link, end_quote
    else:
        start_line = s.find('"class="rg_meta"')
        start_content = s.find('"ou"',start_line+90)
        end_content = s.find(',"ow"',start_content-90)
        content_raw = str(s[start_content+6:end_content-1])
        return content_raw, end_content


def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items

def mention(to, nama):
    aa = ""
    bb = ""
    strt = int(14)
    akh = int(14)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "\xe2\x95\xa0 @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n"+bb+"\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    print "[Command] Tag All"
    try:
       cl.sendMessage(msg)
    except Exception as error:
        print error

def summon(to, nama):
    aa = ""
    bb = ""
    strt = int(14)
    akh = int(14)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "\xe2\x95\xa0 @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n"+bb+"\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    print "[Command] Tag All"
    try:
       cl.sendMessage(msg)
    except Exception as error:
       print error

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    return '%02d Jam %02d Menit %02d Detik' % (hours, mins, secs)

#def waktu():
    #import time
    #a=time.localtime()
    #hr=a.tm_hour
    #mn=a.tm_min
    #sc=a.tm_sec
    #return ('{}:{}:{}'.format(hr,mn,sc))

    
def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾","サテラ:","サテラ:","サテラ：","サテラ："]
    for texX in tex:
        for command in commands:
            if string ==command:
                return True
    return False    

def upload_tempimage(client):
     '''
         Upload a picture of a kitten. We don't ship one, so get creative!
     '''
     config = {
         'album': album,
         'name':  'bot auto upload',
         'title': 'bot auto upload',
         'description': 'bot auto upload'
     }

     print("Uploading image... ")
     image = client.upload_from_path(image_path, config=config, anon=False)
     print("Done")
     print()

     return image
     
def sendAudio(self, to_, path):
       M = Message()
       M.text = None
       M.to = to_
       M.contentMetadata = None
       M.contentPreview = None
       M.contentType = 3
       M_id = self._client.sendMessage(0,M).id
       files = {
             'file': open(path,  'rb'),
       }
    
def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1
    
def sendImage(self, to_, path):
      M = Message(to=to_, text=None, contentType = 1)
      M.contentMetadata = None
      M.contentPreview = None
      M2 = self._client.sendMessage(0,M)
      M_id = M2.id
      files = {
         'file': open(path, 'rb'),
      }
      params = {
         'name': 'media',
         'oid': M_id,
         'size': len(open(path, 'rb').read()),
         'type': 'image',
         'ver': '1.0',
      }
      data = {
         'params': json.dumps(params)
      }
      r = self.post_content('https://obs-sg.line-apps.com/talk/m/upload.nhn', data=data, files=files)
      if r.status_code != 201:
         raise Exception('Upload image failure.')
      return True


def sendImageWithURL(self, to_, url):
      path = '%s/pythonLine-%i.data' % (tempfile.gettempdir(), randint(0, 9))
      r = requests.get(url, stream=True)
      if r.status_code == 200:
         with open(path, 'w') as f:
            shutil.copyfileobj(r.raw, f)
      else:
         raise Exception('Download image failure.')
      try:
         self.sendImage(to_, path)
      except:
         try:
            self.sendImage(to_, path)
         except Exception as e:
            raise e

def sendAudio(self, to_, path):
        M = Message()
        M.text = None
        M.to = to_
        M.contentMetadata = None
        M.contentPreview = None
        M.contentType = 3
        M_id = self._client.sendMessage(0,M).id
        files = {
            'file': open(path, 'rb'),
        }
        params = {
            'name': 'media',
            'oid': M_id,
            'size': len(open(path, 'rb').read()),
            'type': 'audio',
            'ver': '1.0',
        }
        data = {
            'params': json.dumps(params)
        }
        r = self.post_content('https://os.line.naver.jp/talk/m/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Upload audio failure.')
        return True

def sendAudioWithURL(self, to_, url):
        path = self.downloadFileWithURL(url)
        try:
            self.sendAudio(to_, path)
        except Exception as e:
            raise Exception(e)

def sendAudioWithUrl(self, to_, url):
        path = '%s/pythonLine-%1.data' % (tempfile.gettempdir(), randint(0, 9))
        r = requests.get(url, stream=True, verify=False)
        if r.status_code == 200:
           with open(path, 'w') as f:
              shutil.copyfileobj(r.raw, f)
        else:
           raise Exception('Download audio failure.')
        try:
            self.sendAudio(to_, path)
        except Exception as e:
            raise e
            
def downloadFileWithURL(self, fileUrl):
        saveAs = '%s/pythonLine-%i.data' % (tempfile.gettempdir(), randint(0, 9))
        r = self.get_content(fileUrl)
        if r.status_code == 200:
            with open(saveAs, 'wb') as f:
                shutil.copyfileobj(r.raw, f)
            return saveAs
        else:
            raise Exception('Download file failure.')

def sendSticker(self,
                    stickerId = "13",
                    stickerPackageId = "1",
                    stickerVersion = "100",
                    stickerText="[null]"):
        """Send a sticker

        :param stickerId: id of sticker
        :param stickerPackageId: package id of sticker
        :param stickerVersion: version of sticker
        :param stickerText: text of sticker (default='[null]')
        """
        try:
            message = Message(to=self.id, text="")
            message.contentType = ContentType.STICKER

            message.contentMetadata = {
                'STKID': stickerId,
                'STKPKGID': stickerPackageId,
                'STKVER': stickerVersion,
                'STKTXT': stickerText,
            }

            self._client.sendMessage(message)

            return True
        except Exception as e:
            raise e

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)


def bot(op):
    try:

        if op.type == 0:
            return

        if op.type == 5:
           if wait["autoAdd"] == True:
              cl.findAndAddContactsByMid(op.param1)
              if(wait["message"]in[""," ","\n",None]):
                pass
              else:
                cl.sendText(op.param1,str(wait["message"]))


        if op.type == 55:
	    try:
	      group_id = op.param1
	      user_id=op.param2
	      subprocess.Popen('echo "'+ user_id+'|'+str(op.createdTime)+'" >> dataSeen/%s.txt' % group_id, shell=True, stdout=subprocess.PIPE, )
	    except Exception as e:
	      print e
	      
        if op.type == 55:
                try:
                    if cctv['cyduk'][op.param1]==True:
                        if op.param1 in cctv['point']:
                            Name = cl.getContact(op.param2).displayName
                            if Name in cctv['sidermem'][op.param1]:
                                pass
                            else:
                                cctv['sidermem'][op.param1] += "\n• " + Name
                                if " " in Name:
                                    nick = Name.split(' ')
                                    if len(nick) == 2:
                                        cl.sendText(op.param1, Name + " \n" + "" + str(pesan["sidr1"]))
                                        time.sleep(0.2)
                                        summon(op.param1,[op.param2])
                                    else:
                                        cl.sendText(op.param1, Name + "\n" + "" + str(pesan["sidr2"]))
                                        time.sleep(0.2)
                                        summon(op.param1,[op.param2])
                                else:
                                    cl.sendText(op.param1, Name + "\n" + "" + str(pesan["sidr3"]))
                                    time.sleep(0.2)
                                    summon(op.param1,[op.param2])
                        else:
                            pass
                    else:
                        pass
                except:
                    pass

        else:
            pass    	      
	      

        if op.type == 22:
            cl.leaveRoom(op.param1)

        if op.type == 21:
            cl.leaveRoom(op.param1)


        if op.type == 13:
	    print op.param3
            if op.param3 in mid:
		if op.param2 in admin:
		    cl.acceptGroupInvitation(op.param1)
	    #INVITATION BOT ADMIN
            if op.param3 in Amid:
                if op.param3 in Creator:                                                                                                                   
                    ki.acceptGroupInvitation(op.param1)
            if op.param3 in Bmid:
                if op.param2 in Creator:
                    kk.acceptGroupInvitation(op.param1)
            if op.param3 in Cmid:
                if op.param2 in Creator:
                    kc.acceptGroupInvitation(op.param1)
            if op.param3 in Dmid:
                if op.param2 in Creator:
                    ks.acceptGroupInvitation(op.param1)
            if op.param3 in Emid:
                if op.param2 in Creator:
                    ka.acceptGroupInvitation(op.param1)
            #PARAM KICK BOT ADMIN SELF (CL)
            if op.param3 in mid:
                if op.param2 in Amid:
                    cl.acceptGroupInvitation(op.param1)
            if op.param3 in mid:
                if op.param2 in Bmid:
                    cl.acceptGroupInvitation(op.param1)
            if op.param3 in mid:
                if op.param2 in Cmid:
                    cl.acceptGroupInvitation(op.param1)
            if op.param3 in mid:
                if op.param2 in Dmid:
                    cl.acceptGroupInvitation(op.param1)
            if op.param3 in mid:
                if op.param2 in Emid:
                    cl.acceptGroupInvitation(op.param1)
            #PARAM KICK BOT 1  (KI)
            if op.param3 in Amid:
                if op.param2 in mid:
                    ki.acceptGroupInvitation(op.param1)
            if op.param3 in Amid:
                if op.param2 in Bmid:
                    ki.acceptGroupInvitation(op.param1)
            if op.param3 in Amid:
                if op.param2 in Cmid:
                    ki.acceptGroupInvitation(op.param1)
            if op.param3 in Amid:
                if op.param2 in Dmid:
                    ki.acceptGroupInvitation(op.param1)
            if op.param3 in Amid:
                if op.param2 in Emid:
                    ki.acceptGroupInvitation(op.param1)
            #PARAM KICK BOT  2 (KK)
            if op.param3 in Bmid:
                if op.param2 in mid:
                    kk.acceptGroupInvitation(op.param1)
            if op.param3 in Bmid:
                if op.param2 in Amid:                                                                                                                      
                    kk.acceptGroupInvitation(op.param1)
            if op.param3 in Bmid:
                if op.param2 in Cmid:
                    kk.acceptGroupInvitation(op.param1)
            if op.param3 in Bmid:
                if op.param2 in Dmid:
                    kk.acceptGroupInvitation(op.param1)
            if op.param3 in Bmid:
                if op.param2 in Emid:
                    kk.acceptGroupInvitation(op.param1)
            #PARAM KICK BOT  3 (KC)
            if op.param3 in Cmid:
                if op.param2 in mid:
                    kc.acceptGroupInvitation(op.param1)
            if op.param3 in Cmid:
                if op.param2 in Amid:
                    kc.acceptGroupInvitation(op.param1)
            if op.param3 in Cmid:
                if op.param2 in Bmid:
                    kc.acceptGroupInvitation(op.param1)
            if op.param3 in Cmid:
                if op.param2 in Dmid:
                    kc.acceptGroupInvitation(op.param1)
            if op.param3 in Cmid:
                if op.param2 in Emid:
                    kc.acceptGroupInvitation(op.param1)
            #PARAM KICK BOT 4 (KS)
            if op.param3 in Dmid:
                if op.param2 in mid:
                    ks.acceptGroupInvitation(op.param1)
            if op.param3 in Dmid:
                if op.param2 in Amid:
                    ks.acceptGroupInvitation(op.param1)
            if op.param3 in Dmid:
                if op.param2 in Bmid:
                    ks.acceptGroupInvitation(op.param1)
            if op.param3 in Dmid:
                if op.param2 in Cmid:
                    ks.acceptGroupInvitation(op.param1)
            if op.param3 in Dmid:
                if op.param2 in Emid:
                    ks.acceptGroupInvitation(op.param1)
            #PARAM KICK BOT 5  (KA)
            if op.param3 in Emid:
                if op.param2 in mid:
                    ka.acceptGroupInvitation(op.param1)
            if op.param3 in Emid:
                if op.param2 in Amid:
                    ka.acceptGroupInvitation(op.param1)
            if op.param3 in Emid:
                if op.param2 in Bmid:
                    ka.acceptGroupInvitation(op.param1)
            if op.param3 in Emid:
                if op.param2 in Cmid:
                    ka.acceptGroupInvitation(op.param1)
            if op.param3 in Emid:
                if op.param2 in Dmid:                                                                                                                      
                    ka.acceptGroupInvitation(op.param1)

		    
	    if mid in op.param3:	        
                if wait["AutoJoinCancel"] == True:
		    G = cl.getGroup(op.param1)
                    if len(G.members) <= wait["memberscancel"]:
                        cl.acceptGroupInvitation(op.param1)
                        cl.sendText(op.param1,"woy gaυѕaн мaen cυlιĸ...\nĸalo мaυ ιnvιт вιlang вιlang dυlυ donĸ..😎 @" + cl.getContact(op.param2).displayName + " \nKalau mau undang bilang bilang dulu ah...( ´▽` )ﾉ")
                        c = Message(to=op.param1, from_=None, text=None, contentType=13)
                        c.contentMetadata = {'mid': "NADYA,'"}
                        cl.sendMessage(c)
                        cl.leaveGroup(op.param1)                        
		    else:
                        cl.acceptGroupInvitation(op.param1)
                        cl.leaveGroup(op.param1)
			#cl.sendText(op.param1,"☆Ketik ☞Help☜ Untuk Bantuan☆\n☆Harap Gunakan Dengan Bijak ^_^ ☆")
                        		    
 
	    if mid in op.param3:
                if wait["AutoJoin"] == True:
		    G = cl.getGroup(op.param1)
                    if len(G.members) <= wait["Members"]:
                        cl.rejectGroupInvitation(op.param1)
		    else:
                        cl.acceptGroupInvitation(op.param1)
			#cl.sendText(op.param1,"☆Ketik ☞Help☜ Untuk Bantuan☆\n☆Harap Gunakan Dengan Bijak ^_^ ☆")
	    else:
                if wait["AutoCancel"] == True:
		    if op.param3 in Bots:
			pass
		    else:
                        cl.cancelGroupInvitation(op.param1, [op.param3])
		else:
		    if op.param3 in wait["blacklist"]:
			cl.cancelGroupInvitation(op.param1, [op.param3])
			cl.sendText(op.param1, "Blacklist Detected")
		    else:
			pass
			
        if op.type == 13:
            if op.param2 not in Creator:
             if op.param2 not in admin:
              if op.param2 not in Bots:
                if op.param2 in Creator:
                 if op.param2 in admin:
                  if op.param2 in Bots:
                    pass
                elif wait["inviteprotect"] == True:
                    wait ["blacklist"][op.param2] = True
                    random.choice(KAC).cancelGroupInvitation(op.param1,[op.param3])
                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    if op.param2 not in Creator:
                     if op.param2 not in admin:
                      if op.param2 not in Bots:
                        if op.param2 in Creator:
                         if op.param2 in admin:
                          if op.param2 in Bots:
                            pass

        if op.type == 19:
		if wait["AutoKick"] == True:
		    try:
			if op.param3 in Creator:
			 if op.param3 in admin:
			  if op.param3 in Bots:
			      pass
		         if op.param2 in Creator:
		          if op.param2 in admin:
		           if op.param2 in Bots:
		               pass
		           else:
		               random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
		               #cl.kickoutFromGroup(op.param1,[op.param2])
		               if op.param2 in wait["blacklist"]:
		                   pass
		        else:
			    random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
		    except:
		        try:
			    if op.param2 not in Creator:
			        if op.param2 not in admin:
			            if op.param2 not in Bots:
                                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
			    if op.param2 in wait["blacklist"]:
			        pass
			    else:
			        random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
		        except:
			    print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
			    if op.param2 in Creator:
			        if op.param2 in admin:
			            if op.param2 in Bots:
			              pass
			    else:
                                wait["blacklist"][op.param2] = True
		    if op.param2 in wait["blacklist"]:
                        pass
                    else:
		        if op.param2 in Creator:
		            if op.param2 in admin:
		                if op.param2 in Bots:
			             pass
		        else:
                            wait["blacklist"][op.param2] = True
		else:
		    pass
                if mid in op.param3:
                    if op.param2 in Creator:
                      if op.param2 in Bots:
                        pass
                    try:
                        #random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        random.choice(KAC).inviteIntoGroup(op.param1,admin)
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                            kk.inviteIntoGroup(op.param1,admin)
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            if op.param2 in Bots:
                                pass
                            else:
                                wait["blacklist"][op.param2] = True
                    G = ka.getGroup(op.param1)
                    G.preventJoinByTicket = False
                    ka.updateGroup(G)
                    Ti = ka.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                if Amid in op.param3:
                    if op.param2 in Creator:
                      if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        ks.inviteIntoGroup(op.param1,admin)
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                            ks.inviteIntoGroup(op.param1,admin)
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            if op.param2 in Bots:
                                pass
                            else:
                                wait["blacklist"][op.param2] = True
                    G = ka.getGroup(op.param1)
                    G.preventJoinByTicket = False
                    ka.updateGroup(G)
                    Ti = ka.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                if Bmid in op.param3:
                    if op.param2 in Creator:
                      if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        ki.inviteIntoGroup(op.param1,admin)
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                            ks.inviteIntoGroup(op.param1,admin)
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            if op.param2 in Bots:
                                pass
                            else:
                                wait["blacklist"][op.param2] = True
                    G = ka.getGroup(op.param1)
                    G.preventJoinByTicket = False
                    ka.updateGroup(G)
                    Ti = ka.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                if Cmid in op.param3:
                    if op.param2 in Creator:
                      if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        cl.inviteIntoGroup(op.param1,admin)
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                            ki.inviteIntoGroup(op.param1,admin)
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            if op.param2 in Bots:
                                pass
                            else:
                                wait["blacklist"][op.param2] = True
                    G = ks.getGroup(op.param1)
                    G.preventJoinByTicket = False
                    ks.updateGroup(G)
                    Ti = ks.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                if Dmid in op.param3:
                    if op.param2 in Creator:
                      if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        ki.inviteIntoGroup(op.param1,admin)
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                            kk.inviteIntoGroup(op.param1,admin)
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            if op.param2 in Bots:
                                pass
                            else:
                                wait["blacklist"][op.param2] = True
                    G = ki.getGroup(op.param1)
                    G.preventJoinByTicket = False
                    ki.updateGroup(G)
                    Ti = ki.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                if Emid in op.param3:
                    if op.param2 in Creator:
                      if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        ki.inviteIntoGroup(op.param1,admin)
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                            kk.inviteIntoGroup(op.param1,admin)
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            if op.param2 in Bots:
                                pass
                            else:
                                wait["blacklist"][op.param2] = True
                    G = ka.getGroup(op.param1)
                    G.preventJoinByTicket = False
                    ka.updateGroup(G)
                    Ti = ka.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                if mid in op.param3:
                    if op.param2 in Creator:
                      if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                        ki.inviteIntoGroup(op.param1,admin)
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(KAC).inviteIntoGroup(op.param1,[op.param3])
                            kk.inviteIntoGroup(op.param1,admin)
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            if op.param2 in Bots:
                                pass
                            else:
                                wait["blacklist"][op.param2] = True
                    G = ka.getGroup(op.param1)
                    G.preventJoinByTicket = False
                    ka.updateGroup(G)
                    Ti = ka.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                
                if mid in op.param3:
                    if op.param2 in Creator:
                      if op.param2 in Bots:
                        pass
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
			cl.kickoutFromGroup(op.param1,[op.param2])
			cl.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
			    ki.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
			    if op.param2 in Bots:
			        pass
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
		        if op.param2 in Bots:
			    pass
		        else:
                            wait["blacklist"][op.param2] = True

 
                if Creator in op.param3:
                  if admin in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
			cl.kickoutFromGroup(op.param1,[op.param2])
			cl.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
			    if op.param2 not in Bots:
                                ki.kickoutFromGroup(op.param1,[op.param2])
			    if op.param2 in wait["blacklist"]:
			        pass
			    else:
			        ki.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            print ("client Kick regulation or Because it does not exist in the group\ngid=["+op.param1+"]\nmid=["+op.param2+"]")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                    ki.inviteIntoGroup(op.param1,[op.param3])
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True


        if op.type == 11:
            if wait["Qr"] == True:
		if op.param2 in Creator:
		 if op.param2 in admin:
		  if op.param2 in Bots:
		   pass		
		else:
                    cl.kickoutFromGroup(op.param1,[op.param2])
            else:
                pass


        if op.type == 17:
          if wait["Sambutan"] == True:
            if op.param2 in admin:
                return
            ginfo = cl.getGroup(op.param1)
            contact = cl.getContact(op.param2)
            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
            cl.sendImageWithURL(op.param1,image)
            cl.sendText(op.param1,"нaι @" + cl.getContact(op.param2).displayName + "\nѕelaмaт daтang dι " + str(ginfo.name) + "" + str(pesan["welcom"]))
            cl.sendText(op.param1,"Creator grup nya: "+ginfo.creator.displayName)
            print "MEMBER JOIN TO GROUP"

        if op.type == 15:
          if wait["Sambutan"] == True:
            if op.param2 in admin:
                return
            ginfo = cl.getGroup(op.param1)
            contact = cl.getContact(op.param2)
            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
            cl.sendImageWithURL(op.param1,image)
            cl.sendText(op.param1,cl.getContact(op.param2).displayName +  "\n"+ "" + str(pesan["bye"]))
            #cl.inviteIntoGroup(op.param1,[op.param2])
            print "MEMBER HAS LEFT THE GROUP"

        if op.type == 15:
          if wait["ngundang"] == True:
            if op.param2 in admin:
                return
            #cl.inviteIntoGroup(op.param1,[op.param2])
            cl.inviteIntoGroup(op.param1,[op.param3])
            print "MEMBER DI INVITE"

        if op.type == 26:
            msg = op.message
            
            if msg.from_ in mimic["target"] and mimic["status"] == True and mimic["target"][msg.from_] == True:
                    text = msg.text
                    if text is not None:
                        cl.sendText(msg.to,text)
    
            if msg.to in settings["simiSimi"]:
                if settings["simiSimi"][msg.to] == True:
                    if msg.text is not None:
                        text = msg.text
                        r = requests.get("http://api.ntcorp.us/chatbot/v1/?text=" + text.replace(" ","+") + "&key=beta1.nt")
                        data = r.text
                        data = json.loads(data)
                        if data['status'] == 200:
                            if data['result']['result'] == 100:
                                cl.sendText(msg.to,data['result']['response'].encode('utf-8'))

            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["kickMention"] == True:
                     contact = cl.getContact(msg.from_)
                     cName = contact.displayName
                     #balas = ["Aku Bilang Jangan Ngetag Lagi " + cName + "\nAku Kick ya! Sorry, Byee!!!"]
                     balas = cName +" \n"+ "" + str(pesan["responkick"] + "\n"+jam)
                     #ret_ = random.choice(balas)                     
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  cl.sendText(msg.to,balas)
                                  cl.kickoutFromGroup(msg.to,[msg.from_])
                                  break
                                  print "RESPON KICK SEDANG AKTIF"

            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["respone3"] == True:
                     contact = cl.getContact(msg.from_)
                     #cName = contact.displayName
                     pesan["respon3"] in[""," ","\n",None]
                     #ret_ = random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  c = Message(to=msg.from_, contentType = 7)
                                  c.contentMetadata={'STKID': '10',
                                                     'STKPKGID': '1',
                                                     'STKVER': '100'}#tikel ijo nyengir
                                  msg.contentType = 7
                                  msg.contentMetadata={'STKID': '10',
                                                       'STKPKGID': '1',
                                                       'STKVER': '100'}#tikel ana bolem hp jatoh
                                  #msg.contentType = 7
                                  #msg.contentMetadata={'STKID': '20412842',
                                                       #'STKPKGID': '1601853',
                                                       #'STKVER': '19'}
                                  cl.sendMessage(msg)
                                  cl.sendText(msg.from_, "\n"+ str(pesan["respon3"]))
                                  cl.sendMessage(c)
                                  #cl.sendMessage(str(pesan["respon3"]))
                                  break
                                  print "REAPON 3 MODE TAG INBOX AKTIF"

            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["koplok"] == True:
                     contact = cl.getContact(msg.from_)                                                                          
                     cName = contact.displayName
                     #balas = [cName + "\nHADEWHH...tag molo..Rasain nih!!!"]
                     balas = cName +" \n"+ "" + str(pesan["respon2"] + "\n" + jam)
                     #ret_ = random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:                                                                                           
                                  cl.sendText(msg.to,balas)                                                   
                                  msg.contentType = 13                                                                                        
                                  msg.contentMetadata = {'mid': "NADYA,'"}
                                  cl.sendMessage(msg)
                                  break
                                  print "RESPON 2  BLANK LINE EROR AKTIF"

            if 'MENTION' in msg.contentMetadata.keys() != None:                                            
                 if wait["jones"] == True:
                     contact = cl.getContact(msg.from_)
                     cName = contact.pictureStatus
                     xName = contact.displayName
                     msg.text = "@" + xName +" \n"+ "" + str(pesan["respon1"])
                     #ret_ = random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  xlen = str(len(xName)+1)
                                  msg.contentType = 0
                                  msg.contentMetadata ={'MENTION':'{"MENTIONEES":[{"S":"0","E":'+json.dumps(xlen)+',"M":'+json.dumps(msg.from_)+'}]}','EMTVER':'4'}
                                  cl.sendMessage(msg)
                                  image = "http://dl.profile.line-cdn.net/" + cName
                                  cl.sendImageWithURL(msg.to,image)
                                  break
                                  print "RESPON TAG 1 IMAGE JONES AKTIF"

            if 'MENTION' in msg.contentMetadata.keys() != None:                                     
                 if wait["jones2"] == True:
                     contact = cl.getContact(msg.from_)
                     cName = contact.pictureStatus
                     xName = contact.displayName
                     #pesannya = xName +" \n"+ "" + str(pesan["respon5"])
                     #ret_ = random.choice(pesannya)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:                                                                                                                   
                           if mention['M'] in Bots:                                                                                                  
                                  cl.sendText(msg.to, xName +" \n"+ "" + str(pesan["respon5"]))
                                  image = "http://dl.profile.line-cdn.net/" + cName
                                  cl.sendImageWithURL(msg.to,image)
                                  break
                                  print "RESPON 5 IMAGE JONES AKTIF"

            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["sepamRes"] == True:
                     cName = cl.getContact(msg.from_).displayName
                     #cName = contact.displayName
                     pesan["respon4"] in[""," ","\n",None]
                     #msg.text = "@"+ cName +"" +"\n"+ "" + str(pesan["respon4"] + "\n" + datetime.today().strftime('%H:%M:%S'))
                     #ret_ = random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  c = Message(to=msg.from_, contentType = 7)
                                  c.contentMetadata={'STKID': '10',
                                                     'STKPKGID': '1',
                                                     'STKVER': '100'}#tikel ana bolem ngambek gejog hp
                                  msg.contentType = 7
                                  msg.contentMetadata={'STKID': '10',
                                                       'STKPKGID': '1',
                                                       'STKVER': '100'}#tikel ana bolem marah gebrag meja
                                  #msg.contentType = 7......
                                  #msg.contentMetadata={'STKID': '20412836',
                                                       #'STKPKGID': '1601853',
                                                       #'STKVER': '13'}
                                  #msg.contentType = 7
                                  #msg.contentMetadata={'STKID': '20412842',
                                                       #'STKPKGID': '1601853',
                                                       #'STKVER': '19'}
                                  #msg.contentType = 7
                                  #msg.contentMetadata={'STKID': '11908013',
                                                       #'STKPKGID': '1294122',
                                                       #'STKVER': '16'}
                                  #cl.sendMessage(msg)
                                  #cl.sendMessage(msg)
                                  #tkl = random.choice(msg)
                                  cl.sendMessage(msg)
                                  cl.sendText(msg.to,"Tag mlu lu  "+cName+ "\nWe Spam nih...!!!")
                                  cl.sendText(msg.from_, str(pesan["respon4"]))
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)                                                                 
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)                                                                     
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)                                                                                 
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)                                                                                
                                  cl.sendMessage(c)                                                                                 
                                  cl.sendMessage(c)                                                                                 
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)                                                                                
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)                                                                               
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)                                                                              
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)                                                                               
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)                                                                                
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)                                                                               
                                  cl.sendMessage(c)
                                  cl.sendMessage(c)
                                  cl.sendText(msg.from_, "GOSAH TAG MULU LAH...KeNA Spam KAN...HHHHHH")
                                  break
                                  print "RESPON SPAM 4 AKTIF"

            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["koynRes"] == True:
                     cName = cl.getContact(msg.from_).displayName
                     #cName = contact.displayName
                     #pesanku = cName +"\n"+ "" + str(pesan["respon6"])
                     #ret_ = random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']                                                             
                     for mention in mentionees:                                                                            
                           if mention['M'] in Bots:
                                  #cl.sendText(msg.to,balas)
                                  c = Message(to=msg.to, contentType = 7)
                                  c.contentMetadata={'STKID': '10',
                                                     'STKPKGID': '1',
                                                     'STKVER': '100'}
                                  #msg.contentType = 7......
                                  #msg.contentMetadata={'STKID': '20412836',
                                                       #'STKPKGID': '1601853',
                                                       #'STKVER': '13'}
                                  #msg.contentType = 7
                                  #msg.contentMetadata={'STKID': '20412842',
                                                       #'STKPKGID': '1601853',
                                                       #'STKVER': '19'}
                                  #msg.contentType = 7
                                  #msg.contentMetadata={'STKID': '11908013',
                                                       #'STKPKGID': '1294122',
                                                       #'STKVER': '16'}
                                  #cl.sendMessage(msg)
                                  #cl.sendMessage(msg)
                                  #tkl = random.choice(msg)
                                  cl.sendText(msg.to, cName +" \n"+ "" + str(pesan["respon6"]))
                                  cl.sendMessage(c)                                                                                
                                  break
                                  print "RESPON 6 TEXT BIASA SEDANG AKTIF"

            if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                     cName = cl.getContact(msg.from_).displayName
                     #cName = contact.displayName
                     msg.text = "@"+ cName +"" +"\n"+ "" + str(pesan["respon"])
                     #ret_ = random.choice(balas)
                     name = re.findall(r'@(\w+)', msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                           if mention['M'] in Bots:
                                  xlen = str(len(cName)+1)
                                  msg.contentType = 0
                                  msg.contentMetadata ={'MENTION':'{"MENTIONEES":[{"S":"0","E":'+json.dumps(xlen)+',"M":'+json.dumps(msg.from_)+'}]}','EMTVER':'4'}
                                  #cl.sendText(msg.to,balas)
                                  c = Message(to=msg.to, contentType = 7)
                                  c.contentMetadata={'STKID': '10',
                                                     'STKPKGID': '1',
                                                     'STKVER': '100'}
                                  #msg.contentType = 7      
                                  #msg.contentMetadata={'STKID': '20412836',
                                                       #'STKPKGID': '1601853',
                                                       #'STKVER': '13'}
                                  #msg.contentType = 7
                                  #msg.contentMetadata={'STKID': '20412842',
                                                       #'STKPKGID': '1601853',
                                                       #'STKVER': '19'}
                                  #msg.contentType = 7
                                  #msg.contentMetadata={'STKID': '11908013',
                                                       #'STKPKGID': '1294122',
                                                       #'STKVER': '16'}
                                  #cl.sendMessage(msg)
                                  #cl.sendMessage(msg)
                                  #tkl = random.choice(msg)
                                  cl.sendMessage(msg)
                                  cl.sendMessage(c)
                                  break
                                  print "RESPON 1 SEDANG AKTIF"
        if op.type == 25:
            msg = op.message                                  
                              
            if msg.text in ["Bot on"]:
              if msg.from_ in admin:
                wait["Bot"] = True
                cl.sendText(msg.to,"🄱🄾🅃 🅂🅃🄰🅁🅃 🄾🄽 🄰🄶🄰🄸🄽....!!! ^_^")
                print "BOT AKTIF KEMBALI"

        if op.type == 25:
          if wait["Bot"] == True:
            msg = op.message
            
            if msg.contentType == 7:
              if wait["sticker"] == True:
                msg.contentType = 0
                stk_id = msg.contentMetadata['STKID']
                stk_ver = msg.contentMetadata['STKVER']
                pkg_id = msg.contentMetadata['STKPKGID']
                filler = "════════════════\n        🔘 Sticker Check 🔘\n════════════════\n🔘 STKID : %s\n🔘 STKPKGID : %s\n🔘 STKVER : %s\n🔘 Link : line://shop/detail/%s" % (stk_id,pkg_id,stk_ver,pkg_id)+"\n════════════════\n════════════════"
                cl.sendText(msg.to, filler)
                wait["sticker"] = False
            else:
                pass

            if wait["alwaysRead"] == True:
                if msg.toType == 0:
                    cl.sendChatChecked(msg.from_,msg.id)
                else:
                    cl.sendChatChecked(msg.to,msg.id)
                    
            if msg.contentType == 16:
                if wait['likeOn'] == True:
                     url = msg.contentMetadata["postEndUrl"]
                     cl.like(url[25:58], url[66:], likeType=1005)
                     cl.comment(url[25:58], url[66:], wait["comment"])
                     cl.sendText(msg.to,"lιĸe ѕυĸѕeѕ вoѕ !!")                     
                     wait['likeOn'] = False


            if msg.contentType == 13:
                if wait["wblacklist"] == True:
		    if msg.contentMetadata["mid"] not in admin:
                        if msg.contentMetadata["mid"] in wait["blacklist"]:
                            cl.sendText(msg.to,"add тo вlacĸlιѕт (╯з╰)")
                            wait["wblacklist"] = False
                        else:
                            wait["blacklist"][msg.contentMetadata["mid"]] = True
                            wait["wblacklist"] = False
                            nadya.sendText(msg.to,"add тo вlacĸlιѕт (╯з╰)")
		    else:
			cl.sendText(msg.to,"Admin Detected~")
			

                elif wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"Terhapus")
                        wait["dblacklist"] = False

                    else:
                        wait["dblacklist"] = False
                        cl.sendText(msg.to,"Tidak Ada Black List")
            
                    
 
                elif wait["Contact"] == True:
                     msg.contentType = 0
                     cl.sendText(msg.to,msg.contentMetadata["mid"])
                     if 'displayName' in msg.contentMetadata:
                         contact = cl.getContact(msg.contentMetadata["mid"])
                         try:
                             cu = cl.channel.getCover(msg.contentMetadata["mid"])
                         except:
                             cu = ""
                         cl.sendText(msg.to,"Nama:\n" + msg.contentMetadata["displayName"] + "\n\nMid:\n" + msg.contentMetadata["mid"] + "\n\nStatus:\n" + contact.statusMessage + "\n\nPhoto Profile:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\nPhoto Cover:\n" + str(cu))
                     else:
                         contact = cl.getContact(msg.contentMetadata["mid"])
                         try:
                             cu = cl.channel.getCover(msg.contentMetadata["mid"])
                         except:
                             cu = ""
                         cl.sendText(msg.to,"ηαмα :\n" + msg.contentMetadata["displayName"] + "\n\nмι∂ : \n" + msg.contentMetadata["mid"] + "\n\nѕтaтυѕ вιo : \n" + contact.statusMessage + "\n\npнoтo proғιle : \nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\npнoтo cover :  \n" + str(cu))


 
            elif msg.text == "Ginfo":
              if msg.from_ in admin:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        gCreator = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    if wait["lang"] == "JP":
                        if ginfo.invitee is None:
                            sinvitee = "0"
                        else:
                            sinvitee = str(len(ginfo.invitee))
                        if ginfo.preventJoinByTicket == True:
                            u = "close"
                        else:
                            u = "open"
                        cl.sendText(msg.to,"naмa rooм :\n" + str(ginfo.name) + "\n\nrooм ιd : \n" + msg.to + "\n\npeмвυaт rooм :\n" + gCreator + "\n\nѕтaтυѕ proғιle : \nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus + "\n\njυмвlaн мeмвer : " + str(len(ginfo.members)) + "мeмвer pendιng :" + sinvitee + "ѕтaтυѕ qr code :" + u + "it is inside")
                    else:
                        cl.sendText(msg.to,"naмa rooм :\n" + str(ginfo.name) + "\nrooм ιd : \n" + msg.to + "\npeмвυaт rooм :\n" + gCreator + "\nѕтaтυѕ proғιle : \nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"can noт вe υѕed oυтѕιde тнe groυp\n"+jam)
                    else:
                        cl.sendText(msg.to,"Not for use less than group\n"+jam)
                        

 
            elif msg.text is None:
                return
 
            elif msg.text in ["Creator","Owner"]:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Anto}
                cl.sendMessage(msg)
		cl.sendText(msg.to,"creaтor & edιтor  ѕc\n" + jam)
            elif msg.text in ["Pulang kuy"]:
              if msg.from_ in admin:                                                                                                                                                                                                                                                            
                  ki.leaveGroup(msg.to)
                  kk.leaveGroup(msg.to)
                  kc.leaveGroup(msg.to)                                                                                                                                   
                  ks.leaveGroup(msg.to)
                  ka.leaveGroup(msg.to)
                  cl.sendText(msg.to,"Ikut Pulang ga? \nsend Command 'Ok ikut'jika Ok!")
                  print "BOT LEFT VIA COMMAND PULANG KUY"

            elif msg.text in ["Ok ikut"]:
              if msg.from_ in admin:
                  cl.sendText(msg.to,"Jin lep Bos..\nBye All...see u next time")
                  cl.leaveGroup(msg.to)
                  print "BOT ADMIN LEFT ROOM"

            elif msg.text in ["Kuy masuk"]:
              if msg.from_ in admin:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = cl.reissueGroupTicket(msg.to)
                        ka.acceptGroupInvitationByTicket(msg.to,Ticket)
                        ks.acceptGroupInvitationByTicket(msg.to,Ticket)
                        kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                        kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                        ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                        print "ALL BOT MASUK GROUP"
                        G.preventJoinByTicket(G)
                        cl.updateGroup(G)
                        random.choice(KAC).sendText(msg.to," Done....^_^")

            elif msg.text in ["Masuk kuy"]:
              if msg.from_ in admin:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = cl.reissueGroupTicket(msg.to)
                        ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                        kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                        kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                        ks.acceptGroupInvitationByTicket(msg.to,Ticket)
                        ka.acceptGroupInvitationByTicket(msg.to,Ticket)
                        G = cl.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        cl.updateGroup(G)
                        print "ALL BOT MASUK ROOM"
                        G.preventJoinByTicket(G)
                        cl.updateGroup(G)
                        random.choice(KAC).sendText(msg.to," Done....^_^")
        
            elif msg.text in ["Me"]:                                                                         
              if msg.from_ in admin:
                msg.contentType = 13                                                                           
                msg.contentMetadata = {'mid': mid}                                                               
                cl.sendMessage(msg)
                print "Me komando"

            elif msg.text in ["Mybot"]:
              if msg.from_ in admin:
                msg.contentType = 13
                msg.contentMetadata = {'mid': mid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Amid}
                ki.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Bmid}
                kk.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Cmid}                                                                                    
                kc.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Dmid}
                ks.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Emid}                            
                ka.sendMessage(msg)
                print "MY BOT CONTACT"

            #elif msg.text in ["Admin","admin"]:
                #msg.contentType = 13
                #admin1 = "ub542d871ea20170d941cc026c27eb4e6"
                #admin2 = "ub542d871ea20170d941cc026c27eb4e6"
                #admin3 = "ub542d871ea20170d941cc026c27eb4e6"
                #msg.contentMetadata = {'mid': tjia}
                #cl.sendMessage(msg)
                #msg.contentMetadata = {'mid': admin1}
                #cl.sendMessage(msg)
                #msg.contentMetadata = {'mid': admin2}
                #cl.sendMessage(msg)
                #msg.contentMetadata = {'mid': admin3}
                #cl.sendMessage(msg)                
		#cl.sendText(msg.to,"Itu Admin Kami (^_^)")	
		
 
                
            #elif "Admin add @" in msg.text:
              #if msg.from_ in Creator:
                #print "[Command]Admin add executing"
                #_name = msg.text.replace("Admin add @","")
                #_nametarget = _name.rstrip('  ')
                #gs = cl.getGroup(msg.to)
                #targets = []
                #for g in gs.members:
                    #if _nametarget == g.displayName:
                        #targets.append(g.mid)
                #if targets == []:
                   #cl.sendText(msg.to,"Contact Tidak Di Temukan")
                #else:
                   #for target in targets:
                        #try:
                            #admin.append(target)
                            #cl.sendText(msg.to,"Admin Chucky Ditambahkan")
                        #except:
                            #pass
                #print "[Command]Admin add executed"
              #else:
                #cl.sendText(msg.to,"Command Denied.")
                #cl.sendText(msg.to,"Creator Permission Required.")
                
            #elif "Admin remove @" in msg.text:
              #if msg.from_ in Creator:
                #print "[Command]Admin Remove Executing"
                #_name = msg.text.replace("Admin remove @","")
                #_nametarget = _name.rstrip('  ')
                #gs = cl.getGroup(msg.to)
                #targets = []
                #for g in gs.members:
                    #if _nametarget == g.displayName:
                        #targets.append(g.mid)
                #if targets == []:
                   #cl.sendText(msg.to,"Contact Tidak Di Temukan")
                #else:
                   #for target in targets:
                        #try:
                            #admin.remove(target)
                            #cl.sendText(msg.to,"Admin Chucky Dihapus")
                        #except:
                            #pass
                #print "[Command]Admin remove executed"
              #else:
                #cl.sendText(msg.to,"Command Denied.")
                #cl.sendText(msg.to,"Creator Permission Required.")
                
            elif msg.text in ["Admin list","admin list","List admin"]:
              if admin == []:
                  cl.sendText(msg.to,"The Admin List Is Empty")
              else:
                  cl.sendText(msg.to,"Tunggu...")
                  mc = "═══════════\n║        🔘ADMIN LIST🔘\n═══════════\n"
                  for mi_d in admin:
                      mc += "╠••> " +cl.getContact(mi_d).displayName + "\n"
                  cl.sendText(msg.to,mc + "═══════════")
                  print "[Command]Admin List executed"
                 

 

	    elif msg.text in ["Group creator","Gcreator","gcreator"]:
		ginfo = cl.getGroup(msg.to)
		gCreator = ginfo.creator.mid
                msg.contentType = 13
                msg.contentMetadata = {'mid': gCreator}
                cl.sendMessage(msg)
		cl.sendText(msg.to,"conтacт peмвυaт rooм ιnι !!" + jam)
 

                
            elif msg.contentType == 16:
                if wait["Timeline"] == True:
                    msg.contentType = 0
                    msg.text = "post URL\n" + msg.contentMetadata["postEndUrl"]
                    cl.sendText(msg.to,msg.text)

            
            if msg.contentType == 13:
                if wait["steal"] == True:
                    _name = msg.contentMetadata["displayName"]
                    copy = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            print "[Target] Stealed"
                            break                             
                        else:
                            targets.append(copy)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                cl.findAndAddContactsByMid(target)
                                contact = cl.getContact(target)
                                cu = cl.channel.getCover(target)
                                path = str(cu)
                                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nMid :\n" + msg.contentMetadata["mid"] + "\n\nBio :\n" + contact.statusMessage)
                                cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                                cl.sendImageWithURL(msg.to,image)
                                cl.sendText(msg.to,"Cover " + contact.displayName)
                                cl.sendImageWithURL(msg.to,path)
                                wait["steal"] = False
                                break
                            except:
                                    pass


            if msg.contentType == 13:
                if wait["gift"] == True:
                    _name = msg.contentMetadata["displayName"]
                    copy = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            print "[Target] Gift spam"
                            break
                        else:
                            targets.append(copy)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                cl.sendText(msg.to,"Tikel sp Terkirim bos")
                                msg.contentType = 7
                                msg.contentMetadata={'STKID': '6',
                                                     'STKPKGID': '1',
                                                     'STKVER': '100'}
                                msg.to = target
                                msg.text = None
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)                                                                            
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                ki.sendMessage(msg)
                                wait['gift'] = False
                                break
                            except:
                                     msg.contentMetadata = {'mid': target}
                                     wait["gift"] = False
                                     break

            if msg.contentType == 13:
                if wait["spam1"] == True:
                    _name = msg.contentMetadata["displayName"]
                    copy = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            print "[Target] SPAM TEXT SUKSES"
                            break
                        else:
                            targets.append(copy)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                Ispam =  str(pesan["spamr"])
                                msg.to = target
                                #msg.text = None
                                #cl.sendMessage(msg)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                cl.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                ki.sendMessage(Ispam)
                                wait['spam1'] = False
                                break
                            except:
                                     msg.contentMetadata = {'mid': target}
                                     wait["spam1"] = False
                                     break

            if msg.contentType == 13:
                if wait["spam2"] == True:
                    _name = msg.contentMetadata["displayName"]
                    copy = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if _name in s.displayName:
                            print "[Target] SEND EROR CODE HANK TERKIRIM"
                            break
                        else:
                            targets.append(copy)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                cl.sendText(msg.to,"Gift Sesuatu sudah Terkirim")
                                msg.contentType = 13
                                msg.contentMetadata = {'mid': "NADYA,'"}
                                msg.to = target
                                msg.text = None
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)                                   
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                cl.sendMessage(msg)
                                wait['spam2'] = False
                                break
                            except:
                                     msg.contentMetadata = {'mid': target}
                                     wait["spam2"] = False
                                     break

            if msg.contentType == 13:
                if wait['invite'] == True:
                     _name = msg.contentMetadata["displayName"]
                     invite = msg.contentMetadata["mid"]
                     groups = cl.getGroup(msg.to)
                     pending = groups.invitee
                     targets = []
                     for s in groups.members:
                         if _name in s.displayName:
                             cl.sendText(msg.to, _name + " Berada DiGrup Ini")
                         else:
                             targets.append(invite)
                     if targets == []:
                         pass
                     else:
                         for target in targets:
                             try:
                                 cl.findAndAddContactsByMid(target)
                                 cl.inviteIntoGroup(msg.to,[target])
                                 cl.sendText(msg.to,"Invite " + _name)
                                 wait['invite'] = False
                                 break                              
                             except:             
                                      cl.sendText(msg.to,"Limit Invite")
                                      wait['invite'] = False
                                      break

            elif msg.text in ["Help","Key","help","key"]:
              if msg.from_ in admin:
                print "MENU"
                #mulai = time.time()
                eltime = time.time() - mulai
                skn = [HELPMESSAGE,skin1,skin2,skin3,skin4]
                pil = random.choice(skn)
                cl.sendText(msg.to,pil + "\n" + jam + "  Run : "+waktu(eltime))
            elif msg.text in ["About"]:
              if msg.from_ in admin:
                print "ABOUT"
                cl.sendText(msg.to, About + "\n" +  jam)
            elif msg.text in ["Help set"]:
              if msg.from_ in admin:
                print "HELP SET"
                cl.sendText(msg.to, Helpset + "\n" + jam)
            elif "Change respon: " in msg.text:
              if msg.from_ in admin:
                pesan["respon"] = msg.text.replace("Change respon: ","")
                cl.sendText(msg.to,"мeѕѕage reѕpon cнange тo : \n══════════════════\n" + pesan["respon"] + "\n"+jam)
                print "CHANGE TEXT RESPON"
    
            elif "Change respon1: " in msg.text:
              if msg.from_ in admin:
                pesan["respon1"] = msg.text.replace("Change respon1: ","")
                cl.sendText(msg.to,"мeѕѕage reѕpon1 cнange тo : \n══════════════════\n\n" + pesan["respon1"] +"\n"+jam)
                print "CHANGE TEXT RESPON1"
        
            elif "Change respon2: " in msg.text:
              if msg.from_ in admin:
                pesan["respon2"] = msg.text.replace("Change respon2: ","")
                cl.sendText(msg.to,"мeѕѕage reѕpon2 cнange тo : \n══════════════════\n\n" + pesan["respon2"] +"\n"+jam)
                print "CHANGE TEXT RESPON2"
        
            elif "Change respon3: " in msg.text:
              if msg.from_ in admin:
                pesan["respon3"] = msg.text.replace("Change respon3: ","")
                cl.sendText(msg.to,"мeѕѕage reѕpon3 cнange тo : \n══════════════════\n" + pesan["respon3"] +"\n"+jam)
                print "CHANGE TEXT RESPON3"
        
            elif "Change respon4: " in msg.text:
              if msg.from_ in admin:
                pesan["respon4"] = msg.text.replace("Change respon4: ","")
                cl.sendText(msg.to,"мeѕѕage reѕpon4 cнange тo : \n══════════════════\n" + pesan["respon4"] +"\n"+jam)
                print "CHANGE TEXT RESPON4"

            elif "Change respon5: " in msg.text:
              if msg.from_ in admin:
                pesan["respon5"] = msg.text.replace("Change respon5: ","")                                                                             
                cl.sendText(msg.to,"мeѕѕage reѕpon5 cнange тo : \n══════════════════\n" + pesan["respon5"] +"\n"+jam)
                print "CHANGE TEXT RESPON 5"
                
            elif "Change respon6: " in msg.text:
              if msg.from_ in admin:
                pesan["respon6"] = msg.text.replace("Change respon6: ","")
                cl.sendText(msg.to,"мeѕѕage reѕpon6 cнange тo : \n══════════════════\n" + pesan["respon6"] +"\n"+jam)
                print "CHANGE TEXT RESPON 6"

            elif "Change responkick: " in msg.text:
              if msg.from_ in admin:
                pesan["responkick"] = msg.text.replace("Change responkick: ","")
                cl.sendText(msg.to,"мeѕѕage reѕpon ĸιcĸ cнange тo : \n══════════════════\n" + pesan["responkick"] +"\n"+jam)
                print "CHANGE TEXT RESPON KICK"
        
            elif "Change welcome: " in msg.text:
              if msg.from_ in admin:
                pesan["welcom"] = msg.text.replace("Change welcome: ","")
                cl.sendText(msg.to,"мeѕѕage welcoмe cнange тo: \n══════════════════\n" + pesan["welcom"] +"\n"+jam)
                print "CHANGE TEXT WELCOME"
        
            elif "Change bye: " in msg.text:
              if msg.from_ in admin:
                pesan["bye"] = msg.text.replace("Change bye: ","")
                cl.sendText(msg.to,"мeѕѕage вye cнange тo: \n══════════════════\n" + pesan["bye"] +"\n"+jam)
                print "CHANGE TEXT BYE"
        
            elif "Change sider1: " in msg.text:
              if msg.from_ in admin:
                pesan["sidr1"] = msg.text.replace("Change sider1: ","")
                cl.sendText(msg.to,"мeѕѕage cнecĸ ѕιder1 cнange тo: \n══════════════════\n" + pesan["sidr1"] +"\n"+jam)
                print "CHANGE TEXT SIDER 1"
        
            elif "Change sider2: " in msg.text:
              if msg.from_ in admin:
                pesan["sidr2"] = msg.text.replace("Change sider2: ","")
                cl.sendText(msg.to,"мeѕѕage cнecĸ ѕιder2 cнange тo: \n══════════════════\n" + pesan["sidr2"] +"\n"+jam)
                print "CHANGE TEXT SIDER 2"
        
            elif "Change sider3: " in msg.text:
              if msg.from_ in admin:
                pesan["sidr3"] = msg.text.replace("Change sider3: ","")
                cl.sendText(msg.to,"мeѕѕage cнecĸ ѕιder3 cнange тo: \n══════════════════\n" + pesan["sidr3"] +"\n"+jam)
                print "CHANGE TEXT SIDER 3"
        
            elif "Change message: " in msg.text:
              if msg.from_ in admin:
                wait["message"] = msg.text.replace("Change message: ","")
                cl.sendText(msg.to,"мeѕѕage add cнange тo: \n══════════════════\n\n" + wait["mesaage"] +"\n"+jam)
                print "CHANGE TEXT MESSAGE"
        
            elif "Change comment: " in msg.text:
              if msg.from_ in admin:
                wait["comment"] = msg.text.replace("Change comment: ","")
                cl.sendText(msg.to,"мeѕѕage coммenт cнange тo: \n══════════════════\n\n" + wait["comment"] +"\n"+jam)
                print "CHANGE TEXT COMMENT"
        
            elif "Cek all msg" in msg.text:
              if mag.from_ in admin:
                cl.sendText(msg.to,"      🔘 STATUS ALL MESSAGE TEXT 🔘\n══════════════════\nMsg welcome : "+ pesan["welcom"]+"\nMsg bye : "+ pesan["bye"]+"\nMsg Respon : "+ pesan["respon"]+"\nMsg respon1 : "+ pesan["respon1"])
                print "CEK TEXT ALL MSG"
        
            elif "Cek message" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage :\n"+ wait["message"] +"\n"+jam)
                print "CEK  TEXT MESSAGE"
            elif "Cek welcome" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage welcoмe :\n"+ pesan["welcom"] +"\n"+jam)
                print "CEK TEXT WELCOME"
        
            elif "Cek bye" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage вye :\n"+ pesan["bye"] +"\n"+jam)
                print "CEK TEXT BYE"
        
            elif "Cek comment" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage coммenт :\n"+ wait["comment"] +"\n"+jam)
                print "CEK TEXT COMMENT"
    
            elif "Cek respon" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage reѕpon :\n"+ pesan["respon"] +"\n"+jam)
                print "CEK TEXT RESPON"
    
            elif "Cek respon1" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage reѕpon1:\n"+ pesan["respon1"] +"\n"+jam)
                print "CEK TEXT RESPON 1"
    
            elif "Cek respon2" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage reѕpon2: \n"+ pesan["respon2"] +"\n"+jam)
                print "CEK  TEXT RESPON 2"
                
            elif "Cek respon3" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage reѕpon3:\n"+ pesan["respon3"] +"\n"+jam)
                print "CEK  TEXT RESPON3"
                
            elif "Cek respon4" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage reѕpon4: \n"+ pesan["respon4"] +"\n"+jam)
                print "CEK TEXT RESPON 4"
                
            elif "Cek respon5" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage reѕpon5: \n"+ pesan["respon5"] +"\n"+jam)
                print "CEK TEXT RESPON 5"

            elif "Cek respon6" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage reѕpon6: \n"+ pesan["respon6"] +"\n"+jam)
                print "CEK TEXT RESPON 6"

            elif "Cek responkick" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage reѕpon кιcк:\n"+ pesan["responkick"] +"\n"+jam)
                print "CEK TEXT RESPON kick"
                
            elif "Cek sider" in msg.text:
              if msg.from_ in admin:
                cl.sendText(msg.to,"мeѕѕage ѕιder1:"+ pesan["sidr1"]+"\nмeѕѕage ѕιder2 : "+pesan["sidr2"]+ "\nмeѕѕage ѕιder3 : "+pesan["sidr3"])
                print "CEK  TEXT ALL SIDER"
    
            elif "Change spam: " in msg.text:
              if msg.from_ in admin:                                                                                        
                pesan["spamr"] = msg.text.replace("Change spam: ","")
                cl.sendText(msg.to,"cнange ѕpaм тeхт тo::\n" + pesan["spamr"] +"\n"+jam)
                print "CEK TEXT SPAM"

            elif 'sticker:' in msg.text.lower():
                                try:
                                    query = msg.text.replace("sticker:", "")
                                    query = int(query)
                                    if type(query) == int:
                                        cl.sendImageWithURL(msg.to, 'https://stickershop.line-scdn.net/stickershop/v1/product/'+str(query)+'/ANDROID/main.png')
                                        cl.sendText(msg.to, 'https://line.me/S/sticker/'+str(query))
                                    else:
                                        cl.sendText(msg.to, 'gunakan key sticker angka bukan huruf')
                                except Exception as e:
                                    cl.sendText(msg.to, str(e))
            elif 'stickersss:' in msg.text.lower():
                                try:
                                    query = msg.text.replace("sticker:", "")
                                    query = int(query)
                                    if type(query) == int:
                                        cl.sendImageWithURL(msg.to, 'https://stickershop.line-scdn.net/stickershop/v1/product/'+str(query)+'/ANDROID/main.png')
                                        cl.sendText(msg.to, 'https://line.me/S/sticker/'+str(query))
                                    else:
                                        cl.sendText(msg.to, 'gunakan key sticker angka bukan huruf')
                                except Exception as e:
                                    cl.sendText(msg.to, str(e))
            #elif msg.text in ["Key 2","help 2","Help 2"]:
                #cl.sendText(msg.to,groupMessage)p~p

            #elif msg.text in ["Key","help","Help"]:
                #cl.sendText(msg.to,helpMessage)

            #elif msg.text in ["Key 3","help 3","Help 3"]:
                #cl.sendText(msg.to,selfMessage)

            #elif msg.text in ["Key 4","help 4","Help 4"]:
                #cl.sendText(msg.to,botMessage)

            #elif msg.text in ["Key 5","help 5","Help 5"]:
                #cl.sendText(msg.to,setMessage)~pp

            #elif msg.text in ["Key 6","help 6","Help 6"]:
                #cl.sendText(msg.to,mediaMessage)
                
            #elif msg.text in ["Key 7","help 7","Help 7"]:
                #cl.sendText(msg.to,adminMessage)
    
            elif msg.text.lower() == 'mybot':
              if msg.from_ in admin:
                msg.contentType = 13
                msg.contentMetadata = {'mid': mid}
                cl.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Amid}
                ki.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Bmid}
                kk.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Cmid}                                                                                    
                kc.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Dmid}
                ks.sendMessage(msg)
                msg.contentType = 13
                msg.contentMetadata = {'mid': Emid}                            
                ka.sendMessage(msg)
                print "MY BOT KONTAK"

            elif "Invite me" in msg.text:
              if msg.from_ in admin:                                                                                       
                         gid = cl.getGroupIdsJoined()
                         for i in gid:                                                                                           
                                cl.findAndAddContactsByMid(msg.from_)
                                cl.inviteIntoGroup(i,[msg.from_])
                                cl.sendText(msg.to, "ѕυĸѕeѕѕ ιnvιтe yoυ ιnтo rooм\n\n"+jam)
            elif msg.text in ["List grup"]:
                    gid = cl.getGroupIdsJoined()
                    h = ""
		    jml = 0
                    for i in gid:
		        gn = cl.getGroup(i).name
                        h += "♦【%s】\n" % (gn)
		        jml += 1
                    cl.sendText(msg.to,"   🔘 lιѕт groυp 🔘  \n════════════════\n"+ h +"\nтoтal : "+str(jml)+"\n════════════════")
                    print "LIST ROOM"

	    elif "Ban grup: " in msg.text:
		grp = msg.text.replace("Ban grup: ","")
		gid = cl.getGroupIdsJoined()
		if msg.from_ in admin:
		    for i in gid:
		        h = cl.getGroup(i).name
			if h == grp:
			    wait["BlGroup"][i]=True
			    cl.sendText(msg.to, "Success Ban Group : "+grp)
			else:
			    pass
		else:
		    cl.sendText(msg.to, "Sukdes Bos")
 
            elif msg.text in ["List ban","List ban group"]:
		if msg.from_ in admin:
                    if wait["BlGroup"] == {}:
                        cl.sendText(msg.to,"Tidak Ada")
                    else:
                        mc = ""
                        for gid in wait["BlGroup"]:
                            mc += "-> " +cl.getGroup(gid).name + "\n"
                        cl.sendText(msg.to,"===[Ban Group]===\n"+mc)
		else:
		    cl.sendText(msg.to, "U are not Admin")
 
	    elif msg.text in ["Del ban: "]:
		if msg.from_ in admin:
		    ng = msg.text.replace("Del ban: ","")
		    for gid in wait["BlGroup"]:
		        if cl.getGroup(gid).name == ng:
			    del wait["BlGroup"][gid]
			    cl.sendText(msg.to, "Success del ban "+ng)
		        else:
			    pass
		else:
		    cl.sendText(msg.to, "U are not Admin")
 
            elif "Join grup: " in msg.text:
		ng = msg.text.replace("Join grup: ","")
		gid = cl.getGroupIdsJoined()
		try:
		    if msg.from_ in Creator:
                        for i in gid:
                            h = cl.getGroup(i).name
		            if h == ng:
		                rl
		                cl.inviteIntoGroup(i,[Creator])
			        cl.sendText(msg.to,"Success Join To ["+ h +"] Group \n\n"+jam)
			    else:
			        pass
		    else:
		        cl.sendText(msg.to,"U are Not Admin")
		except Exception as e:
		    cl.sendText(msg.to, str(e))
 
	    elif "Leave grup: " in msg.text:
	        print "LEAVE DARI GRUP  "
		ng = msg.text.replace("Leave grup: ","")
		gid = cl.getGroupIdsJoined()
		if msg.from_ in Creator:
                    for i in gid:
                        h = cl.getGroup(i).name
		        if h == ng:
			    cl.sendText(i,"Bot Di Paksa Keluar Oleh Owner! \n\n"+jam)
		            cl.leaveGroup(i)
			    cl.sendText(msg.to,"Success Left ["+ h +"] group \n\n"+jam)
			else:
			    pass
		else:
		    cl.sendText(msg.to,"U are Not admin")
 
	    elif "KELUAR DARI GRUP" == msg.text:
	        print "KELUAR DARI SEMUA GRUP"
		gid = cl.getGroupIdsJoined()
                if msg.from_ in Creator:
		    for i in gid:
			cl.sendText(i,"вoт dι paĸѕa ĸelυar oleн owner !!\n\n"+jam)
		        cl.leaveGroup(i)
		        cl.leaveGroup(i)
		        cl.leaveGroup(i)
		        cl.leaveGroup(i)
		    cl.sendText(msg.to,"ѕυĸѕeѕ ĸelυar darι ѕeмυa rooм \n\n"+jam)
		else:
		    cl.sendText(msg.to,"υ 're noт owner\n\n"+jam)
		   

            elif "Pict grup: " in msg.text:
              if msg.from_ in admin:
                saya = msg.text.replace('Pict grup: ','')
                gid = cl.getGroupIdsJoined()
                for i in gid:
                    h = cl.getGroup(i).name
                    gna = cl.getGroup(i)
                    if h == saya:
                        cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+ gna.pictureStatus)
                        print "VIEW PICTURE GRUP"
    
            elif msg.text in ["Tolak"]:
              if msg.from_ in admin:
                    gid = cl.getGroupIdsInvited()
                    for i in gid:
                        cl.rejectGroupInvitation(i)
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"all ιnvιтaтιonѕ нave вeen rejecтed\n\n"+jam)
                    else:
                        cl.sendText(msg.to,"∂σηε")
                        print "MENOLAK UNDANGAN"

            elif msg.text in ["cancelall","Cancelall"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        cl.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        cl.sendText(msg.to,"тιdaĸ ada υndangan pendιng ! \n\n"+jam)
                else:
                    cl.sendText(msg.to,"тιdaĸ вιѕa   dι lυar     rooм! \n\n"+jam)
                    print "CANCEL ALL UNDANGAN"
 
            elif msg.text in ["Ourl","Url on"]:
              print "BUKA QR KODE"
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    cl.sendText(msg.to,"υrl ιѕ open" +"\n"+jam)
                else:
                    cl.sendText(msg.to,"can noт вe υѕed oυтѕιde тнe groυp\n\n"+jam)
 
            elif msg.text in ["Curl","Url off"]:
              print "TUTUP QR KODE"
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    cl.sendText(msg.to,"υrl ѕυdaн dι тυтυp !\n\n"+jam)
                else:
                    cl.sendText(msg.to,"can noт вe υѕed oυтѕιde тнe groυp\n\n"+jam)

            elif msg.text in ["Invite on"]:
                print "AUTO INVITE USERS ON"
                if msg.from_ in admin:
                    wait["ngundang"] = True
                    cl.sendText(msg.to,"aυтo   ιnvιтe  ση\n\n"+jam)
    #            else:
    #                cl.sendText(msg.to,"ѕυdaн мode on\n\n"+jam)
            elif msg.text in ["Invite off"]:
                print "AUTO INVITE USER OFF"
                if msg.from_ in admin:
                    wait["ngundang"] = False
                    cl.sendText(msg.to,"aυтo   ιnvιтe  oғғ\n\n"+jam)
    #            else:
    #                cl.sendText(msg.to,"ѕυdaн мode oғғ \n\n"+jam)

            elif msg.text in ["Join on","Auto join on"]:
                print "AUTO JOIN ON"
		if msg.from_ in admin:
                    wait["AutoJoin"] = True
                    wait["AutoJoinCancel"] = False
                    cl.sendText(msg.to,"aυтo joιn   aĸтιғ \n\n"+jam)
	#	else:
	#	    cl.sendText(msg.to,"ѕυdaн aĸтιғ \n\n"+jam)

            elif msg.text in ["Join off","Autojoin off"]:
                print "AUTO JOIN OFF"
		if msg.from_ in admin:
                    wait["AutoJoin"] = False
                    cl.sendText(msg.to,"aυтo joιn  non aĸтιғ\n\n"+jam)
	#	else:
	#	    cl.sendText(msg.to,"ѕυdaн мode nonaĸтιғ \n\n"+jam)
		    
		    
            elif msg.text in ["Join cancel on","Autojoincancel on"]:
                print "JOIN CANCEL ON"
		if msg.from_ in admin:
                    wait["AutoJoinCancel"] = True
                    wait["AutoJoin"] = False
                    cl.sendText(msg.to,"aυтo joιn cancel aĸтιғ\n\n"+jam)
	#	else:
	#	    cl.sendText(msg.to,"ѕυdaн aĸтιғ\n\n"+jam)

            elif msg.text in ["Join cancel off","Autojoincancel off"]:
                print "JOIN CANCEL OFF"
		if msg.from_ in admin:
                    wait["AutoJoinCancel"] = False
                    cl.sendText(msg.to,"aυтo joιn cancel nonaĸтιғ \n\n"+jam)
	#	else:
	#	    cl.sendText(msg.to,"ѕυdaн non aĸтιғ \n\n"+jam)

	    elif msg.text in ["Sticker on"]:
	      if msg.from_ in admin:
                wait["sticker"] = True
                cl.sendText(msg.to,"deтecт ιd  yoυr   ѕтιcĸer")
                print "STICKER CEK"

            elif msg.text in ["Bot off"]:
              if msg.from_ in admin:
                wait["Bot"] = False
                cl.sendText(msg.to,"вoт нaѕ вeen  ѕιlenт мode !")
                print "BOT OFF MODE"

            elif msg.text in ["Sticker off"]:
              if msg.from_ in admin:
                wait["sticker"] = False
                cl.sendText(msg.to,"ѕтιcĸer ιd deтecт dι nonaĸтιғĸan")
                print "STICKER DETECT OFFLINE"
                
            #elif msg.text in ["Bot on"]:
                #wait["Bot"] = True
                #cl.sendText(msg.to,"Bot Sudah Di Aktifkan")
                #print "BOT MODE ON"

            elif msg.text in ["Respon1 on"]:
                print "RESPON 1 MODE ON"
                if msg.from_ in admin:
                    wait["jones"] = True
                    wait["detectMention"] = False
                    wait["kickMension"] = False
                    wait["respone3"] = False
                    wait["responspam"] = False
                    wait["jones2"] = False
                    wait["sepamRes"] = False
                    wait["koynRes"] = False
                    cl.sendText(msg.to,"reѕpon1 cover ιмage aĸтιғ \n\n"+jam)
    #            else:
    #                cl.sendText(msg.to,"Sudah Aktif \n\n"+jam)

            elif msg.text in ["Respon1 off"]:
                print "RESPON 1 DI NONAKTIFKAN"
                if msg.from_ in admin:
                    wait["jones"] = False
                    cl.sendText(msg.to,"reѕpon 1 dι nonaĸтιғĸan \n\n"+jam)
        #        else:
        #            cl.sendText(msg.to,"ѕυdaн nonaĸтιғĸan \n\n"+jam)

            elif msg.text in ["Respon2 on"]:
                print "RESPON 2 DI AKTIFKAN"
                if msg.from_ in admin:
                    wait["koplok"] = True
                    wait["respone3"] = False
                    wait["jones"] = False                                                                           
                    wait["detectMention"] = False
                    wait["kickMension"] = False
                    wait["sepamRes"] = False
                    wait["jones2"] = False
                    wait["koynRes"] = False
                    cl.sendText(msg.to,"reѕpon 2 dι aĸтιғĸan \njangan мaen тag ya!\n\n"+jam)
        #        else:
        #            cl.sendText(msg.to,"ѕυdaн aĸтιғ \n\n"+jam)

            elif msg.text in ["Respon2 off"]:
                print "RESPON 2 DI OFF KAN"
                if msg.from_ in admin:
                    wait["koplok"] = False
                    cl.sendText(msg.to,"Respon 2 di nonaktifkan \n\n"+jam)
        #        else:                                                                                                           
        #            cl.sendText(msg.to,"ѕυdaн nOn aĸтιғ \n\n"+jam)

            elif msg.text in ["Respon on"]:
                print "RESPON DI AKTIFKAN"
                if msg.from_ in admin:
                    wait["detectMention"] = True
                    wait["kickMention"] = False
                    wait["jones"] = False
                    wait["koplok"] = False
                    wait["respone3"] = False
                    wait["sepamRes"] = False
                    wait["jones2"] = False
                    wait["koynRes"] = False
                    cl.sendText(msg.to,"aυтo reѕpon dι aĸтιғĸan\n\n"+jam)
        #        else:
        #            cl.sendText(msg.to,"мode aĸтιғ\n\n"+jam)

            elif msg.text in ["Respon off"]:
                print "RESPON DI NONAKTIFKAN"
                if msg.from_ in admin:
                    wait["detectMention"] = False
                    cl.sendText(msg.to,"aυтo reѕpon dι nOnaĸтιғĸan\n\n"+jam)
        #        else:
        #            cl.sendText(msg.to,"мode nonaĸтιғ\n\n"+jam)

            elif msg.text in ["Respon3 on"]:
                print "RESPON 3 DI AKTIFKAN"
                if msg.from_ in admin:
                    wait["respone3"] = True
                    wait["detectMention"] = False
                    wait["kickMention"] = False
                    wait["jones"] = False
                    wait["koplok"] = False
                    wait["sepamRes"] = False
                    wait["jones2"] = False
                    wait["koynRes"] = False
                    cl.sendText(msg.to,"reѕpon 3 dι aĸтιғĸan \n\n"+jam)
    #            else:
    #                cl.sendText(msg.to,"reѕpon 3 ѕυdaн aĸтιғ \n\n"+jam)

            elif msg.text in ["Respon3 off"]:
                print "RESPON 3 OFF"
                if msg.from_ in admin:
                    wait["respone3"] = False
                    wait["detectMention"] = False
                    cl.sendText(msg.to,"reѕpon 3 dι nonaĸтιғĸan \n\n"+jam)
        #        else:
        #            cl.sendText(msg.to,"reѕpon 3 ѕυdaн nonaĸтιғ\n\n"+jam)

            elif msg.text in ["Respon kick on"]:
                print "DANGER !!.....DANGER!!....RESPON KICK AKTIF"
		if msg.from_ in admin:
                    wait["kickMention"] = True  
                    wait["detectMention"] = False
                    wait["jones"] = False
                    wait["koplok"] = False
                    wait["respone3"] = False
                    wait["SepamRes"] = False
                    wait["jones2"] = False
                    wait["koynRes"] = False
                    cl.sendText(msg.to,"reѕpon kiCk ѕυdaн aĸтιғ\n\n"+jam)
	#	else:
	#	    cl.sendText(msg.to,"Mode on")

            elif msg.text in ["Respon kick off"]:
                print "RESPON KICK OFFLINE"
		if msg.from_ in admin:
                    wait["kickMention"] = False
                    cl.sendText(msg.to,"reѕpon kIck ѕυdaн Di nonaĸтιғkAn\n\n"+jam)
	#	else:
	#	    cl.sendText(msg.to,"Mode Off")

	    elif msg.text in ["All respon off"]:
	        print "SEMUA RESPON DI MATIKAN"
                if msg.from_ in admin:
                    wait["respone3"] = False
                    wait["detectMention"] = False
                    wait["kickMention"] = False
                    wait["jones"] = False
                    wait["koplok"] = False
                    wait["sepamRes"] = False
                    wait["jones2"] = False
                    wait["koynRes"] = False
                    cl.sendText(msg.to,"Semua reѕpon dι nonaĸтιғĸan \n\n"+jam)
        #        else:
        #            cl.sendText(msg.to,"All reѕpon ѕυdaн dI nonaĸтιғ\n\n"+jam)

            elif msg.text in ["Respon4 on"]:
                print "RESPON 4 AKTIF MODE"                                      
                if msg.from_ in admin:                                                                                
                    wait["sepamRes"] = True                                                                         
                    wait["detectMention"] = False                                                                    
                    wait["kickMention"] =False                                                                         
                    wait["jones"] = False
                    wait["koplok"] = False 
                    wait["respone3"] = False    
                    wait["jones2"] = False    
                    wait["koynRes"] = False                                                         
                    cl.sendText(msg.to,"reѕpon 4 dι aĸтιғĸan  \nTag = Auto spam\n\n"+jam)                                    
        #        else:                                                                                                 
        #            cl.sendText(msg.to,"reѕpon 4 ѕυdaн aĸтιғ\n\n"+jam)

            elif msg.text in ["Respon4 off"]: 
                print "RESPON 4 OFFLINE"                                                                             
                if msg.from_ in admin:
                    wait["sepamRes"] = False                                                                               
                    wait["respone3"] = True                                                                     
                    cl.sendText(msg.to,"reѕpon 4 dι nonaĸтιғĸan  ^_^\nAuto Respon3 di Aktifkan\n\n"+jam)
    
            elif msg.text in ["Respon5 on"]:
                print "RESPON 5 DI AKTIFKAN"                                                                      
                if msg.from_ in admin:
                    wait["jones2"] = True
                    wait["detectMention"] = False
                    wait["kickMention"] = False
                    wait["jones"] = False                                                                           
                    wait["koplok"] = False
                    wait["sepamRes"] = False
                    wait["respone3"] = False
                    wait["koynRes"] = False                                                                    
                    cl.sendText(msg.to,"reѕpon 5 dι aĸтιғĸan  \n\n"+jam)
        #        else:
        #            cl.sendText(msg.to,"reѕpon 5 suDah aĸтιғ \n\n"+jam)

            elif msg.text in ["Respon5 off"]:
                print "RESPON 5 OFFLINE"
                if msg.from_ in admin:
                    wait["jones2"] = False
                    wait["sepamRes"] = False
                    cl.sendText(msg.to,"reѕpon 5 dι nonaĸтιғĸan ^_^")

            elif msg.text in ["Respon6 on"]:
                print "RESPON 6 DI AKTIFKAN"                                                                    
                if msg.from_ in admin:
                    wait["koynRes"] = True
                    wait["respone3"] = False
                    wait["detectMention"] = False
                    wait["kickMention"] = False
                    wait["jones"] = False                                                                          
                    wait["koplok"] = False
                    wait["sepamRes"] = False
                    wait["jones2"] = False                                                                          
                    cl.sendText(msg.to,"reѕpon 6 dι aĸтιғĸan  \n\n"+jam)
        #        else:
        #            cl.sendText(msg.to,"reѕpon 6 ѕυdaн dI nonaĸтιғ\n\n"+jam)

            elif msg.text in ["Respon6 off"]:                                        
                print "RESPON 6 OFFLINE"
                if msg.from_ in admin:                                               
                    wait["koynRes"] = False                                                   
                    wait["respone3"] = False
                    cl.sendText(msg.to,"reѕpon 6 dι nonaĸтιғĸan ^_^")

	    elif msg.text in ["Auto cancel on"]:
	     print "AUTO CANCEL ON"
	     if msg.from_ in admin:	        
                wait["AutoCancel"] = True
                cl.sendText(msg.to,"aυтo cancel dι aĸтιғĸan \n\n"+jam)
		print wait["AutoCancel"]
	#     else:
	#	    cl.sendText(msg.to,"Mode On \n\n"+jam)

	    elif msg.text in ["Auto cancel off"]:
	     print "AUTO CANCEL OFFLINE"
	     if msg.from_ in admin:	        
                wait["AutoCancel"] = False
                cl.sendText(msg.to,"aυтo cancel dι nonaĸтιғĸan \n\n"+jam)
		print wait["AutoCancel"]
	#     else:
	#	    cl.sendText(msg.to,"Mode Off \n\n"+jam)
		    

	    elif msg.text in ["Invite pro on"]:
	     print "INVITE PROTECT MODE ON"
	     if msg.from_ in admin:	        
                wait["inviteprotect"] = True
                cl.sendText(msg.to,"ιnvιтe proтecт dι aĸтιғĸan \n\n"+jam)
		print wait["inviteprotect"]
	#     else:
	#	    cl.sendText(msg.to,"Mode on \n\n"+jam)

	    elif msg.text in ["Invite pro off"]:
	     print "INVITE PROTECT MODE OFFLINE"
	     if msg.from_ in admin:	        
                wait["inviteprotect"] = False
                cl.sendText(msg.to,"ιnvιтe proтecт dι nonaĸтιғĸan\n\n"+jam)
		print wait["inviteprotect"]
	#     else:
	#	    cl.sendText(msg.to,"Mode off \n\n"+jam)

	    elif "Qr on" in msg.text:
	     print "QR PROTECT ON....DANGER IS OPEN QR"
	     if msg.from_ in Creator:
	        wait["Qr"] = True
	    	cl.sendText(msg.to,"qr proтecт dι aĸтιғĸan\n\n"+jam)
	#     else:
	#	    cl.sendText(msg.to,"Mode On \n\n"+jam)

	    elif "Qr off" in msg.text:
	     print "QR PRO DI OFF KAN"
	     if msg.from_ in admin:	        
	    	wait["Qr"] = False
	    	cl.sendText(msg.to,"qr proтecт dι nonaĸтιғĸan\n\n"+jam)
	#     else:
	#	    cl.sendText(msg.to,"Mode Nonaktif \n\n"+jam)

                        

	    elif "Auto kick on" in msg.text:
	     print "AUTO KICK SEDANG AKTIF"
	     if msg.from_ in admin:	 	        
		     wait["AutoKick"] = True
		     cl.sendText(msg.to,"aυтo ĸιcĸ dι aĸтιғĸan\n\n"+jam)
	#     else:
	#        cl.sendText(msg.to,"Mode on \n\n"+jam)

	    elif "Autokick off" in msg.text:
	     print "AUTO KICK OFFLINE"
	     if msg.from_ in admin:	 	        
		     wait["AutoKick"] = False
		     cl.sendText(msg.to,"aυтo ĸιcĸ dι nonaĸтιғĸan\n\n"+jam)
	#     else:
	#        cl.sendText(msg.to,"Mode off \n\n"+jam)

	    elif "Ghost on" in msg.text:
	     print "GHOST ON BOS"
	     if msg.from_ in admin:	 	        
		     wait["Ghost"] = True
		     cl.sendText(msg.to,"Ghost Sudah Aktif \n\n"+jam)
	#     else:
	#        cl.sendText(msg.to,"Mode on \n\n"+jam)

	    elif "Ghost off" in msg.text:
	     print "GHOS MATE"
	     if msg.from_ in admin:	 	        
		     wait["Ghost"] = False
		     cl.sendText(msg.to,"Ghost Sudah Di Nonaktifkan \n\n"+jam)
	#     else:
	#         cl.sendText(msg.to,"Mode Nonaktifkan \n\n"+jam)

            elif msg.text in ["All protect on"]:
		if msg.from_ in admin:
                    wait["AutoCancel"] = True
                    wait["inviteprotect"] = True
                    wait["AutoKick"] = True
                    wait["Qr"] = True
                    wait["Ghost"] = True
                    wait["ngundang"] = True
                    cl.sendText(msg.to,"all proтecт dι aĸтιғĸan\n\n"+jam)
	##	else:
	#	    cl.sendText(msg.to,"Mode On")
		    print "ALL PROTECT ON !!   SAVETY MODE PAGAR BETON"

            elif msg.text in ["All protect off"]:
		if msg.from_ in admin:
                    wait["AutoCancel"] = False
                    wait["inviteprotect"] = False                    
                    wait["AutoKick"] = False
                    wait["Qr"] = False
                    wait["Ghost"] = False
                    wait["ngundang"] = False
                    cl.sendText(msg.to,"all proтecт dι nOnaĸтιғĸan\n\n"+jam)
	#	else:
	#	    cl.sendText(msg.to,"Mode Nonaktif\n\n"+jam)
		    print "ALL PROTECT OFFLINE"

            elif msg.text in ["Comment on","Comment:on"]:
              if msg.from_ in admin:
                wait["commentOn"] = True
                cl.sendText(msg.to,"coммenт lιĸe poѕт dι aĸтιғĸan")
                print "COMMENT DI ON"
    
            elif msg.text in ["Comment off","Comment:off"]:
                wait["commentOn"] = False
                cl.sendText(msg.to,"coммenт lιĸe poѕт dι nonaĸтιғĸan")
                print "COMMENT DI OFF"
    
            elif msg.text in ["K on","Contact on"]:
              if msg.from_ in admin:
                wait["Contact"] = True
                cl.sendText(msg.to,"ceĸ conтacт dι aĸтιғĸan")
                print "CEK MID KONTAK AKTIF"

            elif msg.text in ["K off","Contact off"]:
              if msg.from_ in admin:
                wait["Contact"] = False
                cl.sendText(msg.to,"ceĸ conтacт dι nonaĸтιғĸan")
                print "CEK MID KONTAK OFF"

            elif msg.text in ["Auto add on","Autoadd on"]:
              if msg.from_ in admin:
                wait["autoAdd"] = True
                cl.sendText(msg.to,"aυтo add ғrend on")
                print "ADD AUTO ON"

            elif msg.text in ["Auto add off","Autoadd off"]:
              if msg.from_ in admin:
                wait["autoAdd"] = False
                cl.sendText(msg.to,"aυтo add ғrend oFf")
                print "ADD AUTO OFF"
                
            elif msg.text in ["Always read on"]:
              if msg.from_ in admin:
                wait["alwaysRead"] = True
                cl.sendText(msg.to,"alwayѕ read on")
                print "ALLWAYS READ CHAT ON"

            elif msg.text in ["Always read off"]:
              if msg.from_ in admin:
                wait["alwaysRead"] = False
                cl.sendText(msg.to,"alwayѕ read oFf")
                print "READ CHAT MODE OFF"

            elif msg.text in ["Sambutan on","Sambutan:on","Welcome on","Welcome:on"]:
              print "WELCOME MESSAGE DI AKTIFKAN"
              if msg.from_ in admin:
                if wait["Sambutan"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"ωεℓcσмε мεssαgε ση\n\n"+jam)
                else:
                    wait["Sambutan"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Sudah Onヽ(´▽｀)/\n\n"+jam)

            elif msg.text in ["Sambutan off"]:
              print "WELCOME MSG OFFLINE"
              if msg.from_ in admin:
                if wait["Sambutan"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"ωεℓcσмε мεssαgε σFf\n\n"+jam)
                else:
                    wait["Sambutan"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Sudah Off (′︵‵。) \n\n"+jam)
                        
                        
            elif "Sider:on" in msg.text:
              print "CEK SIDER ROM AKTIF"
              if msg.from_ in admin:
                try:
                    del cctv['point'][msg.to]
                    del cctv['sidermem'][msg.to]
                    del cctv['cyduk'][msg.to]
                except:
                    pass
                cctv['point'][msg.to] = msg.id
                cctv['sidermem'][msg.to] = ""
                cctv['cyduk'][msg.to]=True
                wait["Sider"] = True
                cl.sendText(msg.to,"cнecĸ ѕιder dι aĸтιғĸan\n\n"+jam)

            elif "Sider:off" in msg.text:
              print "CEK SIDER ROM OFFLINE"
              if msg.from_ in admin:
                if msg.to in cctv['point']:
                    cctv['cyduk'][msg.to]=False
                    wait["Sider"] = False
                    cl.sendText(msg.to, "cнecĸ ѕιder dι nonaĸтιғĸan\n\n"+jam)
    #            else:
    #                cl.sendText(msg.to, "belum Aktif\n\n"+jam)

            elif msg.text in ["Invit gcreator"]:
                   print "GCREATOR DI INVITE"
                   if msg.from_ in admin:
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    try:
                       cl.findAndAddContactsByMid(gCreator)
                       cl.inviteIntoGroup(msg.to,[gCreator])
                       print "success inv gCreator"
                    except:
                       pass

            elif "Ganti dp" in msg.text:
                if msg.from_ in admin:
                    path = "pangeran.jpg"
                    cl.sendText(msg.to,"Setting update dp :")
                    cl.sendImage(msg.to,path)
                    cl.updateProfilePicture(path)
                    print"UPDATE DP"
    
            elif msg.text in ["Set","Status"]:
              if msg.from_ in admin:
                md = ""
		if wait["Sambutan"] == True: md+="・✔️ Sambutan : On\n"
		else:md+="・❌ Sambutan : Off\n"
		if wait["autoAdd"] == True: md+="・✔ ️Auto add : on \n"
		else: md +="・❌ Auto add off \n"
		if wait["AutoJoin"] == True: md+="・✔️ Auto Join : On\n"
                else: md +="・❌ Auto Join : Off\n"
                if wait["commentOn"] == True:md+="・✔ ️ Comment  : On\n"
                else: md+= "・❌ Comment : Off\n"
		if wait["AutoJoinCancel"] == True: md+="・✔️ Auto Join Cancel : On\n"
                else: md +="・❌ Auto Join Cancel : Off\n"                
		if wait["Contact"] == True: md+="・✔️ Info Contact : On\n"
		else: md+="・❌ Info Contact : Off\n"
                if wait["AutoCancel"] == True:md+="・✔️ Auto Cancel : On\n"
                else: md+= "・❌ Auto Cancel : Off\n"
                if wait["inviteprotect"] == True:md+="・✔️ Invite Protect : On\n"
                else: md+= "・❌ Invite Protect : Off\n"                
		if wait["Qr"] == True: md+="・✔️ Qr Protect : On\n"
		else:md+="・❌ Qr Protect : Off\n"
		if wait["AutoKick"] == True: md+="・✔️ Auto Kick : On\n"
		else:md+="・❌ Auto Kick : Off\n"
		if wait["Ghost"] == True: md+="・✔️ Ghost : On\n"
		else:md+="・❌ Ghost : Off\n"
		if wait["alwaysRead"] == True: md+="・✔️ Always Read : On\n"
		else:md+="・❌ Always Read: Off\n"
		if wait["detectMention"] == True: md+="・✔️ Respon : On\n"
		else:md+="・❌ Respon : Off\n"		
		if wait["kickMention"] == True: md+="・✔️ ResponKick : On\n"
		else:md+="・❌ ResponKick : Off\n"				
		if wait["Sider"] == True: md+="・✔️Sider : On\n"
		else:md+="・❌ Sider: Off\n"
		if wait["jones"] == True:md+="・✔ ️ Respon 1 :  On\n"                                           
		else: md+= "・❌ Respon 1 :  Off\n"
		if wait["koplok"] == True:md+="・✔ ️ Respon 2 : On\n"                                           
		else: md+= "・❌ Respon 2 : Off\n"
		if wait["respone3"] == True:md+="・✔ ️Respon 3 : On\n"
                else: md+= "・❌ Respon 3 : Off\n"
                if wait["sepamRes"] == True:md+="・✔  Respon 4 : On\n"
                else: md+= "・❌ Respon 4 : Off\n"
                if wait["jones2"] == True:md+="・✔  ️Respon 5 : On\n"
                else: md+= "・❌ Respon 5 : Off\n"
                if wait["koynRes"] == True:md+="・✔  ️Respon 6 : On\n"
                else: md+= "・❌ Respon 6 : Off\n"
		if wait["Simi"] == True: md+="・✔️ Simisimi : On\n"
		else:md+="・❌ Simisimi: Off\n"
		if wait["ngundang"] == True:md+="・✔   Automatis Invite On\n"
		else:md+="・❌ Automatis Invite Off\n"
                cl.sendText(msg.to,"════════════════\n      👿 ("+ cl.getProfile().displayName + ") 👿 \n════════════════\n"+md+"════════════════\n\n"+jam)
                print "🔘HELP STATUS CEK🔘"
    
            elif msg.text in ["Gift","gift"]:
              print "NG GIFF UY"
              if msg.from_ in admin:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '5'}
                msg.text = None
                cl.sendMessage(msg)
                
            elif "Gift1 " in msg.text:
              print "GIF 1 TAG"
              if msg.from_ in admin:
                       msg.contentType = 13
                       nk0 = msg.text.replace("Gift1 ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    cl.sendText(msg.to,_name + " Check Your Gift")
                                    msg.contentType = 9
                                    msg.contentMetadata= {'PRDTYPE': 'STICKER',
                                                         'STKVER': '1',
                                                         'MSGTPL': '1',
                                                         'STKPKGID': '1380280'}
                                    msg.to = target
                                    msg.text = None
                                    cl.sendMessage(msg)
                                except:
                                    msg.contentMetadata = {'mid': target}

            elif "Gift2 " in msg.text:
              print "GIF 2 TAG"
              if msg.from_ in admin:
                       msg.contentType = 13
                       nk0 = msg.text.replace("Gift2 ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    cl.sendText(msg.to,_name + " Check Your Gift")
                                    msg.contentType = 9
                                    msg.contentMetadata= {'PRDTYPE': 'STICKER',
                                                         'STKVER': '1',
                                                         'MSGTPL': '2',
                                                         'STKPKGID': '1360738'}
                                    msg.to = target
                                    msg.text = None
                                    cl.sendMessage(msg)
                                except:
                                    msg.contentMetadata = {'mid': target}

            elif "Gift3 " in msg.text:
              print "GIF 3 TAG"
              if msg.from_ in admin:
                       msg.contentType = 13
                       nk0 = msg.text.replace("Gift3 ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    cl.sendText(msg.to,_name + " Check Your Gift")
                                    msg.contentType = 9
                                    msg.contentMetadata= {'PRDTYPE': 'STICKER',
                                                         'STKVER': '1',
                                                         'MSGTPL': '3',
                                                         'STKPKGID': '1395389'}
                                    msg.to = target
                                    msg.text = None
                                    cl.sendMessage(msg)
                                except:
                                    msg.contentMetadata = {'mid': target}

            elif "Gift4 " in msg.text:
              print "GIF 4 TAG"
              if msg.from_ in admin:
                       msg.contentType = 13
                       nk0 = msg.text.replace("Gift4 ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    cl.sendText(msg.to,_name + " Check Your Gift")
                                    msg.contentType = 9
                                    msg.contentMetadata= {'PRDTYPE': 'STICKER',
                                                         'STKVER': '1',
                                                         'MSGTPL': '4',
                                                         'STKPKGID': '1329191'}
                                    msg.to = target
                                    msg.text = None
                                    cl.sendMessage(msg)
                                except:
                                    msg.contentMetadata = {'mid': target}

            elif "Gift5 " in msg.text:
                print "GIF 5 TAG"
                if msg.from_ in admin:
                       msg.contentType = 13
                       nk0 = msg.text.replace("Gift5 ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    cl.sendText(msg.to,_name + " Check Your Gift")
                                    msg.contentType = 9
                                    msg.contentMetadata= {'PRDTYPE': 'STICKER',
                                                         'STKVER': '1',
                                                         'MSGTPL': '1',
                                                         'STKPKGID': '9057'}
                                    msg.to = target
                                    msg.text = None
                                    cl.sendMessage(msg)
                                except:
                                    msg.contentMetadata = {'mid': target}

            elif "Gift6 " in msg.text:
              print "GIF 5 TAG"
              if msg.from_ in admin:
                       msg.contentType = 13
                       nk0 = msg.text.replace("Gift6 ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    cl.sendText(msg.to,_name + " Check Your Gift")
                                    msg.contentType = 9
                                    msg.contentMetadata= {'PRDTYPE': 'STICKER',
                                                         'STKVER': '1',
                                                         'MSGTPL': '2',
                                                         'STKPKGID': '9167'}
                                    msg.to = target
                                    msg.text = None
                                    cl.sendMessage(msg)
                                except:
                                    msg.contentMetadata = {'mid': target}

            elif "Spam tikel " in msg.text:
              print "SPAM TIKEL DI LUNCURKAN !!!"
              if msg.from_ in admin:
                       msg.contentType = 13
                       nk0 = msg.text.replace("Spam tikel ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    cl.sendText(msg.to,_name + " \nCheck gift tikel nya donk")
                                    msg.contentType = 7
                                    msg.contentMetadata={'STKID': '11',
                                                         'STKPKGID': '1',
                                                         'STKVER': '100'}
                                    msg.to = target
                                    msg.text = None
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)                                                                           
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)                                                                             
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                except:
                                    msg.contentMetadata = {'mid': target}
                                    print "SPAM TIKEL TERKIRIM.!! .KAPOK LU"

            elif "Spam kontak " in msg.text:
              print "SPAM KONTAK BY TAG"
              if msg.from_ in admin:
                       msg.contentType = 13
                       nk0 = msg.text.replace("Spam kontak ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    cl.sendText(msg.to,_name + " cek inbok ye...")
                                    msg.contentType = 13 
                                    msg.contentMetadata = {'mid': mid}
                                    msg.to = target
                                    msg.text = None
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)                                                                
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)                                                                
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)                                                                            
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)                                                                            
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                except:
                                    msg.contentMetadata = {'mid': target}

            elif "Spam gift " in msg.text:
              print "SPAM GIFT....WOW SERU NIH"
              if msg.from_ in admin:
                       msg.contentType = 13
                       nk0 = msg.text.replace("Spam gift ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    cl.sendText(msg.to,_name + " Check kiriman gift bro")
                                    msg.contentType = 9
                                    msg.contentMetadata= {'PRDTYPE': 'STICKER',
                                                         'STKVER': '1',
                                                         'MSGTPL': '3',
                                                         'STKPKGID': '7334'}
                                    msg.to = target
                                    msg.text = None
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)                                                               
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)                                                                             
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)                                                                       
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                except:
                                    msg.contentMetadata = {'mid': target}
                                    print "SPAM GIFT SUKSES  !!! USIL BGT YA"

            elif "Spam eror " in msg.text:
                print "SPAM EROR CRASH VIA INBOX"
                if msg.from_ in admin:
                       msg.contentType = 13
                       nk0 = msg.text.replace("Spam eror ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"user does not exist")
                           pass
                       else:
                           for target in targets:
                                try:
                                    cl.sendText(msg.to,_name + " Cek Pm mesra beb")
                                    msg.contentType = 13
                                    msg.contentMetadata = {'mid': "NADYA,'"}
                                    msg.to = target
                                    msg.text = None
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)                                                                               
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                    cl.sendMessage(msg)
                                except:
                                    msg.contentMetadata = {'mid': target}
                                    print "RAJA USIL...MAENNYA CRASH"


            elif msg.text.lower() in ["wkwkwk","wkwk","hahaha","haha","ahaha"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '27097133',
                                    'STKPKGID': '1876451',
                                    'STKVER': '22'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["hehehe","hehe"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '15741531',
                                    'STKPKGID': '1407957',
                                    'STKVER': '2'}
                msg.text = None
                cl.sendMessage(msg)





            elif msg.text.lower() in ["galau"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '15741535',
                                    'STKPKGID': '1407957',
                                    'STKVER': '6'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["you","kau","kamu"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '7',
                                    'STKPKGID': '1',
                                    'STKVER': '100'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["marah","hadeuh","hadeh"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '24200510',
                                    'STKPKGID': '1759910',
                                    'STKVER': '15'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["please","pliss","mohon","tolong"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '24200511',
                                    'STKPKGID': '1759910',
                                    'STKVER': '16'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["sue"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '15271372',
                                    'STKPKGID': '1392635',
                                    'STKVER': '1'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["lucu","ngakak","lol"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '27097133',
                                    'STKPKGID': '1876451',
                                    'STKVER': '22'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["salam"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '15669530',
                                    'STKPKGID': '1405607',
                                    'STKVER': '1'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["hmm"]:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '27097118',
                                    'STKPKGID': '1876451',
                                    'STKVER': '7'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["bingung"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '20412836',
                                    'STKPKGID': '1601853',
                                    'STKVER': '13'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["cantik","imut"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '5',
                                    'STKPKGID': '1',
                                    'STKVER': '100'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["nyanyi","lalala"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '11',
                                    'STKPKGID': '1',
                                    'STKVER': '100'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["hah"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '27097114',
                                    'STKPKGID': '1876451',
                                    'STKVER': '18'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["ok","oke","okay","oce","okee","sip","siph"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '24200509',
                                    'STKPKGID': '1759910',
                                    'STKVER': '14'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["mantab","mantap","nice","keren"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '14',
                                    'STKPKGID': '1',
                                    'STKVER': '100'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["hihi"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '15741531',
                                    'STKPKGID': '1407957',
                                    'STKVER': '2'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["nangis","sedih"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '15741535',
                                    'STKPKGID': '1407957',
                                    'STKVER': '6'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["wasalam"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '15669531',
                                    'STKPKGID': '1405607',
                                    'STKVER': '2'}
                msg.text = None
                cl.sendMessage(msg)

            elif msg.text.lower() in ["pulang"]:
              if msg.from_ in admin:
                msg.contentType = 7
                msg.contentMetadata={'STKID': '15741533',
                                    'STKPKGID': '1407957',
                                    'STKVER': '4'}
                msg.text = None
                cl.sendMessage(msg)

            elif "Aye" == msg.text.lower():
              if msg.from_ in admin:
                group = cl.getGroup(msg.to)
                nama = [contact.mid for contact in group.members]
                nm1, nm2, nm3, nm4, nm5, jml = [], [], [], [], [], len(nama)
                if jml <= 100:
                    cl.mention(msg.to, nama)
                    if jml > 100 and jml < 200:
                        for i in range(0, 100):
                            nm1 += [nama[i]]
                    cl.mention(msg.to, nm1)
                    for j in range(101, len(nama)):
                        nm2 += [nama[j]]
                    cl.mention(msg.to, nm2)
                if jml > 200 and jml < 300:
                    for i in range(0, 100):
                        nm1 += [nama[i]]
                    cl.mention(msg.to, nm1)
                    for j in range(101, 200):
                        nm2 += [nama[j]]
                    cl.mention(msg.to, nm2)
                    for k in range(201, len(nama)):
                        nm3 += [nama[k]]
                    cl.mention(msg.to, nm3)
                if jml > 300 and jml < 400:
                    for i in range(0, 100):
                        nm1 += [nama[i]]
                    cl.mention(msg.to, nm1)
                    for j in range(101, 200):
                        nm2 += [nama[j]]
                    cl.mention(msg.to, nm2)
                    for k in range(201, 300):
                        nm3 += [nama[k]]
                    cl.mention(msg.to, nm3)
                    for l in range(301, len(nama)):
                        nm4 += [nama[l]]
                    cl.mention(msg.to, nm4)
                if jml > 400 and jml < 500:
                    for i in range(0, 100):
                        nm1 += [nama[i]]
                    cl.mention(msg.to, nm1)
                    for j in range(101, 200):
                        nm2 += [nama[j]]
                    cl.mention(msg.to, nm2)
                    for k in range(201, 300):
                        nm3 += [nama[k]]
                    mention(msg.to, nm3)
                    for l in range(301, 400):
                        nm4 += [nama[l]]
                    mention(msg.to, nm4)
                    for h in range(401, len(nama)):
                        nm5 += [nama[h]]
                    mention(msg.to, nm5)
                if jml > 500:
                    cl.sendText(msg.to,'Member melebihi batas.')
                    cnt = Message()
                    cnt.text = "Done : " + str(jml) +  " Members"
                    cnt.to = msg.to
                    #msg.contentType = 0
                    #msg.text = cnt
                    #msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cnt+']}','EMTVER':'4'}
                    cl.sendMessage(cnt)
                    print "SENGGOL TAG"
            elif "haloo" == msg.text.lower():
              if msg.from_ in admin:
                 group = cl.getGroup(msg.to)
                 nama = [contact.mid for contact in group.members]
                 nm1, nm2, nm3, nm4, nm5, jml = [], [], [], [], [], len(nama)
                 if jml <= 100:
                    summon(msg.to, nama)
                 if jml > 100 and jml < 200:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, len(nama)-1):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                 if jml > 200 and jml < 300:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, 199):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                    for k in range(200, len(nama)-1):
                        nm3 += [nama[k]]
                    summon(msg.to, nm3)
                 if jml > 300  and jml < 400:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, 199):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                    for k in range(200, 299):
                        nm3 += [nama[k]]
                    summon(msg.to, nm3)
                    for l in range(300, len(nama)-1):
                        nm4 += [nama[l]]
                    summon(msg.to, nm4)
                 if jml > 400  and jml < 500:
                    for i in range(0, 99):
                        nm1 += [nama[i]]
                    summon(msg.to, nm1)
                    for j in range(100, 199):
                        nm2 += [nama[j]]
                    summon(msg.to, nm2)
                    for k in range(200, 299):
                        nm3 += [nama[k]]
                    summon(msg.to, nm3)
                    for l in range(300, 399):
                        nm4 += [nama[l]]
                    summon(msg.to, nm4)
                    for m in range(400, len(nama)-1):
                        nm5 += [nama[m]]
                    summon(msg.to, nm5)
                 if jml > 500:
                     print "Terlalu Banyak Men 500+"
                 cnt = Message()
                 cnt.text = "Jumlah:\n" + str(jml) +  " Members"
                 cnt.to = msg.to
                 cl.sendMessage(cnt)
                 print "TAG VIA EHM"

            elif msg.text in ["Tagall","Tag all","Ngtag","Cium","Cipok"]:
              print "TAG ALL DULU BRO"
              if msg.from_ in admin:
                  group = cl.getGroup(msg.to)
                  nama = [contact.mid for contact in group.members]

                  cb = ""
                  cb2 = ""
                  strt = int(0)
                  akh = int(0)
                  for md in nama:
                      akh = akh + int(6)

                      cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""

                      strt = strt + int(7)
                      akh = akh + 1
                      cb2 += "@nrik \n"

                  cb = (cb[:int(len(cb)-1)])
                  msg.contentType = 0
                  msg.text = cb2
                  msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}

                  try:
                      cl.sendMessage(msg)
                  except Exception as error:
                      print error

            elif "Kiss" in msg.text:
              print "TAG VIA KISS"
              if msg.from_ in admin:
                group = cl.getGroup(msg.to)
                k = len(group.members)//500
                for j in xrange(k+1):
                    msg = Message(to=msg.to)
                    txt = u''
                    s=0
                    d=[]
                    for i in group.members[j*500 : (j+1)*500]:
                        d.append({"S":str(s), "E" :str(s+8), "M":i.mid})
                        s += 9
                        txt += u'@Krampus\n'
                    msg.text = txt
                    msg.contentMetadata = {u'MENTION':json.dumps({"MENTIONEES":d})}
                    cl.sendMessage(msg)

            elif msg.text in ["Cek","cek","Point"]:
              if msg.from_ in admin:
                subprocess.Popen("echo '' > dataSeen/"+msg.to+".txt", shell=True, stdout=subprocess.PIPE)
                cl.sendText(msg.to, "Checkpoint....")
                print "SET VIEW SIDER"

            elif msg.text in ["Tes","Cctv","tes"]:
              if msg.from_ in admin:
	        lurkGroup = ""
	        dataResult, timeSeen, contacts, userList, timelist, recheckData = [], [], [], [], [], []
                with open('dataSeen/'+msg.to+'.txt','r') as rr:
                    contactArr = rr.readlines()
                    for v in xrange(len(contactArr) -1,0,-1):
                        num = re.sub(r'\n', "", contactArr[v])
                        contacts.append(num)
                        pass
                    contacts = list(set(contacts))
                    for z in range(len(contacts)):
                        arg = contacts[z].split('|')
                        userList.append(arg[0])
                        timelist.append(arg[1])
                    uL = list(set(userList))
                    for ll in range(len(uL)):
                        try:
                            getIndexUser = userList.index(uL[ll])
                            timeSeen.append(time.strftime("%H:%M:%S", time.localtime(int(timelist[getIndexUser]) / 1000)))
                            recheckData.append(userList[getIndexUser])
                        except IndexError:
                            conName.append('nones')
                            pass
                    contactId = cl.getContacts(recheckData)
                    for v in range(len(recheckData)):
                        dataResult.append(contactId[v].displayName + ' ('+timeSeen[v]+')')
                        pass
                    if len(dataResult) > 0:
                        tukang = "      👿 SIDER LIST 👿\n・"
                        grp = '\n・'.join(str(f) for f in dataResult)
                        total = '\n・These %i  ueser (%s)' % (len(dataResult), datetime.now().strftime('%H:%M:%S'))
                        cl.sendText(msg.to, "%s %s %s" % (tukang, grp, total))
                        subprocess.Popen("echo '' > dataSeen/"+msg.to+".txt", shell=True, stdout=subprocess.PIPE)
                        #cl.sendText(msg.to, "☆Auto Checkpoint☆")                        
                    else:
                        clsendText(msg.to, "Belum bisa di tampilkan ^_^")
                    print "LIST CCTV ABSEN"


	    elif "Tendang " in msg.text:
	        print "KICK PAKE TENDANG (SUE NIH MAEN KICK)"
		if msg.from_ in admin:	        
		    if 'MENTION' in msg.contentMetadata.keys()!= None:
		        names = re.findall(r'@(\w+)', msg.text)
		        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
		        mentionees = mention['MENTIONEES']
		        print mentionees
		        for mention in mentionees:
			    cl.kickoutFromGroup(msg.to,[mention['M']])

	    elif "Set member: " in msg.text:
	        print "SET MEMBER"
		if msg.from_ in admin:	 	        
		    jml = msg.text.replace("Set member: ","")
		    wait["Members"] = int(jml)
		    cl.sendText(msg.to, "Jumlah minimal member telah di set : "+jml)

	    elif "Add all" in msg.text:
	      print "ADD SEMUA NYA!!"
	      if msg.from_ in admin:
		    thisgroup = cl.getGroups([msg.to])
		    Mids = [contact.mid for contact in thisgroup[0].members]
		    mi_d = Mids[:33]
		    cl.findAndAddContactsByMids(mi_d)
		    cl.sendText(msg.to,"Success Add all")


            elif msg.text in ["Invite"]:
              if msg.from_ in admin:
                wait["invite"] = True
                cl.sendText(msg.to,"Send Contact")
                print "INVITE USER VIA CONTACT"
                
                

            elif msg.text in ["Auto like"]:
              if msg.from_ in admin:
                wait["likeOn"] = True
                cl.sendText(msg.to,"Shere Post Kamu Yang Mau Di Like!")       
                print "AUTO LIKE POST"         


            elif msg.text in ["Steal contact"]:
              if msg.from_ in admin:
                wait["steal"] = True
                cl.sendText(msg.to,"Send Contact")
                print "STEAL CONTACT"
                

            elif msg.text in ["Gift contact"]:
              if msg.from_ in admin:
                wait["gift"] = True
                cl.sendText(msg.to,"Send Contact")
                print "NYPAM GIFT VIA KONTAK"

            elif msg.text in ["Spam1 contact"]:
              if msg.from_ in admin:
                wait["spam1"] = True
                cl.sendText(msg.to,"Send Contact")
                print "MELUNCURKAN SPAM 1 VIA KONTAK"
                
            elif msg.text in ["Spam2 contact"]:
              print "MELUNCURKAN SPAM2 VIA KONTAK"
              if msg.from_ in admin:
                wait["spam2"] = True
                cl.sendText(msg.to,"Send Contact")

	    elif "Spam Gc" in msg.text:
	      print "SPAM GC !!!!! AU TUH SUKSES KAGA"
	      if msg.from_ in admin:
		thisgroup = cl.getGroups([msg.to])
		Mids = [contact.mid for contact in thisgroup[0].members]
		mi_d = Mids[:33]
		cl.createGroup(str(pesan["spamr"]), mi_d)
		cl.leaveGroup(i)
		cl.createGroup(str(pesan["spamr"]), mi_d)
		cl.leaveGroup(i)
		cl.createGroup(str(pesan["spamr"]), mi_d)
		cl.leaveGroup(i)
		cl.createGroup(str(pesan["spamr"]), mi_d)
		cl.leaveGroup(i)
		cl.createGroup(str(pesan["spamr"]), mi_d)
		cl.leaveGroup(i)
		cl.createGroup(str(pesan["spamr"]), mi_d)
		cl.leaveGroup(i)
		cl.createGroup(str(pesan["spamr"]), mi_d)
		cl.leaveGroup(i)
		cl.createGroup(str(pesan["spamr"]), mi_d)
		cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)#20
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)#50
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)#60
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
                cl.createGroup(str(pesan["spamr"]), mi_d)
                cl.leaveGroup(i)
		cl.sendText(msg.to,"Success invite member to group")
		print "SPAM GC,EROR"



            elif ("Gn " in msg.text):
              print "GANTI NAMA ROOM"
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.name = msg.text.replace("Gn ","")
                    cl.updateGroup(X)
                else:
                    cl.sendText(msg.to,"It can't be used besides the group.")

            elif "Kick: " in msg.text:
              print "NG KICK PAKE MID"
              if msg.from_ in admin:
                midd = msg.text.replace("Kick: ","")
		if midd not in admin:
		    cl.kickoutFromGroup(msg.to,[midd])
		else:
		    cl.sendText(msg.to,"Admin Detected")

            elif "Invite: " in msg.text:
              print "INVITE PAKE MID"
              if msg.from_ in admin:
                midd = msg.text.replace("Invite: ","")
                cl.findAndAddContactsByMid(midd)
                cl.inviteIntoGroup(msg.to,[midd])

            elif "Invite creator" in msg.text:
              if msg.from_ in admin:
                midd = "ufb484c768b5da9de91722b2cf5a19cd3"
                cl.inviteIntoGroup(msg.to,[midd])
                print "INVIT CREATOR"

            elif "Siri masuk" in msg.text:
              if msg.from_ in admin:
                midd = "u858d6fb9c80b8444097d05c7ec23803b"
                cl.inviteIntoGroup(msg.to,[midd])
                print "SIRIV10 KANG SUKRI MASUK"

            elif "Invite sukri" in msg.text:
              if msg.from_ in admin:
                midd = "ufb484c768b5da9de91722b2cf5a19cd3"
                cl.inviteIntoGroup(msg.to,[midd])
                print "INVT SUKRI"
            elif msg.text in ["Welcome","welcome","Welkam","welkam","Wc","wc"]:
              print "WELCOM STIKER"
              if msg.from_ in admin:
                gs = cl.getGroup(msg.to)
                cl.sendText(msg.to,"Selamat Datang Di "+ gs.name)
                msg.contentType = 7
                msg.contentMetadata={'STKID': '247',
                                    'STKPKGID': '3',
                                    'STKVER': '100'}
                msg.text = None
                cl.sendMessage(msg)

	    elif "Bc: " in msg.text:
	      print "---------------BROADCASTING"
	      if msg.from_ in admin:
		bc = msg.text.replace("Bc: ","")
		gid = cl.getGroupIdsJoined()
		if msg.from_ in Creator:
		    for i in gid:
			cl.sendText(msg.to,"=======[BROADCAST]=======\n\n"+bc+"\n\nContact Me : line.me/ti/p/~anto_sahaja\n             line.me/ti/p/~anto_sahaja0\n             line.me/ti/p/~anto_sahaja1")
		    cl.sendText(msg.to,"Success BC Bos")
		else:
		    cl.sendText(msg.to,"Sukses Bos")

            elif msg.text in ["Cancel"]:
              print "NGAN CEL UNDANGAN"
              if msg.from_ in admin:
                gid = cl.getGroupIdsInvited()
                for i in gid:
                    cl.rejectGroupInvitation(i)
                cl.sendText(msg.to,"All invitations have been refused")

            elif msg.text in ["Gurl"]:
              print "BUKA QR & KIRIM LINK ROOM"
              if msg.from_ in admin:
                if msg.toType == 2:
                    x = cl.getGroup(msg.to)
                    if x.preventJoinByTicket == True:
                        x.preventJoinByTicket = False
                        cl.updateGroup(x)
                    gurl = cl.reissueGroupTicket(msg.to)
                    cl.sendText(msg.to,"line://ti/g/" + gurl)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can't be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")


            elif msg.text in ["timeline"]:
              if msg.from_ in admin:
		try:
                    url = cl.activity(limit=5)
		    cl.sendText(msg.to,url['result']['posts'][0]['postInfo']['postId'])
		except Exception as E:
		    print E

            elif msg.text in ["Aim left","aim left","Aim out"]:
                if msg.from_ in admin:
                    cl.sendText(msg.to,"Pamit All....See u next Time")
		    cl.leaveGroup(msg.to)		    
		    print "AIM LEFT DARI ROOM"
		    

            elif msg.text in ["Absen"]:
              if msg.from_ in admin:
		cl.sendText(msg.to,"Hadir!!")
		print "ABSEN"


            elif msg.text.lower() in ["respon"]:
              if msg.from_ in admin:
                cl.sendText(msg.to,"Nama ku " + name1)
                ki.sendText(msg.to,"Nama ku " + name2)
                kk.sendText(msg.to,"Nama ku " + name3)
                kc.sendText(msg.to,"Nama ku " + name4)
                ks.sendText(msg.to,"Nama ku " + name5)
                ka.sendText(msg.to,"Nama ku " + name6)
                print "RESPON NAMA"

            elif msg.text in ["SpeedX"]:
              if msg.from_ in admin:
                start = time.time()
                print("SpeedX")
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "Progress...")
                cl.sendText(msg.to, "%sseconds" % (elapsed_time))

            elif msg.text in ["debug speed","Debug speed"]:
              if msg.from_ in admin:
                cl.sendText(msg.to, "Measuring...")                                                                         
                start = time.time()
                time.sleep(0.0001)
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "%sseconds" % (elapsed_time))
                print "SPEED PALSU UYY..."

            elif msg.text in ["Speed","Sp","sp","Speed test"]:
              print "TEST SPEED !!"
              if msg.from_ in admin:
                start = ["0.000458955764771seconds","0.000328155754770seconds","0.000628955764634seconds","0.001148943764619seconds","0.001724955763801seconds"]
                spfx= random.choice(start)
                cl.sendText(msg.to, "Progress...")
                cl.sendText(msg.to, spfx)
            elif msg.text in ["Speed testerr"]:
              if msg.from_ in admin:
                start = time.time()
                cl.sendText(msg.to, "Progress...")
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "%sseconds" % (elapsed_time))
 
            elif msg.text in ["Ban"]:
                if msg.from_ in admin:
                    wait["wblacklist"] = True
                    cl.sendText(msg.to,"send contact")

            elif msg.text in ["Unban"]:
                if msg.from_ in admin:
                    wait["dblacklist"] = True
                    cl.sendText(msg.to,"send contact")
 
            #elif "Ban @" in msg.text:
                #if msg.from_ in admin:
                  #if msg.toType == 2:
                    #print "@Ban by mention"
                    #_name = msg.text.replace("Ban @","")
                    #_nametarget = _name.rstrip('  ')
                    #gs = cl.getGroup(msg.to)
                    #targets = []
                    #for g in gs.members:
                        #if _nametarget == g.displayName:
                            #targets.append(g.mid)
                    #if targets == []:
                        #cl.sendText(msg.to,"Not found")
                    #else:
                        #for target in targets:
			    #if target not in admin:
                                #try:
                                    #wait["blacklist"][target] = True
                                    #f=codecs.open('st2__b.json','w','utf-8')
                                    #json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                    #cl.sendText(msg.to,"Succes BosQ")
                                #except:
                                    #cl.sendText(msg.to,"Error")
			    #else:
				#cl.sendText(msg.to,"Admin Detected~")
 
            elif msg.text in ["Banlist","Ban list"]:
              if msg.from_ in admin:
                if wait["blacklist"] == {}:
                    cl.sendText(msg.to,"Tidak Ada")
                else:
                    mc = ""
                    for mi_d in wait["blacklist"]:
                        mc += "->" +cl.getContact(mi_d).displayName + "\n"
                    cl.sendText(msg.to," 🔘 BanNeD lisT 🔘\n"+mc)
                    print "Ban list"

 
            elif "Unban @" in msg.text:
                if msg.toType == 2:
                    print "UN BANNED VIA TAG"
                if msg.from_ in admin:
                    _name = msg.text.replace("Unban @","")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                del wait["blacklist"][target]
                                f=codecs.open('st2__b.json','w','utf-8')
                                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendText(msg.to,"Succes BosQ")
                            except:
                                cl.sendText(msg.to,"Succes BosQ")
                                
                                
            elif msg.text.lower() == 'clear ban':
                print "CLEAR BANNED !!"
                if msg.from_ in admin:
                    wait["blacklist"] = {}
                    cl.sendText(msg.to,"Unbanned All Success bos") 

            elif msg.text.lower() in ["Sukri","sukrii","Sukrii","Sukri.."]:
                cl.sendText(msg.to,"Apa Manggil~Manggil Aku!?")

 
            #elif msg.text in ["Kill ban"]:
		#if msg.from_ in admin:
                    #if msg.toType == 2:
                        #group = cl.getGroup(msg.to)
                        #gMembMids = [contact.mid for contact in group.members]
                        #matched_list = []
                        #for tag in wait["blacklist"]:
                            #matched_list+=filter(lambda str: str == tag, gMembMids)
                        #if matched_list == []:
                            #cl.sendText(msg.to,"There was no blacklist user")
                            #return
                        #for jj in matched_list:
                            #cl.kickoutFromGroup(msg.to,[jj])
                        #cl.sendText(msg.to,"Blacklist emang pantas tuk di usir")
		#else:
		    #cl.sendText(msg.to, "Khusus creator")
 
            elif msg.text in ["Hajar"]:
                    print "KICK BANNED VIA HAJAR"
                    if msg.toType == 2:
                      if msg.from_ in admin:
                        group = cl.getGroup(msg.to)
                        gMembMids = [contact.mid for contact in group.members]
                        matched_list = []
                        for tag in wait["blacklist"]:
                            matched_list+=filter(lambda str: str == tag, gMembMids)
                        if matched_list == []:
                            cl.sendText(msg.to,"Maaf")
                            return
                        for jj in matched_list:
                            try:
                                cl.kickoutFromGroup(msg.to,[jj])
                                print (msg.to,[jj])
                            except:
                                pass

 
            elif "Tendang all" == msg.text:
                    print "DANGER ...DANGER ....!! TENDANG ALL MELUNCUR"
		    if msg.from_ in admin:
                     if msg.toType == 2:
                        print "Kick all member"
                        _name = msg.text.replace("Tendang all","")
                        gs = cl.getGroup(msg.to)
                        cl.sendText(msg.to,"Dadaaah~")
                        targets = []
                        for g in gs.members:
                            if _name in g.displayName:
                                targets.append(g.mid)
                        if targets == []:
                            cl.sendText(msg.to,"Not found.")
                        else:
                            for target in targets:
				if target not in admin:
                                    try:
                                        random.choice(KAC).kickoutFromGroup(msg.to,[target])
                                        print (msg.to,[g.mid])
                                    except Exception as e:
                                        cl.sendText(msg.to,str(e))
			    #cl.inviteIntoGroup(msg.to, targets)
 

	    elif msg.text in ["Restart","Reset","Booting"]:
	        print "RESTART PROGRAM"
		if msg.from_ in admin:
		    cl.sendText(msg.to, "Restart ulang..")
		    restart_program()
		    print "@Restart"
		else:
		    cl.sendText(msg.to, "No Access")
		    
            elif msg.text in ["Power off"]:
                print "POWER OFF AKUN"
	        if msg.from_ in admin:
                 try:
                     import sys
                     sys.exit()
                 except:
                     pass 		    


            elif '#EROR' in msg.text:
              if msg.from_ in admin:
                msg.contentType = 13
                msg.contentMetadata = {'mid': "NADYA,'"}
                cl.sendMessage(msg)
                print "CRASH.....ROOM"

            elif "Jadi " in msg.text:
              print "COPY,PROFILE"
              if msg.from_ in admin:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                    try:
                        contact = cl.getContact(target)
                        X = contact.displayName
                        profile = cl.getProfile()
                        profile.displayName = X
                        cl.updateProfile(profile)
                        cl.sendText(msg.to, "Success...")
                        #---------------------------------------
                        Y = contact.statusMessage
                        lol = cl.getProfile()
                        lol.statusMessage = Y
                        cl.updateProfile(lol)
                        #---------------------------------------
                        P = contact.pictureStatus
                        cl.updateDisplayPicture(P)
                    except Exception as e:
                        cl.sendText(msg.to, "Failed!")
                        print e

            elif "Mirip @" in msg.text:
              print "MIRIP VIA TAG"
              if msg.from_ in admin:
                   print "[COPY] Ok"
                   _name = msg.text.replace("Mirip @","")
                   _nametarget = _name.rstrip('  ')
                   gs = cl.getGroup(msg.to)
                   targets = []
                   for g in gs.members:
                       if _nametarget == g.displayName:
                           targets.append(g.mid)
                   if targets == []:
                       cl.sendText(msg.to, "Tidak bisa mirip.")
                   else:
                       for target in targets:
                            try:
                               cl.CloneContactProfile(target)
                               cl.sendText(msg.to, "Mirip profile artist.. (^_^)")
                            except Exception as e:
                                print e

            elif msg.text in ["Cancel","cancel"]:
              print "NG,CANCEL"
              if msg.from_ in admin:
                if msg.toType == 2:                                                                                                         
                    X = cl.getGroup(msg.to)                                                                                                 
                    if X.invitee is not None:                                                                                                   
                        gInviMids = [contact.mid for contact in X.invitee]
                        cl.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"No one is inviting")
                        else:
                            cl.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")

            elif msg.text in ["Start backup"]:
                print "START BACKUP"
                if msg.from_ in admin:
                    wek = cl.getContact(mid)
                    a = wek.pictureStatus
                    r = wek.displayName
                    i = wek.statusMessage
                    s = open('mydn.txt',"w")
                    s.write(r)
                    s.close()
                    t = open('mysm.txt',"w")
                    t.write(i)
                    t.close()
                    u = open('myps.txt',"w")
                    u.write(a)
                    u.close()
                    cl.sendText(msg.to, "Backup has been active")
                    print wek
                    print a
                    print r
                    print i

            elif "Mybackup" in msg.text:
                print "MY BACKUP"
                if msg.from_ in admin:                                                                                                                         
                        try:
                            h = open('mydn.txt',"r")
                            name = h.read()
                            h.close()
                            x = name
                            profile = cl.getProfile()
                            profile.displayName = x
                            cl.updateProfile(profile)
                            i = open('mysm.txt',"r")
                            sm = i.read()
                            i.close()
                            y = sm
                            wek = cl.getProfile()
                            wek.statusMessage = y
                            cl.updateProfile(wek)
                            j = open('myps.txt',"r")
                            ps = j.read()
                            j.close()
                            p = ps
                            cl.updateDisplayPicture(p)
                            cl.sendText(msg.to, "Succes  boss")
                        except Exception as e:
                            cl.sendText(msg.to,"Gagal! bro")
                            print e

            elif msg.text in ["Setbackup","Back","Backup","back"]:
              if msg.from_ in admin:
                try:
                    cl.updateDisplayPicture(backup1.pictureStatus)
                    cl.updateProfile(backup1)
                    cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + backup1.pictureStatus)
                except Exception as e:
                    cl.sendText(msg.to, str(e))
                    print "BACK TO PROFILE SENDIRI"

 
	    elif "Musik " in msg.text:
	      if msg.from_ in admin:
	            songname = msg.text.replace("Musik ","")
		    params = {"songname": songname}
		    r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
		    data = r.text
		    data = json.loads(data)
		    for song in data:
		         abc = song[3].replace('https://','http://')
			 cl.sendText(msg.to, "Title : " + song[0] + "\nLength : " + song[1] + "\nLink download : " + song[4])
			 cl.sendText(msg.to, "Lagu " + song[0] + "\nSedang Di Prosses... Tunggu Sebentar ^_^ ")
			 cl.sendAudioWithURL(msg.to,abc)
			 cl.sendText(msg.to, "Selamat Mendengarkan Lagu " + song[0])
			 print "PENCARIAN MUSIK"
	
            elif 'Lirik ' in msg.text.lower():
              if msg.from_ in admin:
                try:
                    songname = msg.text.lower().replace('Lirik ','')
                    params = {'songname': songname}
                    r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                    data = r.text
                    data = json.loads(data)
                    for song in data:
                        hasil = 'Lyric Lagu ('
                        hasil += song[0]
                        hasil += ')\n\n'
                        hasil += song[5]
                        cl.sendText(msg.to, hasil)
                except Exception as wak:
                        cl.sendText(msg.to, str(wak))
                        print "PENCARIAN LIRIK"
                        
	    elif "Musrik " in msg.text:
	                 print "PENCARIAN MUSIK (Musrik)"
	                 if msg.from_ in admin:
					songname = msg.text.replace("Musrik ","")
					params = {"songname": songname}
					r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
					data = r.text
					data = json.loads(data)
					for song in data:
						abc = song[3].replace('https://','http://')
						hasil = 'Lyric Lagu ('
						hasil += song[0]
						hasil += ')\n\n'
						hasil += song[5]
						cl.sendText(msg.to, "Lagu " + song[0] + "\nSedang Di Prosses... Tunggu Sebentar ^_^ ")
						cl.sendAudioWithURL(msg.to,abc)
						cl.sendText(msg.to, "Title : " + song[0] + "\nLength : " + song[1] + "\nLink download : " + song[4] +"\n\n" + hasil)
						cl.sendText(msg.to, "Selamat Mendengarkan Lagu " + song[0])
             
            
            
            elif "Fancyteks " in msg.text:
              if msg.from_ in admin:
                    txt = msg.text.replace("Fancyteks ", "")
                    cl.kedapkedip(msg.to,txt)
                    print "FANCY TEKS KEDIP2"

            elif "TEST @" in msg.text:
              if msg.from_ in admin:
                 _name = msg.text.replace("TEST @","")
                 _nametarget = _name.rstrip(' ')
                 gs = cl.getGroup(msg.to)
                 for g in gs.members:
                     if _nametarget == g.displayName:
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        cl.sendText(g.mid, str(pesan["spamr"]))
                        print "SPAM TEXT INBOX"
        
            elif "Bom " in msg.text:
              print "KICK BY,BOM TAG"
              if msg.from_ in admin:                                                                         
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   targets = []
                   for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                   for target in targets:
                        try:
                            random.choice(KAC).kickoutFromGroup(msg.to,[target])                                                        
                        except:
                            pass
            elif ("Fuck " in msg.text):
              print "KICK VIA FUCK"
              if msg.from_ in admin:                                                                                     
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])                                                                             
                   key["MENTIONEES"] [0] ["M"]
                   for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                   for target in targets:                                                                                                       
                        try:
                            cl.kickoutFromGroup(msg.to,[target])
                        except:
                            cl.sendText(msg.to,"Error")

            elif "Cover @" in msg.text:
              print "STEAL COVER"
              if msg.from_ in admin:
                if msg.toType == 2:
                    cover = msg.text.replace("Cover @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.channel.getHome(target)
                                objId = h["result"]["homeInfo"]["objectId"]
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/myhome/c/download.nhn?userid=" + target + "&oid=" + objId)
                            except Exception as error:
                                print error
                                cl.sendText(msg.to,"Upload image failed.")

            elif "Steal cover @" in msg.text:
              print "STEAL COVER"
              if msg.from_ in admin:
                if msg.toType == 2:
                    cover = msg.text.replace("Steal cover @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.channel.getHome(target)
                                objId = h["result"]["homeInfo"]["objectId"]
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/myhome/c/download.nhn?userid=" + target + "&oid=" + objId)
                            except Exception as error:
                                print error
                                cl.sendText(msg.to,"Upload image failed.")
                                
                                
            elif "Dp @" in msg.text:
              print "STEAL DP"
              if msg.from_ in admin:
                if msg.toType == 2:
                    cover = msg.text.replace("Dp @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.getContact(target)
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + h.pictureStatus)
                            except Exception as error:
                                print error
                                cl.sendText(msg.to,"Upload image failed.")

            elif "Steal dp @" in msg.text:
                print "STEAL DP"
                if msg.toType == 2:
                    cover = msg.text.replace("Steal dp @","")
                    _nametarget = cover.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Not found")
                    else:
                        for target in targets:
                            try:
                                h = cl.getContact(target)
                                cl.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + h.pictureStatus)
                            except Exception as error:
                                print error
                                cl.sendText(msg.to,"Gagal upload..\nMungkin sinyal nabrak.")

            elif msg.text.lower() in ["pap owner","pap creator"]:
                            if msg.from_ in admin:
                                link = ["http://dl.profile.line-cdn.net/0hVuAVSsC-CVp8LyUKhRJ2DUBqBzcLAQ8SBB4VOVAqBWxWFh0IFRlOaQ0nV2xSHB0PEh5CbFknBT9T"]
                                pilih = random.choice(link)
                                cl.sendImageWithURL(msg.to,pilih)

            elif "Spam " in msg.text:
              print "SPAM ON (JUMLAH TEXT)"
              if msg.from_ in admin:
                txt = msg.text.split(" ")
                jmlh = int(txt[2])
                teks = msg.text.replace("Spam "+str(txt[1])+" "+str(jmlh)+" ","")
                tulisan = jmlh * (teks+"\n")
                if txt[1] == "on":
                    if jmlh <= 10:
                       for x in range(jmlh):
                           cl.sendText(msg.to, teks)
                    else:
                       cl.sendText(msg.to, "Out of Range!")
                elif txt[1] == "off":
                    if jmlh <= 10:
                        cl.sendText(msg.to, tulisan)
                    else:
                        cl.sendText(msg.to, "Out Of Range!")

            elif "Spam: " in msg.text:
              print "SPAM TEXT 20"
              if msg.from_ in admin:
                  bctxt = msg.text.replace("Spam: ", "")
                  t = 20
                  while(t):
                    cl.sendText(msg.to, (bctxt))
                    t-=1
            elif "Spam50 " in msg.text:
              print "SPAM TEXT 50"
              if msg.from_ in admin:
                  bctxt = msg.text.replace("Spam50 ", "")
                  t = 50
                  while(t):
                    cl.sendText(msg.to, (bctxt))
                    t-=1
            elif "Spam100 " in msg.text:
              print "SPAM TEXT 100"
              if msg.from_ in admin:
                  bctxt = msg.text.replace("Spam100 ", "")
                  t = 100
                  while(t):
                    cl.sendText(msg.to, (bctxt))
                    t-=1
            elif "Spam150 " in msg.text:
              print "SPAM TEXT 150"
              if msg.from_ in admin:
                  bctxt = msg.text.replace("Spam150 ", "")
                  t = 150
                  while(t):
                    cl.sendText(msg.to, (bctxt))
                    t-=1
            elif "Spam200 " in msg.text:
              print "SPAM TEXT 200"
              if msg.from_ in admin:
                  bctxt = msg.text.replace("Spam200 ", "")
                  t = 200
                  while(t):
                    cl.sendText(msg.to, (bctxt))
                    t-=1
            elif "Spam300 " in msg.text:
              print "SPAM TEXT 300"
              if msg.from_ in admin:
                  bctxt = msg.text.replace("Spam300 ", "")
                  t = 300
                  while(t):
                    cl.sendText(msg.to, (bctxt))
                    t-=1
            elif "Spam400 " in msg.text:
              print "SPAM TEXT 400"
              if msg.from_ in admin:
                  bctxt = msg.text.replace("Spam400 ", "")
                  t = 400
                  while(t):
                    cl.sendText(msg.to, (bctxt))
                    t-=1
            elif "Spam500 " in msg.text:
              print "SPAM TEXT 500"
              if msg.from_ in admin:
                  bctxt = msg.text.replace("Spam500 ", "")
                  t = 500
                  while(t):
                    cl.sendText(msg.to, (bctxt))
                    t-=1
            elif "Spam1000 " in msg.text:
              print "SPAM TEXT 1000"
              if msg.from_ in admin:
                  bctxt = msg.text.replace("Spam1000 ", "")
                  t = 1000
                  while(t):
                    cl.sendText(msg.to, (bctxt))
                    t-=1
            elif "Spam tikels" in msg.text:
              if msg.from_ in admin:
                  msg = contentType = 7
                  contentMetadata={'STKID': '27097114',
                                   'STKPKGID': '1876451',
                                   'STKVER': '18'}
                  t = 10
                  while(t):
                    cl.sendText(msg.to,(msg))
                    t-=1
            elif "Scbc " in msg.text:
              print "BROADCAST ROOM"
              if msg.from_ in admin:
                  bctxt = msg.text.replace("Scbc ", "")
                  orang = cl.getAllContactIds()
                  t = 20
                  for manusia in orang:
                    while(t):
                      cl.sendText(manusia, (bctxt))
                      t-=1

            elif "Cbc " in msg.text:
              if msg.from_ in admin:
                  broadcasttxt = msg.text.replace("Cbc ", "") 
                  orang = cl.getAllContactIds()
                  for manusia in orang:
                    cl.sendText(manusia, (broadcasttxt))
                    print "BROADCAST FREND"

 
            elif '/ig ' in msg.text.lower():
              print "CEK IG"
              if msg.from_ in admin:
                try:
                    instagram = msg.text.lower().replace("/ig ","")
                    html = requests.get('https://www.instagram.com/' + instagram + '/?')
                    soup = BeautifulSoup(html.text, 'html.parser')
                    data = soup.find_all('meta', attrs={'property':'og:description'})
                    text = data[0].get('content').split()
                    data1 = soup.find_all('meta', attrs={'property':'og:image'})
                    text1 = data1[0].get('content').split()
                    user = "Name: " + text[-2] + "\n"
                    user1 = "Username: " + text[-1] + "\n"
                    followers = "Followers: " + text[0] + "\n"
                    following = "Following: " + text[2] + "\n"
                    post = "Post: " + text[4] + "\n"
                    link = "Link: " + "https://www.instagram.com/" + instagram
                    detail = "========INSTAGRAM INFO ========\n"
                    details = "\n========INSTAGRAM INFO ========"
                    cl.sendText(msg.to, detail + user + user1 + followers + following + post + link + details)
                    cl.sendImageWithURL(msg.to, text1[0])
                except Exception as njer:
                	cl.sendText(msg.to, str(njer))
                	
                	
            elif "Kikuk " in msg.text:
              print "KICK VIA TAG KIKUK"
              if msg.from_ in admin:
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   targets = []
                   for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                   for target in targets:
                        try:
                           cl.kickoutFromGroup(msg.to,[target])
                        except:
                            pass
            elif "Kick " in msg.text:
              print "KICK VIA TAG KICK"
              if msg.from_ in admin:
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"][0]["M"]
                   targets = []
                   for x in key["MENTIONEES"]:                                                             
                        targets.append(x["M"])
                   for target in targets:
                        try:                                                                                  
                           random.choice(KAC).kickoutFromGroup(msg.to,[target])
                        except:
                            pass

            elif "Checkig " in msg.text:
              print "CEK IG VIA TAG"
              if msg.from_ in admin:
                separate = msg.text.split(" ")
                user = msg.text.replace(separate[0] + " ","")
                if user.startswith("@"):
                    user = user.replace("@","")
                profile = "https://www.instagram.com/" + user
                with requests.session() as x:
                    x.headers['user-agent'] = 'Mozilla/5.0'
                    end_cursor = ''
                    for count in range(1, 999):
                        print('PAGE: ', count)
                        r = x.get(profile, params={'max_id': end_cursor})
                    
                        data = re.search(r'window._sharedData = (\{.+?});</script>', r.text).group(1)
                        j    = json.loads(data)
                    
                        for node in j['entry_data']['ProfilePage'][0]['user']['media']['nodes']: 
                            if node['is_video']:
                                page = 'https://www.instagram.com/p/' + node['code']
                                r = x.get(page)
                                url = re.search(r'"video_url": "([^"]+)"', r.text).group(1)
                                print(url)
                                cl.sendVideoWithURL(msg.to,url)
                            else:
                                print (node['display_src'])
                                cl.sendImageWithURL(msg.to,node['display_src'])
                        end_cursor = re.search(r'"end_cursor": "([^"]+)"', r.text).group(1)                	


            elif 'Youtubelink: ' in msg.text:
              print "YUTUBE LINK"
              if msg.from_ in admin:
                try:
                    textToSearch = (msg.text).replace('Youtubelink: ', "").strip()
                    query = urllib.quote(textToSearch)
                    url = "https://www.youtube.com/results?search_query=" + query
                    response = urllib2.urlopen(url)
                    html = response.read()
                    soup = BeautifulSoup(html, "html.parser")
                    results = soup.find(attrs={'class':'yt-uix-tile-link'})
                    cl.sendText(msg.to,'https://www.youtube.com' + results['href'])
                except:
                    cl.sendText(msg.to,"Could not find it")
                    
                    
            elif 'Youtubevideo: ' in msg.text:
                    try:
                        textToSearch = (msg.text).replace('Youtubevideo: ', "").strip()
                        query = urllib.quote(textToSearch)
                        url = "https://www.youtube.com/results?search_query=" + query
                        response = urllib2.urlopen(url)
                        html = response.read()
                        soup = BeautifulSoup(html, "html.parser")
                        results = soup.find(attrs={'class': 'yt-uix-tile-link'})
                        cl.sendVideoWithURL(msg.to,'https://www.youtube.com' + results['href'])
                    except:
                        cl.sendText(msg.to, "Could not find it")                    

 
            elif "Say-id " in msg.text:
              if msg.from_ in admin:
                say = msg.text.replace("Say-id ","")
                lang = 'id'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")

            elif "Say-en " in msg.text:
              if msg.from_ in admin:
                say = msg.text.replace("Say-en ","")
                lang = 'en'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")

            elif "Say-jp " in msg.text:
              if msg.from_ in admin:
                say = msg.text.replace("Say-jp ","")
                lang = 'ja'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")

            elif "Welcome to" in msg.text:
              if msg.from_ in admin:
                gs = cl.getGroup(msg.to)
                say = msg.text.replace("Welcome to","Selamat Datang Di "+ gs.name)
                lang = 'id'
                tts = gTTS(text=say, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")


            elif msg.text.lower() in ["hi","hai","halo","hallo"]:
                    beb = "iya halo juga .. "+("@" +cl.getContact(msg.from_).displayName,"")
                    cl.sendText(msg.to,beb)



            elif "playstore " in msg.text.lower():
              if msg.from_ in admin:
                tob = msg.text.lower().replace("playstore ","")
                cl.sendText(msg.to,"Sedang Mencari...")
                cl.sendText(msg.to,"Title : "+tob+"\nSource : Google Play\nLink : https://play.google.com/store/search?q=" + tob)
                cl.sendText(msg.to,"Tuh Linknya Kak (^_^)")


            elif "Mid @" in msg.text:
              print "CEK MID @"
              if msg.from_ in admin:
                _name = msg.text.replace("Mid @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                        cl.sendText(msg.to, g.mid)
                    else:
                        pass


            elif "Mybio " in msg.text:
                print "UPDATE TL"
                if msg.from_ in admin:
                    string = msg.text.replace("Mybio ","")
                    if len(string.decode('utf-8')) <= 500:
                        profile = cl.getProfile()
                        profile.statusMessage = string
                        cl.updateProfile(profile)
                        cl.sendText(msg.to,"Done")

            elif "Namaku " in msg.text:
                print "GANTI NAMA"
		if msg.from_ in admin:
                    string = msg.text.replace("Namaku ","")
                    if len(string.decode('utf-8')) <= 5000:
                        profile = cl.getProfile()
                        profile.displayName = string
                        cl.updateProfile(profile)
                        cl.sendText(msg.to,"Done")



            elif msg.text in ["Mymid","Myid"]:
                middd = "Name : " +cl.getContact(msg.from_).displayName + "\nMid : " +msg.from_
                cl.sendText(msg.to,middd)
                print "CEK MID SELF"

            elif msg.text in ["Me"]:
                msg.contentType = 13
                msg.contentMetadata = {'mid': msg.from_}
                cl.sendMessage(msg)
                print "ME"

            elif "/apakah " in msg.text:
                apk = msg.text.replace("/apakah ","")
                rnd = ["Ya","Tidak","Bisa Jadi","Mungkin"]
                p = random.choice(rnd)
                lang = 'id'
                tts = gTTS(text=p, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")
                
            elif "/hari " in msg.text:
                apk = msg.text.replace("/hari ","")
                rnd = ["Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu"]
                p = random.choice(rnd)
                lang = 'id'
                tts = gTTS(text=p, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")                


            elif "/berapa " in msg.text:
                apk = msg.text.replace("/berapa ","")
                rnd = ['10%','20%','30%','40%','50%','60%','70%','80%','90%','100%','0%']
                p = random.choice(rnd)
                lang = 'id'
                tts = gTTS(text=p, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")
                
            elif "/berapakah " in msg.text:
                apk = msg.text.replace("/berapakah ","")
                rnd = ['1','2','3','4','5','6','7','8','9','10','Tidak Ada']
                p = random.choice(rnd)
                lang = 'id'
                tts = gTTS(text=p, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")                

            elif "/kapan " in msg.text:
                apk = msg.text.replace("/kapan ","")
                rnd = ["kapan kapan","besok","satu abad lagi","Hari ini","Tahun depan","Minggu depan","Bulan depan","Sebentar lagi","Tidak Akan Pernah"]
                p = random.choice(rnd)
                lang = 'id'
                tts = gTTS(text=p, lang=lang)
                tts.save("hasil.mp3")
                cl.sendAudio(msg.to,"hasil.mp3")

 
            elif msg.text in ["Simisimi on","Simisimi:on"]:
              if msg.from_ in admin:
                settings["simiSimi"][msg.to] = True
                wait["Simi"] = True
                cl.sendText(msg.to," Simisimi Di Aktifkan")
                
            elif msg.text in ["Simisimi off","Simisimi:off"]:
              if msg.from_ in admin:
                settings["simiSimi"][msg.to] = False
                wait["Simi"] = False
                cl.sendText(msg.to,"Simisimi Di Nonaktifkan")

 
            elif "Image " in msg.text:
              if msg.from_ in admin:
                search = msg.text.replace("Image ","")
                url = 'https://www.google.com/search?espv=2&biw=1366&bih=667&tbm=isch&oq=kuc&aqs=mobile-gws-lite.0.0l5&q=' + search
                raw_html = (download_page(url))
                items = []
                items = items + (_images_get_all_items(raw_html))
                path = random.choice(items)
                print path
                try:
                    cl.sendImageWithURL(msg.to,path)
                except:
                    pass
 
            elif "Youtube " in msg.text:
              print "SEARCH YUTUBE"
              if msg.from_ in admin:
                    query = msg.text.replace("Youtube ","")
                    with requests.session() as s:
                        s.headers['user-agent'] = 'Mozilla/5.0'
                        url = 'http://www.youtube.com/results'
                        params = {'search_query': query}
                        r = s.get(url, params=params)
                        soup = BeautifulSoup(r.content, 'html.parser')
                        hasil = ""
                        for a in soup.select('.yt-lockup-title > a[title]'):
                            if '&list=' not in a['href']:
                                hasil += ''.join((a['title'],'\nUrl : http://www.youtube.com' + a['href'],'\n\n'))
                        cl.sendText(msg.to,hasil)
                        print '[Command] Youtube Search'


 
            elif "Tr-id " in msg.text:
              if msg.from_ in admin:
                isi = msg.text.replace("Tr-id ","")
                translator = Translator()
                hasil = translator.translate(isi, dest='id')
                A = hasil.text
                A = A.encode('utf-8')
                cl.sendText(msg.to, A)

            elif "Tr-en " in msg.text:
              if msg.from_ in admin:
                isi = msg.text.replace("Tr-en ","")
                translator = Translator()
                hasil = translator.translate(isi, dest='en')
                A = hasil.text
                A = A.encode('utf-8')
                cl.sendText(msg.to, A)
                
            elif "Tr-th " in msg.text:
              if msg.from_ in admin:
                isi = msg.text.replace("Tr-th ","")
                translator = Translator()
                hasil = translator.translate(isi, dest='th')
                A = hasil.text
                A = A.encode('utf-8')
                cl.sendText(msg.to, A)                

            
            elif "Id@en" in msg.text:
              if msg.from_ in admin:
                bahasa_awal = 'id'
                bahasa_tujuan = 'en'
                kata = msg.text.replace("Id@en ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----Dari Indonesia----\n" + "" + kata + "\n\n----Ke Inggris----\n" + "" + result)


            elif "En@id" in msg.text:
              if msg.from_ in admin:
                bahasa_awal = 'en'
                bahasa_tujuan = 'id'
                kata = msg.text.replace("En@id ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----Dari Inggris----\n" + "" + kata + "\n\n----Ke Indonesia----\n" + "" + result)
                
            
            elif "Id@th" in msg.text:
              if msg.from_ in admin:
                bahasa_awal = 'id'
                bahasa_tujuan = 'th'
                kata = msg.text.replace("Id@en ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----Dari Indonesia----\n" + "" + kata + "\n\n----Ke Thailand----\n" + "" + result)
                
            
            elif "Th@id" in msg.text:
              if msg.from_ in admin:
                bahasa_awal = 'th'
                bahasa_tujuan = 'id'
                kata = msg.text.replace("Id@en ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"----Dari Thailand----\n" + "" + kata + "\n\n----Ke Indonesia----\n" + "" + result)                
 
            elif msg.text in ["Friendlist"]:
              print "LIST FREND"
              if msg.from_ in admin:
                contactlist = cl.getAllContactIds()
                kontak = cl.getContacts(contactlist)
                num=1
                msgs="═════════List Contact═════════"
                for ids in kontak:
                    msgs+="\n[%i] %s" % (num, ids.displayName)
                    num=(num+1)
                msgs+="\n═════════List Contact═════════\n\nTotal Friend : %i" % len(kontak)
                cl.sendText(msg.to, msgs)

            elif msg.text in ["Memlist"]:
              print "LIST MEMBER"
              if msg.from_ in admin:
                kontak = cl.getGroup(msg.to)
                group = kontak.members
                num=1
                msgs="═══ 🔘 List Member 🔘 ═══"
                for ids in group:
                    msgs+="\n[%i] %s" % (num, ids.displayName )
                    num=(num+1)
                msgs+="\n═══🔘List Member🔘═══\n\nTotal Members : %i" % len(group)
                cl.sendText(msg.to, msgs)

            elif msg.text in ["#Hay"]:
              print "HAI LIST MEMBER"
              if msg.from_ in admin:
                kontak = cl.getGroup(msg.to)
                group = kontak.members
                num=1
                msgs="═════════\nMention\n═════════"
                for ids in group:
                    msgs+="\n👿%i @%s" % (num, ids.displayName + " ")
                    num=(num+1)
                msgs+="\n═════════\nTagall\n═════════\n\nTotal users: %i" % len(group)
                cl.sendText(msg.to, msgs)

            elif "Getvid @" in msg.text:
              if msg.from_ in admin:
                print "[Command]dp executing"
                _name = msg.text.replace("Getvid @","")
                _nametarget = _name.rstrip('  ')
                gs = cl.getGroup(msg.to)
                targets = []
                for g in gs.members:
                    if _nametarget == g.displayName:
                        targets.append(g.mid)
                if targets == []:
                    cl.sendText(msg.to,"Contact not found")
                else:
                    for target in targets:
                        try:
                            contact = cl.getContact(target)
                            path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            cl.sendVideoWithURL(msg.to, path)
                        except Exception as e:
                            raise e
                print "[Command]dp executed"


            elif "Getgroup image" in msg.text:
              if msg.from_ in admin:
                group = cl.getGroup(msg.to)
                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                cl.sendImageWithURL(msg.to,path)
                print "PICTURE GRUP STEAL"

            elif "Urlgroup image" in msg.text:
              if msg.from_ in admin:
                group = cl.getGroup(msg.to)
                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                cl.sendText(msg.to,path)
                print "STEAL URL IMAGE GRUP"
 
            elif "Getname" in msg.text:
              print "GET NAMA @"
              if msg.from_ in admin:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                contact = cl.getContact(key1)
                cu = cl.channel.getCover(key1)
                try:
                    cl.sendText(msg.to, "===[DisplayName]===\n" + contact.displayName)
                except:
                    cl.sendText(msg.to, "===[DisplayName]===\n" + contact.displayName)


            elif "Getprofile " in msg.text:
              print "GET PROFIL TAG"
              if msg.from_ in admin:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                contact = cl.getContact(key1)
                cu = cl.channel.getCover(key1)
                path = str(cu)
                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                try:
                    cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nBio :\n" + contact.statusMessage)
                    cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                    cl.sendImageWithURL(msg.to,image)
                    cl.sendText(msg.to,"Cover " + contact.displayName)
                    cl.sendImageWithURL(msg.to,path)
                except:
                    pass


            elif "Getcontact " in msg.text:
              print "GET CONTACT VIA TAG"
              if msg.from_ in admin:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]                
                mmid = cl.getContact(key1)
                msg.contentType = 13
                msg.contentMetadata = {"mid": key1}
                cl.sendMessage(msg)

            elif "Getinfo " in msg.text:
              print "GWT INFO"
              if msg.from_ in admin:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                contact = cl.getContact(key1)
                cu = cl.channel.getCover(key1)
                try:
                    cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nMid :\n" + contact.mid + "\n\nBio :\n" + contact.statusMessage + "\n\nProfile Picture :\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n\nHeader :\n" + str(cu))
                except:
                    cl.sendText(msg.to,"Nama :\n" + contact.displayName + "\n\nMid :\n" + contact.mid + "\n\nBio :\n" + contact.statusMessage + "\n\nProfile Picture :\n" + str(cu))


            elif "Getbio " in msg.text:
              print "GET BIO VIA TAG"
              if msg.from_ in admin:
                key = eval(msg.contentMetadata["MENTION"])
                key1 = key["MENTIONEES"][0]["M"]
                contact = cl.getContact(key1)
                cu = cl.channel.getCover(key1)
                try:
                    cl.sendText(msg.to, "===[StatusMessage]===\n" + contact.statusMessage)
                except:
                    cl.sendText(msg.to, "===[StatusMessage]===\n" + contact.statusMessage)


            elif msg.text in ["Runtime"]:
              if msg.from_ in admin:
                #start = time.time()
                runtime = time.time() - mulai
                van = "Bot Sudah Berjalan Selama :\n"+waktu(runtime)
                cl.sendText(msg.to,van)
                print "CEK RUNTIME"
                
            elif "Checkdate " in msg.text:
              print "CEK TANGGAL LAHIR"
              if msg.from_ in admin:
                tanggal = msg.text.replace("Checkdate ","")
                r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
                data=r.text
                data=json.loads(data)
                lahir = data["data"]["lahir"]
                usia = data["data"]["usia"]
                ultah = data["data"]["ultah"]
                zodiak = data["data"]["zodiak"]
                cl.sendText(msg.to,"========== I N F O R M A S I ==========\n"+"Date Of Birth : "+lahir+"\nAge : "+usia+"\nUltah : "+ultah+"\nZodiak : "+zodiak+"\n========== I N F O R M A S I ==========")
                
   
            elif msg.text in ["Kalender","Time","Waktu"]:
              print "CEK KALENDER"
              if msg.from_ in admin:
                timeNow = datetime.now()
                timeHours = datetime.strftime(timeNow,"(%H:%M)")
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                inihari = datetime.today()
                hr = inihari.strftime('%A')
                bln = inihari.strftime('%m')
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bln == str(k): bln = bulan[k-1]
                rst = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + "\nJam : [ " + inihari.strftime('%H:%M:%S') + " ]"
                cl.sendText(msg.to, rst)                
                 
                
            elif "SearchID: " in msg.text:
              print "SEARCH ID LINE"
              if msg.from_ in admin:
                userid = msg.text.replace("SearchID: ","")
                contact = cl.findContactsByUserid(userid)
                msg.contentType = 13
                msg.contentMetadata = {'mid': contact.mid}
                cl.sendMessage(msg)
                
            elif "Searchid: " in msg.text:
              print "SEARCH ID LINE"
              if msg.from_ in admin:
                userid = msg.text.replace("Searchid: ","")
                contact = cl.findContactsByUserid(userid)
                msg.contentType = 13
                msg.contentMetadata = {'mid': contact.mid}
                cl.sendMessage(msg)       
                
                
            elif "removechat" in msg.text.lower():
                print "HAPUS ALL CHAT"
                if msg.from_ in admin:
                    try:
                        cl.removeAllMessages(op.param2)
                        print "[Command] Remove Chat"
                        cl.sendText(msg.to,"Done")
                    except Exception as error:
                        print error
                        cl.sendText(msg.to,"Error")      
                        
                        
            elif "Invitemeto: " in msg.text:
                print " INVITE ME"
                if msg.from_ in admin:
                    gid = msg.text.replace("Invitemeto: ","")
                    if gid == "":
                        cl.sendText(msg.to,"Invalid group id")
                    else:
                        try:
                            ki.findAndAddContactsByMid(msg.from_)
                            ki.inviteIntoGroup(gid,[msg.from_])
                        except:
                            ki.sendText(msg.to,"Mungkin Saya Tidak Di Dalaam Grup Itu")


            elif msg.text in ["Gruplist"]:
              print "GRUP LIST"
              if msg.from_ in admin:
                ki.sendText(msg.to, "Wait....!!")                    
                gid = ki.getGroupIdsJoined()
                h = ""
                for i in gid:
                    h += "・" + "%s\n" % (ki.getGroup(i).name +" ☞ ["+str(len(ki.getGroup(i).members))+"] Member\n")
                ki.sendText(msg.to,"════════\n         🔘LIST GROUPS🔘\n═══════\n" + h + "════════" + "\n・ Total Groups:" +" ["+str(len(gid))+"]\n════════")

            elif msg.text in ["Glistmid"]:   
              print "LIST GRUP ID"
              if msg.from_ in admin:
                gruplist = ki.getGroupIdsJoined()
                kontak = ki.getGroups(gruplist)
                num=1
                msgs="═══════🔘List GrupMid🔘═══════"
                for ids in kontak:
                    msgs+="\n[%i] %s" % (num, ids.id)
                    num=(num+1)
                msgs+="\n══════🔘List GrupMid🔘══════\n\nTotal Grup : %i" % len(kontak)
                ki.sendText(msg.to, msgs)



            elif "Google: " in msg.text:
                print "GUGEL SEARCH"
                if msg.from_ in admin:
                    a = msg.text.replace("Google: ","")
                    b = urllib.quote(a)
                    cl.sendText(msg.to,"Sedang Mencari...")
                    cl.sendText(msg.to, "https://www.google.com/" + b)
                    cl.sendText(msg.to,"Itu Dia Linknya. . .")     


            elif "Details group: " in msg.text:
                print "GRUP DETILE"
                if msg.from_ in admin:
                    gid = msg.text.replace("Details group: ","")
                    if gid in [""," "]:
                        cl.sendText(msg.to,"Grup id tidak valid")
                    else:
                        try:
                            groups = cl.getGroup(gid)
                            if groups.members is not None:
                                members = str(len(groups.members))
                            else:
                                members = "0"
                            if groups.invitee is not None:
                                pendings = str(len(groups.invitee))
                            else:
                                pendings = "0"
                            h = "[" + groups.name + "]\n -+GroupID : " + gid + "\n -+Members : " + members + "\n -+MembersPending : " + pendings + "\n -+Creator : " + groups.creator.displayName + "\n -+GroupPicture : http://dl.profile.line.naver.jp/" + groups.pictureStatus
                            cl.sendText(msg.to,h)
                        except Exception as error:
                            cl.sendText(msg.to,(error))
            
            elif "Cancel invite: " in msg.text:
                print "CANCEL INVIT GRUP"
                if msg.from_ in admin:
                    gids = msg.text.replace("Cancel invite: ","")
                    gid = cl.getGroup(gids)
                    for i in gid:
                        if i is not None:
                            try:
                                cl.rejectGroupInvitation(i)
                            except:
                                cl.sendText(msg.to,"Error!")
                                break
                        else:
                            break
                    if gid is not None:
                        cl.sendText(msg.to,"Berhasil tolak undangan dari grup " + gid.name)
                    else:
                        cl.sendText(msg.to,"Grup tidak ditemukan")
            
            elif msg.text in ["Acc invite"]:
                print "TERIMA SEMUA UNDANGAN ROOM"
                if msg.from_ in admin:
                    gid = cl.getGroupIdsInvited()
                    _list = ""
                    for i in gid:
                        if i is not None:
                            gids = cl.getGroup(i)
                            _list += gids.name
                            cl.acceptGroupInvitation(i)
                        else:
                            break
                    if gid is not None:
                        cl.sendText(msg.to,"Berhasil terima semua undangan dari grup :\n" + _list)
                    else:
                        cl.sendText(msg.to,"Tidak ada grup yang tertunda saat ini")

            elif "Gif gore" in msg.text:
            	gif = ("https://media.giphy.com/media/l2JHVsQiOZrNMGzYs/giphy.gif","https://media.giphy.com/media/OgltQ2hbilzJS/200w.gif")
                gore = random.choice(gif)
                cl.sendGifWithURL(msg.to,gore)
                print "GIF GORE"

            elif "Micadd " in msg.text:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                    try:
                        mimic["target"][target] = True
                        cl.sendText(msg.to,"Target ditambahkan!")
                        break
                    except:
                        cl.sendText(msg.to,"Fail !")
                        break

            elif "Micdel " in msg.text:
                targets = []
                key = eval(msg.contentMetadata["MENTION"])
                key["MENTIONEES"][0]["M"]
                for x in key["MENTIONEES"]:
                    targets.append(x["M"])
                for target in targets:
                    try:
                        del mimic["target"][target]
                        cl.sendText(msg.to,"Target dihapuskan!")
                        break
                    except:
                        cl.sendText(msg.to,"Fail !")
                        break

            elif msg.text in ["Miclist"]:
                        if mimic["target"] == {}:
                            cl.sendText(msg.to,"Nothing")
                        else:
                            mc = "Target Mimic User:\n"
                            for mi_d in mimic["target"]:
                                mc += "?? "+cl.getContact(mi_d).displayName + "\n"
                            cl.sendText(msg.to,mc)

            elif "Mimic target " in msg.text:
                        if mimic["copy"] == True:
                            siapa = msg.text.replace("Mimic target ","")
                            if siapa.rstrip(' ') == "me":
                                mimic["copy2"] = "me"
            elif "Mimic target " in msg.text:
                        if mimic["copy"] == True:
                            siapa = msg.text.replace("Mimic target ","")
                            if siapa.rstrip(' ') == "me":
                                mimic["copy2"] = "me"
                                cl.sendText(msg.to,"Mimic change to me")
                            elif siapa.rstrip(' ') == "target":
                                mimic["copy2"] = "target"
                                cl.sendText(msg.to,"Mimic change to target")
                            else:
                                cl.sendText(msg.to,"I dont know")

            elif "Mimic " in msg.text:
                cmd = msg.text.replace("Mimic ","")
                if cmd == "on":
                    if mimic["status"] == False:
                        mimic["status"] = True
                        cl.sendText(msg.to,"Reply Message on")
                    else:
                        cl.sendText(msg.to,"Sudah on")
                elif cmd == "off":
                    if mimic["status"] == True:
                        mimic["status"] = False
                        cl.sendText(msg.to,"Reply Message off")
                    else:
                        cl.sendText(msg.to,"Sudah off")


        if op.type == 59:
            print op


    except Exception as error:
        print error


while True:
    try:
        Ops = cl.fetchOps(cl.Poll.rev, 5)
    except EOFError:
        raise Exception("It might be wrong revision\n" + str(cl.Poll.rev))

    for Op in Ops:
        if (Op.type != OpType.END_OF_OPERATION):
            cl.Poll.rev = max(cl.Poll.rev, Op.revision)
            bot(Op)

