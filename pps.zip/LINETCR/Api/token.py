import os, sys, token
path = os.path.join(os.path.dirname(__file__), '../lib/')
sys.path.insert(0, path)

token = token1 = "EqMB1WGLlLv3L0loYJ76.TulyCEOGfW2uhmaMWN605G.vO4SevKZrm4ZotqxvvgbdxMS/yOemiH529VgZiSqe1Y="